package com.example.sunnysidecafe;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class GuestNotificationActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private LinearLayout notificationContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_notification_screen);

        dbHelper = new DatabaseHelper(this);
        notificationContainer = findViewById(R.id.notificationContainer);

        loadNotifications();

        TextView btnMarkRead = findViewById(R.id.tv_mark_read);
        if (btnMarkRead != null) {
            btnMarkRead.setOnClickListener(v -> {
            });
        }

        View btnBack = findViewById(R.id.btn_back_arrow);
        if(btnBack != null) btnBack.setOnClickListener(v -> finish());

        setupBottomNavigation();
    }

    private void loadNotifications() {
        if (notificationContainer == null) return;
        notificationContainer.removeAllViews();

        Cursor cursor = dbHelper.getAllNotifications();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int idxTitle = cursor.getColumnIndex(DatabaseHelper.COLUMN_NOTIF_TITLE);
                int idxMsg = cursor.getColumnIndex(DatabaseHelper.COLUMN_NOTIF_MESSAGE);
                int idxType = cursor.getColumnIndex(DatabaseHelper.COLUMN_NOTIF_TYPE);
                int idxTime = cursor.getColumnIndex(DatabaseHelper.COLUMN_NOTIF_TIME);

                if (idxTitle == -1) break;

                String title = cursor.getString(idxTitle);
                String message = cursor.getString(idxMsg);
                String type = cursor.getString(idxType);
                String timeStr = cursor.getString(idxTime);

                String displayTime = getTimeAgo(timeStr);

                View cardView = LayoutInflater.from(this).inflate(R.layout.layout_notification_item, notificationContainer, false);

                TextView tvTitle = cardView.findViewById(R.id.tv_title);
                TextView tvMessage = cardView.findViewById(R.id.tv_message);
                TextView tvTime = cardView.findViewById(R.id.tv_time);
                CardView card = cardView.findViewById(R.id.notif_card);
                FrameLayout iconBg = cardView.findViewById(R.id.icon_bg);
                ImageView icon = cardView.findViewById(R.id.img_icon);

                tvTitle.setText(title);
                tvMessage.setText(message);
                tvTime.setText(displayTime);

                if ("cancelled".equalsIgnoreCase(type)) {
                    card.setCardBackgroundColor(Color.parseColor("#80F8D7DA"));
                    iconBg.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#F8D7DA")));
                    icon.setImageResource(R.drawable.ic_reservation_cancel);
                }
                else if ("completed".equalsIgnoreCase(type) || "confirmed".equalsIgnoreCase(type)) {
                    card.setCardBackgroundColor(Color.parseColor("#80D4EDDA"));
                    iconBg.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#D4EDDA")));
                    icon.setImageResource(R.drawable.ic_reservation_completed);
                }
                else if ("ready".equalsIgnoreCase(type)) {
                    card.setCardBackgroundColor(Color.parseColor("#80D1ECF1"));
                    iconBg.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#D1ECF1")));
                    icon.setImageResource(R.drawable.ic_ready);
                }
                else {
                    card.setCardBackgroundColor(Color.parseColor("#80FFF3CD"));
                    iconBg.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#FFF3CD")));
                    icon.setImageResource(R.drawable.ic_upcoming);
                }

                notificationContainer.addView(cardView);

            } while (cursor.moveToNext());
            cursor.close();
        }
    }

    private String getTimeAgo(String timestampStr) {
        try {
            long time = Long.parseLong(timestampStr);
            long now = System.currentTimeMillis();
            long diff = now - time;

            if (diff < 60 * 1000) {
                return "Just now";
            } else if (diff < 60 * 60 * 1000) {
                long minutes = diff / (60 * 1000);
                return minutes + "m ago";
            } else if (diff < 24 * 60 * 60 * 1000) {
                long hours = diff / (60 * 60 * 1000);
                return hours + "h ago";
            } else {
                long days = diff / (24 * 60 * 60 * 1000);
                return days + "d ago";
            }
        } catch (NumberFormatException e) {
            return timestampStr != null ? timestampStr : "Just now";
        }
    }

    private void setupBottomNavigation() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, GuestMenuActivity.class)));
        if (navReservation != null) navReservation.setOnClickListener(v -> startActivity(new Intent(this, GuestReservationListActivity.class)));
        if (navSettings != null) navSettings.setOnClickListener(v -> startActivity(new Intent(this, GuestSettingsActivity.class)));
    }
}
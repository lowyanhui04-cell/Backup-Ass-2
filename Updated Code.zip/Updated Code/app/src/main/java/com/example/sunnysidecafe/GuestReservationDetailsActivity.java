package com.example.sunnysidecafe;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class GuestReservationDetailsActivity extends AppCompatActivity {

    private int peopleCount = 2;
    private Calendar currentMonthCalendar;
    private Calendar selectedDateCalendar;

    private TextView tvDateDisplay;
    private TextView tvPeopleCount;

    private List<TextView> dayViews = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_reservation_details_screen);

        currentMonthCalendar = Calendar.getInstance();
        currentMonthCalendar.set(Calendar.DAY_OF_MONTH, 1);

        selectedDateCalendar = Calendar.getInstance();

        tvDateDisplay = findViewById(R.id.tv_date_display);
        tvPeopleCount = findViewById(R.id.tv_people_count);

        ImageView btnBack = findViewById(R.id.btn_back);
        View btnMinus = findViewById(R.id.btn_minus);
        View btnPlus = findViewById(R.id.btn_plus);
        View btnNext = findViewById(R.id.btn_next);

        View btnPrevMonth = findViewById(R.id.btn_prev_month);
        View btnNextMonth = findViewById(R.id.btn_next_month);

        initializeCalendarGrid();
        updateCalendarDisplay();

        if (btnPrevMonth != null) {
            btnPrevMonth.setOnClickListener(v -> {
                currentMonthCalendar.add(Calendar.MONTH, -1);
                updateCalendarDisplay();
            });
        }

        if (btnNextMonth != null) {
            btnNextMonth.setOnClickListener(v -> {
                currentMonthCalendar.add(Calendar.MONTH, 1);
                updateCalendarDisplay();
            });
        }

        if (tvPeopleCount != null) tvPeopleCount.setText(String.valueOf(peopleCount));

        if (btnMinus != null) {
            btnMinus.setOnClickListener(v -> {
                if (peopleCount > 1) {
                    peopleCount--;
                    tvPeopleCount.setText(String.valueOf(peopleCount));
                }
            });
        }

        if (btnPlus != null) {
            btnPlus.setOnClickListener(v -> {
                if (peopleCount < 20) {
                    peopleCount++;
                    tvPeopleCount.setText(String.valueOf(peopleCount));
                }
            });
        }

        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        if (btnNext != null) {
            btnNext.setOnClickListener(v -> {
                SimpleDateFormat sdf = new SimpleDateFormat("d MMMM yyyy", Locale.ENGLISH);
                String formattedDate = sdf.format(selectedDateCalendar.getTime());

                Intent intent = new Intent(GuestReservationDetailsActivity.this, GuestReservationTimeActivity.class);
                intent.putExtra("PEOPLE_COUNT", peopleCount);
                intent.putExtra("SELECTED_DATE", formattedDate);
                startActivity(intent);
            });
        }

        setupBottomNavigation();
    }

    private void initializeCalendarGrid() {
        int[] rowIds = {
                R.id.calendar_row_1, R.id.calendar_row_2, R.id.calendar_row_3,
                R.id.calendar_row_4, R.id.calendar_row_5, R.id.calendar_row_6
        };

        for (int rowId : rowIds) {
            LinearLayout row = findViewById(rowId);
            if (row != null) {
                for (int i = 0; i < row.getChildCount(); i++) {
                    View child = row.getChildAt(i);
                    if (child instanceof TextView) {
                        dayViews.add((TextView) child);
                    }
                }
            }
        }
    }

    private void updateCalendarDisplay() {
        SimpleDateFormat sdf = new SimpleDateFormat("MMMM yyyy", Locale.ENGLISH);
        if (tvDateDisplay != null) {
            tvDateDisplay.setText(sdf.format(currentMonthCalendar.getTime()));
        }

        Calendar iterator = (Calendar) currentMonthCalendar.clone();
        iterator.set(Calendar.DAY_OF_MONTH, 1);

        int firstDayOfWeek = iterator.get(Calendar.DAY_OF_WEEK);
        int offset = firstDayOfWeek - 2;
        if (offset < 0) offset += 7;

        iterator.add(Calendar.DAY_OF_YEAR, -offset);

        for (TextView dayView : dayViews) {
            int dayOfMonth = iterator.get(Calendar.DAY_OF_MONTH);
            dayView.setText(String.valueOf(dayOfMonth));

            boolean isSameMonth = iterator.get(Calendar.MONTH) == currentMonthCalendar.get(Calendar.MONTH);
            boolean isSelected = isSameDay(iterator, selectedDateCalendar);

            if (isSelected) {
                dayView.setBackgroundResource(R.drawable.bg_calendar_selected);
                dayView.setTextColor(Color.parseColor("#1A234A"));
            } else if (isSameMonth) {
                dayView.setBackground(null);
                dayView.setTextColor(Color.parseColor("#1A234A"));
            } else {
                dayView.setBackground(null);
                dayView.setTextColor(Color.parseColor("#999999"));
            }

            final Calendar clickedDate = (Calendar) iterator.clone();
            dayView.setOnClickListener(v -> {
                selectedDateCalendar = clickedDate;
                if (clickedDate.get(Calendar.MONTH) != currentMonthCalendar.get(Calendar.MONTH)) {
                    currentMonthCalendar.setTime(clickedDate.getTime());
                    currentMonthCalendar.set(Calendar.DAY_OF_MONTH, 1);
                }
                updateCalendarDisplay();
            });

            iterator.add(Calendar.DAY_OF_YEAR, 1);
        }
    }

    private boolean isSameDay(Calendar c1, Calendar c2) {
        return c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR) &&
                c1.get(Calendar.DAY_OF_YEAR) == c2.get(Calendar.DAY_OF_YEAR);
    }

    private void setupBottomNavigation() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, GuestMenuActivity.class)));
        if (navReservation != null) navReservation.setOnClickListener(v -> startActivity(new Intent(this, GuestReservationActivity.class)));
        if (navNotification != null) navNotification.setOnClickListener(v -> startActivity(new Intent(this, GuestNotificationActivity.class)));
        if (navSettings != null) navSettings.setOnClickListener(v -> startActivity(new Intent(this, GuestSettingsActivity.class)));
    }
}
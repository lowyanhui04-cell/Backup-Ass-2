package com.example.sunnysidecafe;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GuestReservationTimeActivity extends AppCompatActivity {

    private String selectedTime = "";
    private String selectedDate;
    private int peopleCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_reservation_time_screen);

        selectedDate = getIntent().getStringExtra("SELECTED_DATE");
        peopleCount = getIntent().getIntExtra("PEOPLE_COUNT", 2);

        TextView tvSummaryDate = findViewById(R.id.tvSummaryDate);
        TextView tvSummaryGuests = findViewById(R.id.tvSummaryGuests);
        if (tvSummaryDate != null) tvSummaryDate.setText(selectedDate);
        if (tvSummaryGuests != null) tvSummaryGuests.setText(peopleCount + " Guests");

        View btnNavNext = findViewById(R.id.btn_nav_next);
        if (btnNavNext != null) {
            btnNavNext.setOnClickListener(v -> {
                if (selectedTime.isEmpty()) {
                    Toast.makeText(this, "Please select a time first", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(GuestReservationTimeActivity.this, GuestReservationTableActivity.class);
                    intent.putExtra("SELECTED_DATE", selectedDate);
                    intent.putExtra("PEOPLE_COUNT", peopleCount);
                    intent.putExtra("SELECTED_TIME", selectedTime);
                    startActivity(intent);
                }
            });
        }

        View btnBackArrow = findViewById(R.id.btn_back_arrow);
        View btnNavBack = findViewById(R.id.btn_nav_back);

        if(btnBackArrow != null) btnBackArrow.setOnClickListener(v -> finish());
        if(btnNavBack != null) btnNavBack.setOnClickListener(v -> finish());

        setupTimeSlots();
    }

    private void setupTimeSlots() {
        TextView time500 = findViewById(R.id.time_500);
        TextView time700 = findViewById(R.id.time_700);
        TextView time900 = findViewById(R.id.time_900);

        View.OnClickListener timeListener = v -> {
            resetTimeStyle(time500);
            resetTimeStyle(time700);
            resetTimeStyle(time900);

            v.setBackgroundResource(R.drawable.bg_selected);
            ((TextView) v).setTextColor(Color.BLACK);

            selectedTime = ((TextView) v).getText().toString();
        };

        if (time500 != null) time500.setOnClickListener(timeListener);
        if (time700 != null) time700.setOnClickListener(timeListener);
        if (time900 != null) time900.setOnClickListener(timeListener);
    }

    private void resetTimeStyle(TextView tv) {
        if (tv != null) {
            tv.setBackgroundResource(R.drawable.bg_unselected);
            tv.setTextColor(Color.parseColor("#1A234A")); // Dark text
        }
    }
}
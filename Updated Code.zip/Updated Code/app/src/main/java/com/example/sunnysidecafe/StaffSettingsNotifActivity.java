package com.example.sunnysidecafe;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

public class StaffSettingsNotifActivity extends AppCompatActivity {

    private SwitchCompat switchPush;
    private CheckBox cbNewRes, cbResChange;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.staff_settings_notif_screen);

        sharedPreferences = getSharedPreferences("StaffData", Context.MODE_PRIVATE);

        switchPush = findViewById(R.id.switchPush);
        cbNewRes = findViewById(R.id.cbNewRes);
        cbResChange = findViewById(R.id.cbResChange);
        Button btnSave = findViewById(R.id.btnSave);

        loadSettings();

        switchPush.setOnCheckedChangeListener((buttonView, isChecked) -> {
            cbNewRes.setEnabled(isChecked);
            cbResChange.setEnabled(isChecked);
        });

        if (btnSave != null) {
            btnSave.setOnClickListener(v -> saveSettings());
        }

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        setupBottomNav();
    }

    private void loadSettings() {
        boolean isPushOn = sharedPreferences.getBoolean("push_enabled", true);
        boolean isNewResOn = sharedPreferences.getBoolean("notif_new_res", true);
        boolean isResChangeOn = sharedPreferences.getBoolean("notif_res_change", true);

        switchPush.setChecked(isPushOn);
        cbNewRes.setChecked(isNewResOn);
        cbResChange.setChecked(isResChangeOn);

        cbNewRes.setEnabled(isPushOn);
        cbResChange.setEnabled(isPushOn);
    }

    private void saveSettings() {
        boolean isPushOn = switchPush.isChecked();
        boolean isNewRes = cbNewRes.isChecked();
        boolean isResChange = cbResChange.isChecked();

        if (!isNewRes && !isResChange) {
            isPushOn = false;
        }

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("push_enabled", isPushOn);
        editor.putBoolean("notif_new_res", isNewRes);
        editor.putBoolean("notif_res_change", isResChange);
        editor.apply();

        Toast.makeText(this, "Notification Preferences Updated", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void setupBottomNav() {
        findViewById(R.id.nav_btn_menu).setOnClickListener(v -> startActivity(new Intent(this, StaffMenuActivity.class)));
        findViewById(R.id.nav_btn_reservation).setOnClickListener(v -> startActivity(new Intent(this, StaffReservationActivity.class)));
        findViewById(R.id.nav_btn_notification).setOnClickListener(v -> startActivity(new Intent(this, StaffNotificationActivity.class)));
        findViewById(R.id.nav_btn_settings).setOnClickListener(v -> finish());
    }
}
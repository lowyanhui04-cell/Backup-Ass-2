package com.example.sunnysidecafe;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class StaffNotificationActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private LinearLayout notificationContainer;
    private LinearLayout navMenu, navReservation, navNotification, navSettings;
    private ImageView btnBack;
    private TextView btnClearAll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.staff_notification_screen);

        dbHelper = new DatabaseHelper(this);

        initializeViews();
        setupNavigation();
        setupActions();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadStaffNotifications();
    }

    private void initializeViews() {
        notificationContainer = findViewById(R.id.notificationContainer);
        navMenu = findViewById(R.id.nav_btn_menu);
        navReservation = findViewById(R.id.nav_btn_reservation);
        navNotification = findViewById(R.id.nav_btn_notification);
        navSettings = findViewById(R.id.nav_btn_settings);
        btnBack = findViewById(R.id.btnBack);
        btnClearAll = findViewById(R.id.tv_mark_read);
    }

    private void loadStaffNotifications() {
        if (notificationContainer == null) return;
        notificationContainer.removeAllViews();

        Cursor cursor = dbHelper.getNotificationsFor("staff");

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String title = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NOTIF_TITLE));
                String message = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NOTIF_MESSAGE));
                String type = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NOTIF_TYPE));
                String timeStr = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NOTIF_TIME));

                View cardView = LayoutInflater.from(this).inflate(R.layout.layout_notification_item, notificationContainer, false);

                TextView tvTitle = cardView.findViewById(R.id.tv_title);
                TextView tvMessage = cardView.findViewById(R.id.tv_message);
                TextView tvTime = cardView.findViewById(R.id.tv_time);
                CardView card = cardView.findViewById(R.id.notif_card);
                FrameLayout iconBg = cardView.findViewById(R.id.icon_bg);
                ImageView icon = cardView.findViewById(R.id.img_icon);

                tvTitle.setText(title);
                tvMessage.setText(message);
                tvTime.setText(getTimeAgo(timeStr));

                if ("cancelled".equalsIgnoreCase(type)) {
                    // CANCELLED (Red)
                    card.setCardBackgroundColor(Color.parseColor("#80F8D7DA"));
                    iconBg.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#F8D7DA")));
                    icon.setImageResource(R.drawable.ic_reservation_cancel);

                } else if ("modified".equalsIgnoreCase(type)) {
                    // MODIFIED (Yellow)
                    card.setCardBackgroundColor(Color.parseColor("#80FFF3CD"));
                    iconBg.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#FFF3CD")));
                    icon.setImageResource(R.drawable.ic_reservation_modified);

                } else {
                    // NEW BOOKING / UPCOMING (Green)
                    card.setCardBackgroundColor(Color.parseColor("#80D4EDDA"));
                    iconBg.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#D4EDDA")));
                    icon.setImageResource(R.drawable.ic_new_reservation);
                }

                notificationContainer.addView(cardView);

            } while (cursor.moveToNext());
            cursor.close();
        }
    }

    private String getTimeAgo(String timestampStr) {
        try {
            long time = Long.parseLong(timestampStr);
            long now = System.currentTimeMillis();
            long diff = now - time;
            if (diff < 60000) return "Just now";
            else if (diff < 3600000) return (diff / 60000) + "m ago";
            else if (diff < 86400000) return (diff / 3600000) + "h ago";
            else return (diff / 86400000) + "d ago";
        } catch (Exception e) { return "Just now"; }
    }

    private void setupNavigation() {
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());
        if (navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, StaffMenuActivity.class)));
        if (navReservation != null) navReservation.setOnClickListener(v -> startActivity(new Intent(this, StaffReservationActivity.class)));
        if (navNotification != null) navNotification.setOnClickListener(v -> loadStaffNotifications());
        if (navSettings != null) navSettings.setOnClickListener(v -> startActivity(new Intent(this, StaffSettingsActivity.class)));
    }

    private void setupActions() {
        if (btnClearAll != null) {
            btnClearAll.setOnClickListener(v -> {
                Toast.makeText(this, "Notifications cleared", Toast.LENGTH_SHORT).show();
                notificationContainer.removeAllViews();
            });
        }
    }
}
package com.example.sunnysidecafe;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GuestMenuActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private GridLayout menuContainer;
    private EditText etSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_menu_screen);

        dbHelper = new DatabaseHelper(this);
        menuContainer = findViewById(R.id.guestMenuContainer);
        etSearch = findViewById(R.id.etSearch);

        if (etSearch != null) {
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                    loadMenuItems(s.toString());
                }
                @Override public void afterTextChanged(Editable s) {}
            });
        }

        setupBottomNavigation();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (etSearch != null) {
            loadMenuItems(etSearch.getText().toString());
        } else {
            loadMenuItems("");
        }
    }

    private void loadMenuItems(String query) {
        if (menuContainer == null) return;
        menuContainer.removeAllViews();

        Cursor cursor = dbHelper.getAllMenuItems();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int nameIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME);
                int priceIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_PRICE);
                int imageIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_IMAGE_URI);

                String name = cursor.getString(nameIndex);
                double price = cursor.getDouble(priceIndex);
                String savedUriStr = cursor.getString(imageIndex);

                if (!query.isEmpty() && !name.toLowerCase().contains(query.toLowerCase())) {
                    continue;
                }

                View cardView = LayoutInflater.from(this).inflate(R.layout.guest_item_card, menuContainer, false);

                GridLayout.LayoutParams params = new GridLayout.LayoutParams();
                params.width = 0; // 0 width because we use weight
                params.height = GridLayout.LayoutParams.WRAP_CONTENT;
                params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
                params.setMargins(10, 10, 10, 30);
                cardView.setLayoutParams(params);

                TextView title = cardView.findViewById(R.id.tvTitle);
                TextView priceTv = cardView.findViewById(R.id.tvPrice);
                ImageView img = cardView.findViewById(R.id.imgFood);

                title.setText(name);
                priceTv.setText(String.format("RM %.2f", price));

                if (savedUriStr != null && !savedUriStr.isEmpty()) {
                    try {
                        img.setImageURI(Uri.parse(savedUriStr));
                    } catch (Exception e) {
                        img.setImageResource(R.drawable.food_pineapple);
                    }
                } else {
                    img.setImageResource(R.drawable.food_pineapple);
                }

                menuContainer.addView(cardView);

            } while (cursor.moveToNext());
            cursor.close();
        }
    }

    private void setupBottomNavigation() {
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);
        View btnBack = findViewById(R.id.btn_back_arrow);

        if(btnBack != null) btnBack.setOnClickListener(v -> finish());

        if (navReservation != null) {
            navReservation.setOnClickListener(v -> {
                startActivity(new Intent(GuestMenuActivity.this, GuestReservationActivity.class));
                overridePendingTransition(0, 0);
            });
        }

        if (navNotification != null) {
            navNotification.setOnClickListener(v -> {
                startActivity(new Intent(GuestMenuActivity.this, GuestNotificationActivity.class));
                overridePendingTransition(0, 0);
            });
        }

        if (navSettings != null) {
            navSettings.setOnClickListener(v -> {
                startActivity(new Intent(GuestMenuActivity.this, GuestSettingsActivity.class));
                overridePendingTransition(0, 0);
            });
        }
    }
}
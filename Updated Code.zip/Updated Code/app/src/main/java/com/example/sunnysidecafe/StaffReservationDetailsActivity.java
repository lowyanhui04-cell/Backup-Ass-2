package com.example.sunnysidecafe;

import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class StaffReservationDetailsActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int reservationId = -1;
    private Button btnCancel;
    private TextView tvName, tvDateTime, tvPax, tvLocation;

    private String currentGuestName = "";
    private String currentFormattedDetails = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reservation_details_screen);

        dbHelper = new DatabaseHelper(this);
        reservationId = getIntent().getIntExtra("RES_ID", -1);
        boolean isHistory = getIntent().getBooleanExtra("IS_HISTORY", false);

        tvName = findViewById(R.id.tvName);
        tvDateTime = findViewById(R.id.tvDateTime);
        tvPax = findViewById(R.id.tvPax);
        tvLocation = findViewById(R.id.tvLocation);
        btnCancel = findViewById(R.id.btnCancelReservation);

        if (reservationId != -1) {
            loadReservationDetails(reservationId);
        } else {
            Toast.makeText(this, "Error loading reservation", Toast.LENGTH_SHORT).show();
            finish();
        }

        ImageView btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        if (btnCancel != null) {
            btnCancel.setOnClickListener(v -> showCancellationDialog());
        }

        setupTabNavigation(isHistory);
        setupBottomNav();
    }

    private void loadReservationDetails(int id) {
        Cursor cursor = dbHelper.getReservation(id);

        if (cursor != null && cursor.moveToFirst()) {
            String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_RES_NAME));
            String rawDate = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_RES_DATE));
            String time = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_RES_TIME));
            int guests = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_RES_GUESTS));
            String tableInfo = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_RES_TABLE_TYPE));
            String status = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_RES_STATUS));

            currentGuestName = name;

            String formattedDate = rawDate;
            try {
                SimpleDateFormat inputFormat = new SimpleDateFormat("d MMMM yyyy", Locale.ENGLISH);
                Date dateObj = inputFormat.parse(rawDate);
                SimpleDateFormat outputFormat = new SimpleDateFormat("EEE, MMM d, yyyy", Locale.ENGLISH);
                formattedDate = outputFormat.format(dateObj);
            } catch (Exception e) { e.printStackTrace(); }

            currentFormattedDetails = formattedDate + " | " + time;

            if ("Cancelled".equalsIgnoreCase(status)) {
                if (tvName != null) {
                    tvName.setText(name + " (Cancelled)");
                    tvName.setTextColor(Color.RED);
                }
                if (btnCancel != null) btnCancel.setVisibility(View.GONE);
            } else {
                if (tvName != null) {
                    tvName.setText(name);
                    tvName.setTextColor(Color.BLACK);
                }
                if (btnCancel != null) btnCancel.setVisibility(View.VISIBLE);
            }

            if (tvDateTime != null) tvDateTime.setText(currentFormattedDetails);
            if (tvPax != null) tvPax.setText(guests + " people");

            if (tableInfo.contains("(")) {
                String[] parts = tableInfo.split("\\(", 2);
                if (tvLocation != null) tvLocation.setText(parts[0].trim());
            } else {
                if (tvLocation != null) tvLocation.setText(tableInfo);
            }
        }
        if (cursor != null) cursor.close();
    }

    private void showCancellationDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.cancellation_dialog_screen);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }

        TextView dialogTitle = dialog.findViewById(R.id.tvHeader);
        TextView dialogMessage = dialog.findViewById(R.id.tvBody);

        if (dialogTitle != null) {
            dialogTitle.setText("Cancel Reservation for " + currentGuestName + "?");
        }
        if (dialogMessage != null) {
            dialogMessage.setText("Are you sure you want to cancel the booking on " + currentFormattedDetails + "?");
        }

        Button btnConfirmCancel = dialog.findViewById(R.id.btnConfirmCancel);
        Button btnGoBack = dialog.findViewById(R.id.btnGoBack);

        btnConfirmCancel.setOnClickListener(v -> {
            boolean success = dbHelper.updateReservationStatus(String.valueOf(reservationId), "Cancelled", "staff");

            if (success) {
                Toast.makeText(this, "Reservation Cancelled", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
                Intent intent = new Intent(StaffReservationDetailsActivity.this, StaffReservationActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Failed to cancel", Toast.LENGTH_SHORT).show();
            }
        });

        btnGoBack.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void setupTabNavigation(boolean isHistory) {
        LinearLayout tabContainer = findViewById(R.id.tabContainer);
        if (tabContainer != null) {
            LinearLayout tabUpcoming = (LinearLayout) tabContainer.getChildAt(0);
            LinearLayout tabHistory = (LinearLayout) tabContainer.getChildAt(1);

            if (isHistory) {
                setTabActive(tabHistory, true);
                setTabActive(tabUpcoming, false);
            } else {
                setTabActive(tabUpcoming, true);
                setTabActive(tabHistory, false);
            }

            tabUpcoming.setOnClickListener(v -> {
                startActivity(new Intent(this, StaffReservationActivity.class));
                overridePendingTransition(0, 0);
            });

            tabHistory.setOnClickListener(v -> {
                startActivity(new Intent(this, StaffHistoryReservationActivity.class));
                overridePendingTransition(0, 0);
            });
        }
    }

    private void setTabActive(LinearLayout tab, boolean isActive) {
        TextView tv = (TextView) tab.getChildAt(0);
        View indicator = tab.getChildAt(1);
        if (isActive) {
            tv.setTextColor(Color.parseColor("#9C8749"));
            indicator.setBackgroundResource(R.drawable.tab_indicator_rounded_gold);
            setTabHeight(indicator, 5);
        } else {
            tv.setTextColor(Color.BLACK);
            indicator.setBackgroundResource(R.drawable.tab_indicator_rounded_black);
            setTabHeight(indicator, 3);
        }
    }

    private void setTabHeight(View view, int dp) {
        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
        view.setLayoutParams(params);
    }

    private void setupBottomNav() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, StaffMenuActivity.class)));
        if (navNotification != null) navNotification.setOnClickListener(v -> startActivity(new Intent(this, StaffNotificationActivity.class)));
        if (navSettings != null) navSettings.setOnClickListener(v -> startActivity(new Intent(this, StaffSettingsActivity.class)));
    }
}
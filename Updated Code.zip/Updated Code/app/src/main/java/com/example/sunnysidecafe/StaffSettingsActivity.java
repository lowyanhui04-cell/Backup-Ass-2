package com.example.sunnysidecafe;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.SwitchCompat;

public class StaffSettingsActivity extends AppCompatActivity {

    private TextView tvName, tvEmail;
    private SwitchCompat switchPush;
    private CheckBox cbNewRes, cbResChange;
    private SharedPreferences sharedPrefs;

    private final ActivityResultLauncher<Intent> editProfileLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    displayStoredAccountData();
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.staff_settings_screen);

        tvName = findViewById(R.id.tvName);
        tvEmail = findViewById(R.id.tvEmail);
        switchPush = findViewById(R.id.switchPush);
        cbNewRes = findViewById(R.id.cbNewRes);
        cbResChange = findViewById(R.id.cbResChange);

        sharedPrefs = getSharedPreferences("StaffData", Context.MODE_PRIVATE);

        displayStoredAccountData();
        loadNotificationSettings();

        ImageView btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        setupExpandableSection(R.id.headerAccount, R.id.bodyAccount, R.id.arrowAccount);
        setupExpandableSection(R.id.headerNotif, R.id.bodyNotif, R.id.arrowNotif);
        setupExpandableSection(R.id.headerAppearance, R.id.bodyAppearance, R.id.arrowAppearance);

        findViewById(R.id.btnEditProfile).setOnClickListener(v -> {
            Intent intent = new Intent(this, StaffAccountActivity.class);
            editProfileLauncher.launch(intent);
        });

        findViewById(R.id.btnSaveNotif).setOnClickListener(v -> saveNotificationSettings());

        findViewById(R.id.btnLogOut).setOnClickListener(v -> showLogoutDialog());
        setupBottomNav();
    }

    private void displayStoredAccountData() {
        tvName.setText(sharedPrefs.getString("name", "Jane"));
        tvEmail.setText(sharedPrefs.getString("email", "jane@gmail.com"));
    }

    private void loadNotificationSettings() {
        switchPush.setChecked(sharedPrefs.getBoolean("push_enabled", true));
        cbNewRes.setChecked(sharedPrefs.getBoolean("notif_new_res", true));
        cbResChange.setChecked(sharedPrefs.getBoolean("notif_res_change", true));
    }

    private void saveNotificationSettings() {
        SharedPreferences.Editor editor = sharedPrefs.edit();
        editor.putBoolean("push_enabled", switchPush.isChecked());
        editor.putBoolean("notif_new_res", cbNewRes.isChecked());
        editor.putBoolean("notif_res_change", cbResChange.isChecked());
        editor.apply();

        Toast.makeText(this, "Notification settings saved!", Toast.LENGTH_SHORT).show();

        findViewById(R.id.bodyNotif).setVisibility(View.GONE);
        findViewById(R.id.arrowNotif).animate().rotation(0).setDuration(200).start();
    }

    private void setupExpandableSection(int headerId, int bodyId, int arrowId) {
        View header = findViewById(headerId);
        View body = findViewById(bodyId);
        ImageView arrow = findViewById(arrowId);
        if (header != null && body != null && arrow != null) {
            header.setOnClickListener(v -> {
                if (body.getVisibility() == View.GONE) {
                    body.setVisibility(View.VISIBLE);
                    arrow.animate().rotation(180).setDuration(200).start();
                } else {
                    body.setVisibility(View.GONE);
                    arrow.animate().rotation(0).setDuration(200).start();
                }
            });
        }
    }

    private void showLogoutDialog() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_logout_screen);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
        dialog.findViewById(R.id.btnCancel).setOnClickListener(v -> dialog.dismiss());
        dialog.findViewById(R.id.btnLogout).setOnClickListener(v -> {
            startActivity(new Intent(this, GuestStaffActivity.class));
            finish();
        });
        dialog.show();
    }

    private void setupBottomNav() {
        findViewById(R.id.nav_btn_menu).setOnClickListener(v -> startActivity(new Intent(this, StaffMenuActivity.class)));
        findViewById(R.id.nav_btn_reservation).setOnClickListener(v -> startActivity(new Intent(this, StaffReservationActivity.class)));
        findViewById(R.id.nav_btn_notification).setOnClickListener(v -> startActivity(new Intent(this, StaffNotificationActivity.class)));
    }
}
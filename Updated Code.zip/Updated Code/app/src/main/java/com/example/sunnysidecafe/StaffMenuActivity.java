package com.example.sunnysidecafe;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class StaffMenuActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText etSearch;
    private LinearLayout menuItemsContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.staff_menu_screen);

        dbHelper = new DatabaseHelper(this);
        etSearch = findViewById(R.id.etSearch);
        menuItemsContainer = findViewById(R.id.menuItemsContainer);

        if (etSearch != null) {
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                    loadMenuItems(s.toString());
                }
                @Override public void afterTextChanged(Editable s) {}
            });
        }

        View fabAdd = findViewById(R.id.fabAdd);
        if (fabAdd != null) {
            fabAdd.setOnClickListener(v -> startActivity(new Intent(this, ManageItemActivity.class)));
        }

        View btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        setupBottomNav();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (etSearch != null) {
            loadMenuItems(etSearch.getText().toString());
        } else {
            loadMenuItems("");
        }
    }

    private void loadMenuItems(String query) {
        if (menuItemsContainer != null) {
            menuItemsContainer.removeAllViews();
        } else {
            return;
        }

        Cursor cursor = dbHelper.getAllMenuItems();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int idIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_ID);
                int nameIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME);
                int priceIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_PRICE);
                int imageIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_IMAGE_URI);

                int id = cursor.getInt(idIndex);
                String name = cursor.getString(nameIndex);
                double price = cursor.getDouble(priceIndex);
                String savedUriStr = cursor.getString(imageIndex);

                if (!query.isEmpty() && !name.toLowerCase().contains(query.toLowerCase())) {
                    continue;
                }

                View cardView = LayoutInflater.from(this).inflate(R.layout.item_menu_card, menuItemsContainer, false);

                ImageView img = cardView.findViewById(R.id.imgFood);
                TextView title = cardView.findViewById(R.id.tvTitle);
                TextView priceTv = cardView.findViewById(R.id.tvPrice);
                ImageView btnEdit = cardView.findViewById(R.id.btnEdit);
                ImageView btnDelete = cardView.findViewById(R.id.btnDelete);

                title.setText(name);
                priceTv.setText(String.format("RM %.2f", price));

                if (savedUriStr != null && !savedUriStr.isEmpty() && !savedUriStr.equals("null")) {
                    try {
                        img.setImageURI(Uri.parse(savedUriStr));
                    } catch (Exception e) {
                        img.setImageResource(R.drawable.food_pineapple); // Error fallback
                    }
                } else {
                    img.setImageResource(R.drawable.food_pineapple); // Default
                }

                btnEdit.setOnClickListener(v -> {
                    Intent intent = new Intent(this, ManageItemActivity.class);
                    intent.putExtra("ID", id);
                    intent.putExtra("NAME", name);
                    intent.putExtra("PRICE", String.valueOf(price));
                    intent.putExtra("URI", savedUriStr);
                    startActivity(intent);
                });

                btnDelete.setOnClickListener(v -> showCustomDeleteDialog(String.valueOf(id), name));

                menuItemsContainer.addView(cardView);

            } while (cursor.moveToNext());
            cursor.close();
        }
    }

    private void showCustomDeleteDialog(String id, String itemName) {
        View view = LayoutInflater.from(this).inflate(R.layout.delete_dialog_screen, null);
        AlertDialog dialog = new AlertDialog.Builder(this).setView(view).create();

        if(dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        TextView tvBody = view.findViewById(R.id.tvBody);
        if (tvBody != null) {
            tvBody.setText("Delete " + itemName + "?");
        }

        view.findViewById(R.id.btnCancel).setOnClickListener(v -> dialog.dismiss());
        view.findViewById(R.id.btnConfirmDelete).setOnClickListener(v -> {
            if (dbHelper.deleteMenuItem(id)) {
                if (etSearch != null) {
                    loadMenuItems(etSearch.getText().toString());
                } else {
                    loadMenuItems("");
                }
                Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
            }
            dialog.dismiss();
        });
        dialog.show();
    }

    private void setupBottomNav() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) navMenu.setOnClickListener(v -> Toast.makeText(this, "You are on the Menu", Toast.LENGTH_SHORT).show());

        if (navReservation != null) navReservation.setOnClickListener(v -> {
            startActivity(new Intent(this, StaffReservationActivity.class));
            overridePendingTransition(0,0);
        });

        if (navNotification != null) navNotification.setOnClickListener(v -> {
            startActivity(new Intent(this, StaffNotificationActivity.class));
            overridePendingTransition(0,0);
        });

        if (navSettings != null) navSettings.setOnClickListener(v -> {
            startActivity(new Intent(this, StaffSettingsActivity.class));
            overridePendingTransition(0,0);
        });
    }
}
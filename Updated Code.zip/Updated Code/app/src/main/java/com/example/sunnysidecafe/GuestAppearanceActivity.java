package com.example.sunnysidecafe;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class GuestAppearanceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.staff_settings_appearance_screen);

        RadioGroup radioGroup = findViewById(R.id.radioGroupTheme);

        SharedPreferences prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE);
        int themeMode = prefs.getInt("theme_mode", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);

        if (themeMode == AppCompatDelegate.MODE_NIGHT_NO) {
            radioGroup.check(R.id.rbLight);
        } else if (themeMode == AppCompatDelegate.MODE_NIGHT_YES) {
            radioGroup.check(R.id.rbDark);
        } else {
            radioGroup.check(R.id.rbSystem);
        }

        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            int mode;
            if (checkedId == R.id.rbLight) {
                mode = AppCompatDelegate.MODE_NIGHT_NO;
            } else if (checkedId == R.id.rbDark) {
                mode = AppCompatDelegate.MODE_NIGHT_YES;
            } else {
                mode = AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM;
            }

            SharedPreferences.Editor editor = prefs.edit();
            editor.putInt("theme_mode", mode);
            editor.apply();

            AppCompatDelegate.setDefaultNightMode(mode);
        });

        View btnBack = findViewById(R.id.btnBack);
        if(btnBack != null) btnBack.setOnClickListener(v -> finish());

        setupBottomNavigation();
    }

    private void setupBottomNavigation() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        if (navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, GuestMenuActivity.class)));
    }
}
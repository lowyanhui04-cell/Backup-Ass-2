package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class GuestStaffActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_staff_selection_screen);

        View btnGuest = findViewById(R.id.btnGuest);
        View btnStaff = findViewById(R.id.btnStaff);

        if (btnGuest != null) {
            btnGuest.setOnClickListener(v -> {
                Intent intent = new Intent(GuestStaffActivity.this, LoginActivity.class);
                intent.putExtra("userType", "guest"); // <--- This passes "guest" to Login
                startActivity(intent);
            });
        }

        if (btnStaff != null) {
            btnStaff.setOnClickListener(v -> {
                Intent intent = new Intent(GuestStaffActivity.this, LoginActivity.class);
                intent.putExtra("userType", "staff"); // <--- This passes "staff" to Login
                startActivity(intent);
            });
        }
    }
}
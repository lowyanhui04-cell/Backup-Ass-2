package com.example.sunnysidecafe;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.SwitchCompat;

public class GuestSettingsActivity extends AppCompatActivity {

    private LinearLayout layoutAccountContent, layoutNotifContent, layoutAppearanceContent;
    private ImageView arrowAccount, arrowNotif, arrowAppearance;

    private TextView tvName, tvEmail;
    private SwitchCompat switchPush;
    private RadioGroup radioGroupTheme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SharedPreferences prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE);
        int savedTheme = prefs.getInt("theme_mode", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
        AppCompatDelegate.setDefaultNightMode(savedTheme);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_settings_screen);

        layoutAccountContent = findViewById(R.id.layoutAccountContent);
        layoutNotifContent = findViewById(R.id.layoutNotifContent);
        layoutAppearanceContent = findViewById(R.id.layoutAppearanceContent);

        arrowAccount = findViewById(R.id.arrowAccount);
        arrowNotif = findViewById(R.id.arrowNotif);
        arrowAppearance = findViewById(R.id.arrowAppearance);

        tvName = findViewById(R.id.tvName);
        tvEmail = findViewById(R.id.tvEmail);
        switchPush = findViewById(R.id.switchPush);
        radioGroupTheme = findViewById(R.id.radioGroupTheme);

        findViewById(R.id.btnAccountHeader).setOnClickListener(v ->
                toggleSection(layoutAccountContent, arrowAccount));

        findViewById(R.id.btnNotifHeader).setOnClickListener(v ->
                toggleSection(layoutNotifContent, arrowNotif));

        findViewById(R.id.btnAppearanceHeader).setOnClickListener(v ->
                toggleSection(layoutAppearanceContent, arrowAppearance));

        findViewById(R.id.btnEditProfile).setOnClickListener(v ->
                startActivity(new Intent(this, GuestEditProfileActivity.class)));

        findViewById(R.id.btnLogOut).setOnClickListener(v -> showLogoutDialog());

        View btnBack = findViewById(R.id.btnBack);
        if(btnBack != null) btnBack.setOnClickListener(v -> finish());

        setupAccountData();
        setupNotificationSwitch();
        setupAppearanceRadio();
        setupBottomNavigation();
    }

    @Override
    protected void onResume() {
        super.onResume();
        setupAccountData();
    }

    private void toggleSection(View content, ImageView arrow) {
        if (content.getVisibility() == View.VISIBLE) {
            content.setVisibility(View.GONE);
            arrow.animate().rotation(0).setDuration(200).start();
        } else {
            content.setVisibility(View.VISIBLE);
            arrow.animate().rotation(180).setDuration(200).start();
        }
    }

    private void setupAccountData() {
        SharedPreferences prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE);
        String name = prefs.getString("user_name", "Guest User");
        String email = prefs.getString("user_email", "guest@example.com");

        tvName.setText(name);
        tvEmail.setText(email);
    }

    private void setupNotificationSwitch() {
        SharedPreferences prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE);
        boolean isEnabled = prefs.getBoolean("notifications_enabled", true);
        switchPush.setChecked(isEnabled);

        switchPush.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean("notifications_enabled", isChecked);
            editor.apply();
        });
    }

    private void setupAppearanceRadio() {
        SharedPreferences prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE);
        int themeMode = prefs.getInt("theme_mode", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);

        radioGroupTheme.setOnCheckedChangeListener(null);

        if (themeMode == AppCompatDelegate.MODE_NIGHT_NO) {
            radioGroupTheme.check(R.id.rbLight);
        } else if (themeMode == AppCompatDelegate.MODE_NIGHT_YES) {
            radioGroupTheme.check(R.id.rbDark);
        } else {
            radioGroupTheme.check(R.id.rbSystem);
        }

        radioGroupTheme.setOnCheckedChangeListener((group, checkedId) -> {
            int newMode;
            if (checkedId == R.id.rbLight) {
                newMode = AppCompatDelegate.MODE_NIGHT_NO;
            } else if (checkedId == R.id.rbDark) {
                newMode = AppCompatDelegate.MODE_NIGHT_YES;
            } else {
                newMode = AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM;
            }

            int currentMode = prefs.getInt("theme_mode", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
            if (newMode != currentMode) {
                SharedPreferences.Editor editor = prefs.edit();
                editor.putInt("theme_mode", newMode);
                editor.apply();

                AppCompatDelegate.setDefaultNightMode(newMode);
            }
        });
    }

    private void showLogoutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_logout_screen, null);
        builder.setView(view);
        AlertDialog dialog = builder.create();
        if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        view.findViewById(R.id.btnCancel).setOnClickListener(v -> dialog.dismiss());

        view.findViewById(R.id.btnLogout).setOnClickListener(v -> {
            Intent intent = new Intent(GuestSettingsActivity.this, GuestStaffActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        dialog.show();
    }

    private void setupBottomNavigation() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);

        if (navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, GuestMenuActivity.class)));
        if (navReservation != null) navReservation.setOnClickListener(v -> startActivity(new Intent(this, GuestReservationListActivity.class)));
        if (navNotification != null) navNotification.setOnClickListener(v -> startActivity(new Intent(this, GuestNotificationActivity.class)));
    }
}
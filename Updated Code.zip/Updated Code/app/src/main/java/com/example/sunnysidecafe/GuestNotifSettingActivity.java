package com.example.sunnysidecafe;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

public class GuestNotifSettingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_notif_setting_screen);

        SwitchCompat switchPush = findViewById(R.id.switchPush);

        SharedPreferences prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE);
        boolean isEnabled = prefs.getBoolean("notifications_enabled", true);
        switchPush.setChecked(isEnabled);

        switchPush.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean("notifications_enabled", isChecked);
            editor.apply();
        });

        View btnBack = findViewById(R.id.btnBack);
        if(btnBack != null) btnBack.setOnClickListener(v -> finish());

        setupBottomNavigation();
    }

    private void setupBottomNavigation() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, GuestMenuActivity.class)));
        if (navReservation != null) navReservation.setOnClickListener(v -> startActivity(new Intent(this, GuestReservationListActivity.class)));
        if (navNotification != null) navNotification.setOnClickListener(v -> startActivity(new Intent(this, GuestNotificationActivity.class)));
        if (navSettings != null) navSettings.setOnClickListener(v -> startActivity(new Intent(this, GuestSettingsActivity.class)));
    }
}
package com.example.sunnysidecafe;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GuestReservationTableActivity extends AppCompatActivity {

    private String selectedDate, selectedTime;
    private int peopleCount;
    private String selectedSeating = "Outdoor";
    private DatabaseHelper dbHelper;
    private LinearLayout layoutIndoor, layoutOutdoor, layoutWindow;
    private EditText etRemarks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_reservation_table_screen);

        dbHelper = new DatabaseHelper(this);

        selectedDate = getIntent().getStringExtra("SELECTED_DATE");
        selectedTime = getIntent().getStringExtra("SELECTED_TIME");
        peopleCount = getIntent().getIntExtra("PEOPLE_COUNT", 2);

        if(selectedTime == null) selectedTime = "Time Not Selected";

        TextView tvSummaryDate = findViewById(R.id.tvSummaryDate);
        TextView tvSummaryGuests = findViewById(R.id.tvSummaryGuests);

        View btnEditSummary = findViewById(R.id.btn_edit_summary);
        if (btnEditSummary != null) {
            btnEditSummary.setOnClickListener(v -> {
                Intent intent = new Intent(GuestReservationTableActivity.this, GuestReservationDetailsActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Clears stack to avoid loops
                startActivity(intent);
            });
        }

        if (tvSummaryDate != null) tvSummaryDate.setText(selectedDate);
        if (tvSummaryGuests != null) tvSummaryGuests.setText(peopleCount + " Guests");

        layoutIndoor = findViewById(R.id.layout_indoor);
        layoutOutdoor = findViewById(R.id.layout_outdoor);
        layoutWindow = findViewById(R.id.layout_window);
        etRemarks = findViewById(R.id.et_special_request);
        Button btnConfirm = findViewById(R.id.btn_confirm);

        setupSeatingSelection();

        if (btnConfirm != null) {
            btnConfirm.setOnClickListener(v -> confirmReservation());
        }

        ImageView btnBack = findViewById(R.id.btn_back_arrow);
        if(btnBack != null) btnBack.setOnClickListener(v -> finish());
    }

    private void setupSeatingSelection() {
        View.OnClickListener seatingListener = v -> {
            if (layoutIndoor != null) layoutIndoor.setBackgroundResource(R.drawable.bg_white_card);
            if (layoutOutdoor != null) layoutOutdoor.setBackgroundResource(R.drawable.bg_white_card);
            if (layoutWindow != null) layoutWindow.setBackgroundResource(R.drawable.bg_white_card);

            v.setBackgroundResource(R.drawable.bg_selected);

            int id = v.getId();
            if (id == R.id.layout_indoor) selectedSeating = "Indoor";
            else if (id == R.id.layout_outdoor) selectedSeating = "Outdoor";
            else if (id == R.id.layout_window) selectedSeating = "Window";
        };

        if (layoutIndoor != null) layoutIndoor.setOnClickListener(seatingListener);
        if (layoutOutdoor != null) layoutOutdoor.setOnClickListener(seatingListener);
        if (layoutWindow != null) layoutWindow.setOnClickListener(seatingListener);
    }

    private void confirmReservation() {
        SharedPreferences prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE);
        String customerName = prefs.getString("user_name", "Guest");

        String tableInfo = selectedSeating;
        if(etRemarks != null && !etRemarks.getText().toString().isEmpty()) {
            tableInfo += " (" + etRemarks.getText().toString() + ")";
        }

        boolean success = dbHelper.insertReservation(
                customerName,
                selectedDate,
                selectedTime,
                peopleCount,
                tableInfo
        );

        if (success) {
            Toast.makeText(this, "Confirmed!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(GuestReservationTableActivity.this, GuestReservationListActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Error saving to database", Toast.LENGTH_SHORT).show();
        }
    }
}
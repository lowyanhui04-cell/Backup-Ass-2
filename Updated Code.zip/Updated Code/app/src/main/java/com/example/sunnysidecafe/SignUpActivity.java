package com.example.sunnysidecafe;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SignUpActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private String userRole;
    private boolean isPassVisible = false;
    private boolean isConfirmVisible = false;

    private void registerUserOnAPI(String name, String email, String password, String role) {
        java.util.concurrent.ExecutorService executor = java.util.concurrent.Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                String studentId = "bscs2506056";
                java.net.URL url = new java.net.URL("http://10.240.72.69/comp2000/coursework/create_user/" + studentId);
                java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);

                org.json.JSONObject jsonParam = new org.json.JSONObject();
                jsonParam.put("username", email);
                jsonParam.put("password", password);
                jsonParam.put("email", email);
                jsonParam.put("userrole", role);

                java.io.OutputStream os = conn.getOutputStream();
                os.write(jsonParam.toString().getBytes("UTF-8"));
                os.close();

                int responseCode = conn.getResponseCode();
                runOnUiThread(() -> {
                    if (responseCode == 200) {
                        dbHelper.registerUser(name, email, password, role);
                        Toast.makeText(this, "API & Local Account Created!", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(this, "API Registration Failed: " + responseCode, Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup_screen);

        dbHelper = new DatabaseHelper(this);

        userRole = getIntent().getStringExtra("userType");

        if (userRole == null) {
            userRole = "guest";
        }

        EditText etName = findViewById(R.id.etName);
        EditText etEmail = findViewById(R.id.etEmail);
        EditText etPassword = findViewById(R.id.etPassword);
        EditText etConfirm = findViewById(R.id.etConfirmPassword);
        Button btnCreate = findViewById(R.id.btnCreateAccount);
        TextView tvLogin = findViewById(R.id.tvLogIn);


        updatePasswordIcon(etPassword, R.drawable.secure_password_icon);
        updatePasswordIcon(etConfirm, R.drawable.secure_password_icon);

        setupPasswordToggle(etPassword, true);
        setupPasswordToggle(etConfirm, false);

        tvLogin.setOnClickListener(v -> finish());
        btnCreate.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String pass = etPassword.getText().toString().trim();
            String confirm = etConfirm.getText().toString().trim();

            if (name.isEmpty() || email.isEmpty() || pass.isEmpty()) {

                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();

            } else if (!pass.equals(confirm)) {

                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();

            } else {

                if (dbHelper.checkUser(email, pass)) {

                    Toast.makeText(this, "User already exists", Toast.LENGTH_SHORT).show();

                    return;

                }

                if (dbHelper.registerUser(name, email, pass, userRole)) {

                    Toast.makeText(this, "Account Created! Please Login.", Toast.LENGTH_LONG).show();

                    finish();

                } else {

                    Toast.makeText(this, "Registration Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private void updatePasswordIcon(EditText editText, int drawableId) {

        Drawable drawable = ContextCompat.getDrawable(this, drawableId);

        if (drawable != null) {

            int size = (int) TypedValue.applyDimension(

                    TypedValue.COMPLEX_UNIT_DIP, 20, getResources().getDisplayMetrics());

            drawable.setBounds(0, 0, size, size);

            editText.setCompoundDrawables(null, null, drawable, null);
        }
    }
    @SuppressLint("ClickableViewAccessibility")

    private void setupPasswordToggle(EditText editText, boolean isMainPassword) {

        editText.setOnTouchListener((v, event) -> {

            final int DRAWABLE_RIGHT = 2;

            if (editText.getCompoundDrawables()[DRAWABLE_RIGHT] == null) return false;

            if (event.getAction() == MotionEvent.ACTION_UP) {

                if (event.getRawX() >= (editText.getRight() - editText.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width() - editText.getPaddingRight())) {

                    int selection = editText.getSelectionEnd();

                    boolean currentlyVisible = isMainPassword ? isPassVisible : isConfirmVisible;

                    if (currentlyVisible) {

                        editText.setTransformationMethod(PasswordTransformationMethod.getInstance());

                        updatePasswordIcon(editText, R.drawable.secure_password_icon);

                        if (isMainPassword) isPassVisible = false; else isConfirmVisible = false;

                    } else {

                        editText.setTransformationMethod(HideReturnsTransformationMethod.getInstance());

                        updatePasswordIcon(editText, R.drawable.input_field_password_icon);

                        if (isMainPassword) isPassVisible = true; else isConfirmVisible = true;

                    }

                    editText.setSelection(selection);

                    return true;

                }

            }

            return false;

        });

    }

}
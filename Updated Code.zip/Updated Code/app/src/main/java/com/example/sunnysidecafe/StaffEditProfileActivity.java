package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class StaffEditProfileActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.staff_edit_profile_screen);
        EditText etFullName = findViewById(R.id.etFullName);
        EditText etEmail = findViewById(R.id.etEmail);
        EditText etPassword = findViewById(R.id.etPassword);
        ImageView btnBack = findViewById(R.id.btnBack);

        if(btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        Button btnSaveChanges = findViewById(R.id.btnSaveChanges);

        if(btnSaveChanges != null) {

            btnSaveChanges.setOnClickListener(v -> {

                String newName = etFullName.getText().toString();

                String newEmail = etEmail.getText().toString();

                Toast.makeText(this, "Profile Updated Successfully", Toast.LENGTH_SHORT).show();

                finish();

            });

        }

        Button btnChangePassword = findViewById(R.id.btnChangePassword);

        if(btnChangePassword != null) {

            btnChangePassword.setOnClickListener(v -> Toast.makeText(this, "Change Password clicked", Toast.LENGTH_SHORT).show());

        }

        setupBottomNav();

    }

    private void setupBottomNav() {

        View navMenu = findViewById(R.id.nav_btn_menu);

        View navReservation = findViewById(R.id.nav_btn_reservation);

        View navNotification = findViewById(R.id.nav_btn_notification);

        View navSettings = findViewById(R.id.nav_btn_settings);

        if(navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, StaffMenuActivity.class)));

        if(navReservation != null) navReservation.setOnClickListener(v -> startActivity(new Intent(this, StaffReservationActivity.class)));

        if(navNotification != null) navNotification.setOnClickListener(v -> startActivity(new Intent(this, StaffNotificationActivity.class)));

        if(navSettings != null) navSettings.setOnClickListener(v -> startActivity(new Intent(this, StaffSettingsActivity.class)));

    }

}
package com.example.sunnysidecafe;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class LoginActivity extends AppCompatActivity {
    private String userType;

    private DatabaseHelper databaseHelper;

    private boolean isPassVisible = false;

    private void checkUserOnAPI(String email, String password) {
        java.util.concurrent.ExecutorService executor = java.util.concurrent.Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                String studentId = "bscs2506056";
                java.net.URL url = new java.net.URL("http://10.240.72.69/comp2000/coursework/read_all_users/" + studentId);
                java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                if (conn.getResponseCode() == 200) {
                    java.util.Scanner s = new java.util.Scanner(conn.getInputStream()).useDelimiter("\\A");
                    String response = s.hasNext() ? s.next() : "";

                    org.json.JSONObject jsonResponse = new org.json.JSONObject(response);
                    org.json.JSONArray users = jsonResponse.getJSONArray("users");

                    boolean found = false;
                    for (int i = 0; i < users.length(); i++) {
                        org.json.JSONObject user = users.getJSONObject(i);
                        if (user.getString("email").equals(email) && user.getString("password").equals(password)) {
                            found = true;
                            break;
                        }
                    }

                    boolean finalFound = found;
                    runOnUiThread(() -> {
                        if (finalFound) {
                            navigateBasedOnRole();
                        } else {
                            Toast.makeText(this, "API login failed. Checking local...", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.login_screen);

        databaseHelper = new DatabaseHelper(this);

        userType = getIntent().getStringExtra("userType");

        if (userType == null) {

            userType = "guest";

        }

        EditText etEmail = findViewById(R.id.etEmail);

        EditText etPassword = findViewById(R.id.etPassword);

        Button btnLogin = findViewById(R.id.btnLogin);

        TextView tvSignUp = findViewById(R.id.tvSignUp);

        updatePasswordIcon(etPassword, R.drawable.secure_password_icon);

        setupPasswordToggle(etPassword);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                if (email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                } else {
                    if (databaseHelper.checkUser(email, password)) {

                        String storedRole = databaseHelper.getUserRole(email);

                        if (storedRole.equalsIgnoreCase(userType)) {
                            String name = databaseHelper.getUserName(email);
                            SharedPreferences prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = prefs.edit();
                            editor.putString("user_name", name);
                            editor.putString("user_email", email);
                            editor.apply();

                            Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                            navigateBasedOnRole();
                        } else {
                            Toast.makeText(LoginActivity.this, "Access Denied: You are registered as a " + storedRole, Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(LoginActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


        tvSignUp.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {

                Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);

                intent.putExtra("userType", userType);

                startActivity(intent);

            }

        });

    }

    private void navigateBasedOnRole() {

        Intent intent;

        if ("staff".equalsIgnoreCase(userType)) {

            intent = new Intent(LoginActivity.this, StaffMenuActivity.class);

        } else {

            intent = new Intent(LoginActivity.this, GuestMenuActivity.class);

        }

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        startActivity(intent);

        finish();

    }

    private void updatePasswordIcon(EditText editText, int drawableId) {

        Drawable drawable = ContextCompat.getDrawable(this, drawableId);

        if (drawable != null) {

            int size = (int) TypedValue.applyDimension(

                    TypedValue.COMPLEX_UNIT_DIP, 20, getResources().getDisplayMetrics());

            drawable.setBounds(0, 0, size, size);

            editText.setCompoundDrawables(null, null, drawable, null);

        }
    }

    @SuppressLint("ClickableViewAccessibility")

    private void setupPasswordToggle(EditText editText) {

        editText.setOnTouchListener((v, event) -> {

            final int DRAWABLE_RIGHT = 2;

            if (editText.getCompoundDrawables()[DRAWABLE_RIGHT] == null) return false;

            if (event.getAction() == MotionEvent.ACTION_UP) {

                if (event.getRawX() >= (editText.getRight() - editText.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width() - editText.getPaddingRight())) {

                    int selection = editText.getSelectionEnd();

                    if (isPassVisible) {

                        editText.setTransformationMethod(PasswordTransformationMethod.getInstance());

                        updatePasswordIcon(editText, R.drawable.secure_password_icon);

                        isPassVisible = false;

                    } else {

                        editText.setTransformationMethod(HideReturnsTransformationMethod.getInstance());

                        updatePasswordIcon(editText, R.drawable.input_field_password_icon);

                        isPassVisible = true;

                    }

                    editText.setSelection(selection);

                    return true;
                }

            }

            return false;
        });
    }
}
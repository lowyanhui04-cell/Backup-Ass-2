package com.example.sunnysidecafe;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class NotificationHelper {

    public static void showStaffNotification(Context context, String type, String message) {
        SharedPreferences prefs = context.getSharedPreferences("StaffData", Context.MODE_PRIVATE);

        boolean masterSwitch = prefs.getBoolean("push_enabled", true);
        boolean allowNew = prefs.getBoolean("notif_new_res", true);
        boolean allowChange = prefs.getBoolean("notif_res_change", true);

        if (!masterSwitch) return;
        if (type.equals("NEW_RESERVATION") && !allowNew) return;
        if (type.equals("CHANGE_RESERVATION") && !allowChange) return;

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        String channelId = "staff_notif_channel";

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, "Reservations", NotificationManager.IMPORTANCE_HIGH);
            manager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Staff Update")
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        manager.notify((int) System.currentTimeMillis(), builder.build());
    }
}
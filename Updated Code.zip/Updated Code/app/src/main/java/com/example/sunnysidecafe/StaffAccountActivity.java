package com.example.sunnysidecafe;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

public class StaffAccountActivity extends AppCompatActivity {

    private EditText etName, etEmail;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.staff_edit_profile_screen);

        etName = findViewById(R.id.etFullName);
        etEmail = findViewById(R.id.etEmail);
        AppCompatButton btnSave = findViewById(R.id.btnSaveChanges);

        sharedPreferences = getSharedPreferences("StaffData", Context.MODE_PRIVATE);

        etName.setText(sharedPreferences.getString("name", "John"));
        etEmail.setText(sharedPreferences.getString("email", "John@gmail.com"));

        btnSave.setOnClickListener(v -> {
            String newName = etName.getText().toString().trim();
            String newEmail = etEmail.getText().toString().trim();

            if (newName.isEmpty() || newEmail.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // PERMANENTLY SAVE DATA
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("name", newName);
            editor.putString("email", newEmail);
            editor.apply();

            Toast.makeText(this, "Changes Saved!", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        });
    }
}
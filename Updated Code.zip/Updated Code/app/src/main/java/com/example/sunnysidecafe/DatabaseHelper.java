package com.example.sunnysidecafe;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "SunnysideCafe.db";
    private static final int DATABASE_VERSION = 3;

    private final Context context;

    public static final String TABLE_MENU = "menu_items";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_PRICE = "price";
    public static final String COLUMN_IMAGE_URI = "image_uri";

    public static final String TABLE_RESERVATIONS = "reservations";
    public static final String COLUMN_RES_ID = "res_id";
    public static final String COLUMN_RES_NAME = "customer_name";
    public static final String COLUMN_RES_DATE = "date";
    public static final String COLUMN_RES_TIME = "time";
    public static final String COLUMN_RES_GUESTS = "guests";
    public static final String COLUMN_RES_TABLE_TYPE = "table_type";
    public static final String COLUMN_RES_STATUS = "status";

    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_USER_NAME = "name";
    public static final String COLUMN_USER_EMAIL = "email";
    public static final String COLUMN_USER_PASSWORD = "password";
    public static final String COLUMN_USER_ROLE = "role";

    public static final String TABLE_NOTIFICATIONS = "notifications";
    public static final String COLUMN_NOTIF_ID = "notif_id";
    public static final String COLUMN_NOTIF_TITLE = "title";
    public static final String COLUMN_NOTIF_MESSAGE = "message";
    public static final String COLUMN_NOTIF_TYPE = "type";
    public static final String COLUMN_NOTIF_TIME = "time_ago";
    public static final String COLUMN_NOTIF_TARGET = "target";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_MENU + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT, " +
                COLUMN_PRICE + " REAL, " +
                COLUMN_IMAGE_URI + " TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_RESERVATIONS + " (" +
                COLUMN_RES_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_RES_NAME + " TEXT, " +
                COLUMN_RES_DATE + " TEXT, " +
                COLUMN_RES_TIME + " TEXT, " +
                COLUMN_RES_GUESTS + " INTEGER, " +
                COLUMN_RES_TABLE_TYPE + " TEXT, " +
                COLUMN_RES_STATUS + " TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USER_NAME + " TEXT, " +
                COLUMN_USER_EMAIL + " TEXT, " +
                COLUMN_USER_PASSWORD + " TEXT, " +
                COLUMN_USER_ROLE + " TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_NOTIFICATIONS + " (" +
                COLUMN_NOTIF_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NOTIF_TITLE + " TEXT, " +
                COLUMN_NOTIF_MESSAGE + " TEXT, " +
                COLUMN_NOTIF_TYPE + " TEXT, " +
                COLUMN_NOTIF_TIME + " TEXT, " +
                COLUMN_NOTIF_TARGET + " TEXT)");

        insertDummyMenuItems(db);
    }

    private void insertDummyMenuItems(SQLiteDatabase db) {
        String resourceBase = "android.resource://" + context.getPackageName() + "/drawable/";
        ContentValues v1 = new ContentValues(); v1.put(COLUMN_NAME, "Grilled Chicken Chop with Pineapple Slice"); v1.put(COLUMN_PRICE, 26.90); v1.put(COLUMN_IMAGE_URI, resourceBase + "food_pineapple"); db.insert(TABLE_MENU, null, v1);
        ContentValues v2 = new ContentValues(); v2.put(COLUMN_NAME, "Signature Grilled Chicken Chop"); v2.put(COLUMN_PRICE, 24.90); v2.put(COLUMN_IMAGE_URI, resourceBase + "food_signature"); db.insert(TABLE_MENU, null, v2);
        ContentValues v3 = new ContentValues(); v3.put(COLUMN_NAME, "Carbonara Spaghetti"); v3.put(COLUMN_PRICE, 24.90); v3.put(COLUMN_IMAGE_URI, resourceBase + "food_carbonara"); db.insert(TABLE_MENU, null, v3);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MENU);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RESERVATIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTIFICATIONS);
        onCreate(db);
    }

    // --- NOTIFICATION METHODS ---

    public void addNotification(String title, String message, String type, String target) {
        if ("guest".equalsIgnoreCase(target) && !areNotificationsEnabled(context)) {
            return;
        }
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NOTIF_TITLE, title);
        values.put(COLUMN_NOTIF_MESSAGE, message);
        values.put(COLUMN_NOTIF_TYPE, type);
        values.put(COLUMN_NOTIF_TIME, String.valueOf(System.currentTimeMillis()));
        values.put(COLUMN_NOTIF_TARGET, target);
        db.insert(TABLE_NOTIFICATIONS, null, values);
    }

    public void addNotification(String title, String message, String type) {
        addNotification(title, message, type, "guest");
    }

    public Cursor getNotificationsFor(String target) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NOTIFICATIONS +
                        " WHERE " + COLUMN_NOTIF_TARGET + " = ? ORDER BY " + COLUMN_NOTIF_ID + " DESC",
                new String[]{target});
    }

    public Cursor getAllNotifications() {
        return getNotificationsFor("guest");
    }

    private String getCustomerName(String reservationId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_RESERVATIONS, new String[]{COLUMN_RES_NAME},
                COLUMN_RES_ID + "=?", new String[]{reservationId}, null, null, null);
        String name = "Guest";
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                name = cursor.getString(0);
            }
            cursor.close();
        }
        return name;
    }

    public boolean registerUser(String name, String email, String password, String role) { SQLiteDatabase db = this.getWritableDatabase(); ContentValues values = new ContentValues(); values.put(COLUMN_USER_NAME, name); values.put(COLUMN_USER_EMAIL, email); values.put(COLUMN_USER_PASSWORD, password); values.put(COLUMN_USER_ROLE, role); return db.insert(TABLE_USERS, null, values) != -1; }

    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(TABLE_USERS, null, COLUMN_USER_EMAIL + "=? AND " + COLUMN_USER_PASSWORD + "=?", new String[]{email, password}, null, null, null);
        boolean r = c.getCount() > 0;
        c.close();
        return r;
    }

    public boolean checkUserWithRole(String email, String password, String role) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(TABLE_USERS, null,
                COLUMN_USER_EMAIL + "=? AND " + COLUMN_USER_PASSWORD + "=? AND " + COLUMN_USER_ROLE + "=?",
                new String[]{email, password, role}, null, null, null);
        boolean exists = c.getCount() > 0;
        c.close();
        return exists;
    }

    public String getUserRole(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(TABLE_USERS, new String[]{COLUMN_USER_ROLE}, COLUMN_USER_EMAIL + "=?", new String[]{email}, null, null, null);
        if(c != null && c.moveToFirst()){
            String role = c.getString(0);
            c.close();
            return role;
        }
        return "";
    }

    public String getUserName(String email) { SQLiteDatabase db = this.getReadableDatabase(); Cursor c = db.query(TABLE_USERS, new String[]{COLUMN_USER_NAME}, COLUMN_USER_EMAIL + "=?", new String[]{email}, null, null, null); if(c!=null && c.moveToFirst()){ String n = c.getString(0); c.close(); return n;} return "Guest User"; }
    public boolean insertMenuItem(String n, double p, String i) { SQLiteDatabase db = this.getWritableDatabase(); ContentValues v = new ContentValues(); v.put(COLUMN_NAME, n); v.put(COLUMN_PRICE, p); v.put(COLUMN_IMAGE_URI, i); return db.insert(TABLE_MENU, null, v) != -1; }
    public Cursor getAllMenuItems() { return this.getReadableDatabase().rawQuery("SELECT * FROM " + TABLE_MENU, null); }
    public boolean updateMenuItem(String id, String n, double p, String i) { SQLiteDatabase db = this.getWritableDatabase(); ContentValues v = new ContentValues(); v.put(COLUMN_NAME, n); v.put(COLUMN_PRICE, p); v.put(COLUMN_IMAGE_URI, i); return db.update(TABLE_MENU, v, COLUMN_ID + "=?", new String[]{id}) > 0; }
    public boolean deleteMenuItem(String id) { return this.getWritableDatabase().delete(TABLE_MENU, COLUMN_ID + "=?", new String[]{id}) > 0; }
    public Cursor getAllReservations() { return this.getReadableDatabase().rawQuery("SELECT * FROM " + TABLE_RESERVATIONS, null); }
    public Cursor getReservation(int id) { return this.getReadableDatabase().rawQuery("SELECT * FROM " + TABLE_RESERVATIONS + " WHERE " + COLUMN_RES_ID + " = ?", new String[]{String.valueOf(id)}); }
    public boolean updateUserProfile(String ce, String nn, String ne, String np) { SQLiteDatabase db = this.getWritableDatabase(); ContentValues v = new ContentValues(); v.put(COLUMN_USER_EMAIL, ne); v.put(COLUMN_USER_PASSWORD, np); return db.update(TABLE_USERS, v, COLUMN_USER_EMAIL + "=?", new String[]{ce}) != -1; }
    public boolean areNotificationsEnabled(Context context) { return context.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE).getBoolean("notifications_enabled", true); }


    public boolean insertReservation(String name, String date, String time, int guests, String tableType) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_RES_NAME, name);
        values.put(COLUMN_RES_DATE, date);
        values.put(COLUMN_RES_TIME, time);
        values.put(COLUMN_RES_GUESTS, guests);
        values.put(COLUMN_RES_TABLE_TYPE, tableType);
        values.put(COLUMN_RES_STATUS, "Confirmed");
        long result = db.insert(TABLE_RESERVATIONS, null, values);

        if (result != -1) {
            addNotification("Reservation Confirmed", "Your reservation for " + guests + " people on " + date + " is confirmed.", "confirmed", "guest");
            addNotification("New Booking", name + " has booked a table for " + guests + " people.", "upcoming", "staff");
        }
        return result != -1;
    }

    public boolean updateReservationStatus(String id, String status) {
        return updateReservationStatus(id, status, "guest");
    }

    public boolean updateReservationStatus(String id, String status, String source) {
        String name = getCustomerName(id);
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_RES_STATUS, status);
        int result = db.update(TABLE_RESERVATIONS, values, COLUMN_RES_ID + " = ?", new String[]{id});

        if (result > 0) {
            if ("Cancelled".equalsIgnoreCase(status)) {

                if ("staff".equalsIgnoreCase(source)) {
                    addNotification("Reservation Cancelled",
                            "Your reservation has been cancelled by the staff.",
                            "cancelled", "guest");

                    addNotification("Booking Cancelled",
                            "Cancelled reservation for " + name + ".",
                            "cancelled", "staff");
                } else {
                    addNotification("Reservation Cancelled",
                            "You have successfully cancelled your reservation.",
                            "cancelled", "guest");

                    addNotification("Booking Cancelled",
                            name + " has cancelled their reservation.",
                            "cancelled", "staff");
                }

            } else if ("Completed".equalsIgnoreCase(status)) {
                addNotification("Reservation Completed", "Thanks for visiting!", "completed", "guest");
            } else if ("Confirmed".equalsIgnoreCase(status)) {
                addNotification("Reservation Confirmed", "Table confirmed.", "confirmed", "guest");
            }
        }
        return result > 0;
    }

    public boolean updateReservationDetails(int id, String date, String time, int guests, String tableType) {
        String name = getCustomerName(String.valueOf(id));
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_RES_DATE, date);
        values.put(COLUMN_RES_TIME, time);
        values.put(COLUMN_RES_GUESTS, guests);
        values.put(COLUMN_RES_TABLE_TYPE, tableType);

        int result = db.update(TABLE_RESERVATIONS, values, COLUMN_RES_ID + " = ?", new String[]{String.valueOf(id)});

        if (result > 0) {
            addNotification("Reservation Updated", "You updated your details.", "upcoming", "guest");
            addNotification("Booking Modified", name + " has updated their reservation details.", "modified", "staff");
        }
        return result > 0;
    }
}
package com.example.sunnysidecafe;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GuestEditProfileActivity extends AppCompatActivity {

    private EditText etName, etEmail, etPassword;
    private DatabaseHelper dbHelper;

    private String originalEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_edit_profile_screen);

        dbHelper = new DatabaseHelper(this);
        etName = findViewById(R.id.etFullName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);

        SharedPreferences prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE);
        String currentName = prefs.getString("user_name", "");
        originalEmail = prefs.getString("user_email", ""); // Important: Keep reference to old email
        String currentPass = prefs.getString("user_password", "");

        etName.setText(currentName);
        etEmail.setText(originalEmail);
        etPassword.setText(currentPass);

        findViewById(R.id.btnSaveChanges).setOnClickListener(v -> saveChanges());

        View btnBack = findViewById(R.id.btnBack);
        if(btnBack != null) btnBack.setOnClickListener(v -> finish());
    }

    private void saveChanges() {
        String newName = etName.getText().toString().trim();
        String newEmail = etEmail.getText().toString().trim();
        String newPass = etPassword.getText().toString().trim();

        if (newName.isEmpty() || newEmail.isEmpty()) {
            Toast.makeText(this, "Name and Email cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean dbSuccess = dbHelper.updateUserProfile(originalEmail, newName, newEmail, newPass);

        SharedPreferences prefs = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("user_name", newName);
        editor.putString("user_email", newEmail);
        editor.putString("user_password", newPass);
        editor.apply();

        if (dbSuccess) {
            Toast.makeText(this, "Profile Updated Successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Profile Updated Locally", Toast.LENGTH_SHORT).show();
        }

        finish();

        View btnBack = findViewById(R.id.btnBack);
        if(btnBack != null) btnBack.setOnClickListener(v -> finish());

        setupBottomNavigation();
    }

    private void setupBottomNavigation() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, GuestMenuActivity.class)));
        if (navReservation != null) navReservation.setOnClickListener(v -> startActivity(new Intent(this, GuestReservationListActivity.class)));
        if (navNotification != null) navNotification.setOnClickListener(v -> startActivity(new Intent(this, GuestNotificationActivity.class)));
        if (navSettings != null) navSettings.setOnClickListener(v -> startActivity(new Intent(this, GuestSettingsActivity.class)));
    }
}
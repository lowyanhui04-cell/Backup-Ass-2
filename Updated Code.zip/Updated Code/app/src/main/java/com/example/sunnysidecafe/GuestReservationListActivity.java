package com.example.sunnysidecafe;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class GuestReservationListActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private CardView cardReservation;
    private TextView tvDateTime, tvPeople, tvTableType, tvStatusBadge;
    private int currentResId = -1;

    private LinearLayout tabUpcoming, tabHistory;
    private TextView tvTabUpcoming, tvTabHistory;
    private View indicatorUpcoming, indicatorHistory;

    private boolean isHistoryTab = false;

    private String currentDisplayDate = "";
    private String currentDisplayTime = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_reservation_list_screen);

        dbHelper = new DatabaseHelper(this);

        cardReservation = findViewById(R.id.card_reservation);
        tvDateTime = findViewById(R.id.tv_datetime);
        tvTableType = findViewById(R.id.tv_table_type);

        View layoutPeople = findViewById(R.id.layout_people);
        if (layoutPeople instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) layoutPeople;
            if (group.getChildCount() > 1 && group.getChildAt(1) instanceof TextView) {
                tvPeople = (TextView) group.getChildAt(1);
            }
        }

        if (cardReservation.getChildCount() > 0) {
            View cardInner = cardReservation.getChildAt(0);
            if (cardInner instanceof ViewGroup) {
                View badge = ((ViewGroup) cardInner).getChildAt(0);
                if (badge instanceof TextView) {
                    tvStatusBadge = (TextView) badge;
                }
            }
        }

        LinearLayout tabContainer = findViewById(R.id.tabContainer);
        if (tabContainer != null) {
            tabUpcoming = (LinearLayout) tabContainer.getChildAt(0);
            tvTabUpcoming = (TextView) tabUpcoming.getChildAt(0);
            indicatorUpcoming = tabUpcoming.getChildAt(1);

            tabHistory = (LinearLayout) tabContainer.getChildAt(1);
            tvTabHistory = (TextView) tabHistory.getChildAt(0);
            indicatorHistory = tabHistory.getChildAt(1);

            tabUpcoming.setOnClickListener(v -> switchTab(false));
            tabHistory.setOnClickListener(v -> switchTab(true));
        }

        View btnEdit = findViewById(R.id.btn_edit);
        View btnCancel = findViewById(R.id.btn_cancel);
        View btnBack = findViewById(R.id.btn_back_arrow);

        if(btnEdit != null) btnEdit.setOnClickListener(v -> showEditDialog());
        if(btnCancel != null) btnCancel.setOnClickListener(v -> showCancelDialog());
        if(btnBack != null) btnBack.setOnClickListener(v -> finish());

        setupBottomNavigation();
    }

    @Override
    protected void onResume() {
        super.onResume();
        switchTab(isHistoryTab);
    }

    private void switchTab(boolean isHistory) {
        isHistoryTab = isHistory;

        if (!isHistory) {
            tvTabUpcoming.setTextColor(Color.parseColor("#9C8749")); // Gold
            indicatorUpcoming.setBackgroundResource(R.drawable.tab_indicator_rounded_gold);
            setTabHeight(indicatorUpcoming, 5);

            tvTabHistory.setTextColor(Color.BLACK);
            indicatorHistory.setBackgroundResource(R.drawable.tab_indicator_rounded_black);
            setTabHeight(indicatorHistory, 3);

        } else {
            tvTabUpcoming.setTextColor(Color.BLACK);
            indicatorUpcoming.setBackgroundResource(R.drawable.tab_indicator_rounded_black);
            setTabHeight(indicatorUpcoming, 3);

            tvTabHistory.setTextColor(Color.parseColor("#9C8749"));
            indicatorHistory.setBackgroundResource(R.drawable.tab_indicator_rounded_gold);
            setTabHeight(indicatorHistory, 5);
        }

        loadReservations();
    }

    private void setTabHeight(View view, int dp) {
        if (view == null) return;
        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.height = (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
        view.setLayoutParams(params);
    }

    private void loadReservations() {
        String selection;
        if (isHistoryTab) {
            selection = DatabaseHelper.COLUMN_RES_STATUS + " = 'Cancelled'";
        } else {
            selection = DatabaseHelper.COLUMN_RES_STATUS + " != 'Cancelled'";
        }

        Cursor cursor = dbHelper.getReadableDatabase().query(
                DatabaseHelper.TABLE_RESERVATIONS,
                null, selection, null, null, null,
                DatabaseHelper.COLUMN_RES_ID + " DESC LIMIT 1");

        if (cursor != null && cursor.moveToFirst()) {
            currentResId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_RES_ID));
            String rawDate = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_RES_DATE));
            String time = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_RES_TIME));
            int guests = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_RES_GUESTS));
            String tableInfo = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_RES_TABLE_TYPE));
            String status = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_RES_STATUS));

            try {
                SimpleDateFormat inputFormat = new SimpleDateFormat("d MMMM yyyy", Locale.ENGLISH);
                Date dateObj = inputFormat.parse(rawDate);
                SimpleDateFormat outputFormat = new SimpleDateFormat("EEE, MMM d", Locale.ENGLISH);
                currentDisplayDate = outputFormat.format(dateObj);
            } catch (Exception e) {
                currentDisplayDate = rawDate;
            }
            currentDisplayTime = (time != null && !time.isEmpty()) ? time : "Time N/A";

            if(tvDateTime != null) tvDateTime.setText(currentDisplayDate + " | " + currentDisplayTime);
            if(tvPeople != null) tvPeople.setText(guests + " people");
            if(tvTableType != null) tvTableType.setText(tableInfo);

            if (tvStatusBadge != null) {
                tvStatusBadge.setText(status);
                if ("Cancelled".equalsIgnoreCase(status)) {
                    tvStatusBadge.setTextColor(Color.RED);
                } else {
                    tvStatusBadge.setTextColor(Color.parseColor("#16A34A"));
                    tvStatusBadge.setBackgroundResource(R.drawable.bg_badge_staff);
                }
            }

            if(cardReservation != null) cardReservation.setVisibility(View.VISIBLE);

            View btnLayout = findViewById(R.id.btn_edit).getParent() instanceof LinearLayout ? (View) findViewById(R.id.btn_edit).getParent() : null;
            if(btnLayout != null) {
                btnLayout.setVisibility(isHistoryTab ? View.GONE : View.VISIBLE);
            }

        } else {
            if(cardReservation != null) cardReservation.setVisibility(View.GONE);
        }
        if(cursor != null) cursor.close();
    }

    private void showEditDialog() {
        if (currentResId == -1) return;

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_edit_reservation, null);
        builder.setView(view);
        AlertDialog dialog = builder.create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            Window window = dialog.getWindow();
            WindowManager.LayoutParams wlp = window.getAttributes();
            wlp.gravity = Gravity.BOTTOM;
            wlp.width = WindowManager.LayoutParams.MATCH_PARENT;
            window.setAttributes(wlp);
        }

        TextView tvDateVal = view.findViewById(R.id.tv_date_value);
        TextView tvTimeVal = view.findViewById(R.id.tv_time_value);
        TextView tvGuests = view.findViewById(R.id.tv_people_count);
        TextView tvSeating = view.findViewById(R.id.tv_seating_value);
        View btnUpdate = view.findViewById(R.id.btn_update_reservation);
        View btnClose = view.findViewById(R.id.btn_close_dialog);

        tvDateVal.setText(currentDisplayDate);
        tvTimeVal.setText(currentDisplayTime);
        if(tvPeople != null) tvGuests.setText(tvPeople.getText().toString().replace(" people", "").trim());
        if(tvTableType != null) tvSeating.setText(tvTableType.getText());

        view.findViewById(R.id.field_date).setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this, (dp, y, m, d) -> {
                SimpleDateFormat displayFormat = new SimpleDateFormat("EEE, MMM d", Locale.ENGLISH);
                c.set(y, m, d);
                tvDateVal.setText(displayFormat.format(c.getTime()));
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });

        view.findViewById(R.id.field_time).setOnClickListener(v -> {
            new TimePickerDialog(this, (tp, h, m) -> {
                String amPm = (h < 12) ? "AM" : "PM";
                int hour = (h > 12) ? h - 12 : h;
                if (hour == 0) hour = 12;
                String newTime = String.format(Locale.ENGLISH, "%d:%02d %s", hour, m, amPm);
                tvTimeVal.setText(newTime);
            }, 12, 0, false).show();
        });

        view.findViewById(R.id.btn_minus_people).setOnClickListener(v -> {
            try {
                int n = Integer.parseInt(tvGuests.getText().toString());
                if (n > 1) tvGuests.setText(String.valueOf(n - 1));
            } catch (Exception e) {}
        });

        view.findViewById(R.id.btn_plus_people).setOnClickListener(v -> {
            try {
                int n = Integer.parseInt(tvGuests.getText().toString());
                if (n < 20) tvGuests.setText(String.valueOf(n + 1));
            } catch (Exception e) {}
        });

        view.findViewById(R.id.field_seating).setOnClickListener(v -> {
            String current = tvSeating.getText().toString();
            if (current.contains("Outdoor")) tvSeating.setText("Indoor");
            else if (current.contains("Indoor")) tvSeating.setText("Window");
            else tvSeating.setText("Outdoor");
        });

        btnUpdate.setOnClickListener(v -> {
            boolean success = dbHelper.updateReservationDetails(
                    currentResId,
                    tvDateVal.getText().toString(),
                    tvTimeVal.getText().toString(),
                    Integer.parseInt(tvGuests.getText().toString()),
                    tvSeating.getText().toString()
            );

            if (success) {
                Toast.makeText(this, "Reservation Updated", Toast.LENGTH_SHORT).show();
                loadReservations();
                dialog.dismiss();
            }
        });

        btnClose.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void showCancelDialog() {
        if (currentResId == -1) return;

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_cancel_reservation, null);
        builder.setView(view);
        AlertDialog dialog = builder.create();
        if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        view.findViewById(R.id.btn_no).setOnClickListener(v -> dialog.dismiss());

        view.findViewById(R.id.btn_yes).setOnClickListener(v -> {
            boolean success = dbHelper.updateReservationStatus(String.valueOf(currentResId), "Cancelled");
            if (success) {
                Toast.makeText(this, "Reservation Cancelled", Toast.LENGTH_SHORT).show();
                loadReservations();
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void setupBottomNavigation() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) navMenu.setOnClickListener(v -> {
            startActivity(new Intent(this, GuestMenuActivity.class));
            overridePendingTransition(0,0);
        });

        if (navNotification != null) navNotification.setOnClickListener(v -> {
            startActivity(new Intent(this, GuestNotificationActivity.class));
            overridePendingTransition(0,0);
        });

        if (navSettings != null) navSettings.setOnClickListener(v -> {
            startActivity(new Intent(this, GuestSettingsActivity.class));
            overridePendingTransition(0,0);
        });
    }
}
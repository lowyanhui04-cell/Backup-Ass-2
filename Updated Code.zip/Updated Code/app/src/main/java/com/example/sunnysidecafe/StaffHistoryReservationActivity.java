package com.example.sunnysidecafe;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class StaffHistoryReservationActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private TextView tvName, tvDate;
    private Button btnViewDetails;
    private int currentResId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reservation_list_screen);

        dbHelper = new DatabaseHelper(this);
        updateTabStyles();

        View constraintLayout = findViewById(R.id.card_reservation);
        if (constraintLayout != null) {
            tvName = constraintLayout.findViewById(R.id.tvName);
            tvDate = constraintLayout.findViewById(R.id.tvDate);
            btnViewDetails = constraintLayout.findViewById(R.id.btnViewDetails);
        } else {
            tvName = findViewById(R.id.tvName);
            tvDate = findViewById(R.id.tvDate);
            btnViewDetails = findViewById(R.id.btnViewDetails);
        }

        ImageView btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        if (btnViewDetails != null) {
            btnViewDetails.setOnClickListener(v -> {
                if (currentResId != -1) {
                    Intent intent = new Intent(this, StaffReservationDetailsActivity.class);
                    intent.putExtra("RES_ID", currentResId);
                    intent.putExtra("IS_HISTORY", true);
                    startActivity(intent);
                }
            });
        }

        setupBottomNav();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadHistoryReservations();
    }

    private void updateTabStyles() {
        LinearLayout tabContainer = findViewById(R.id.tabContainer);
        if (tabContainer != null) {
            LinearLayout tabUpcoming = (LinearLayout) tabContainer.getChildAt(0);
            LinearLayout tabHistory = (LinearLayout) tabContainer.getChildAt(1);

            TextView tvUpcoming = (TextView) tabUpcoming.getChildAt(0);
            View indUpcoming = tabUpcoming.getChildAt(1);
            tvUpcoming.setTextColor(Color.BLACK);
            indUpcoming.setBackgroundResource(R.drawable.tab_indicator_rounded_black);
            setTabHeight(indUpcoming, 3);

            TextView tvHistory = (TextView) tabHistory.getChildAt(0);
            View indHistory = tabHistory.getChildAt(1);
            tvHistory.setTextColor(Color.parseColor("#9C8749"));
            indHistory.setBackgroundResource(R.drawable.tab_indicator_rounded_gold);
            setTabHeight(indHistory, 5);

            tabUpcoming.setOnClickListener(v -> {
                Intent intent = new Intent(this, StaffReservationActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
                finish();
            });
        }
    }

    private void setTabHeight(View view, int dp) {
        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.height = (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
        view.setLayoutParams(params);
    }

    private void loadHistoryReservations() {
        Cursor cursor = dbHelper.getReadableDatabase().rawQuery(
                "SELECT * FROM " + DatabaseHelper.TABLE_RESERVATIONS +
                        " WHERE " + DatabaseHelper.COLUMN_RES_STATUS + " = 'Cancelled' " +
                        " ORDER BY " + DatabaseHelper.COLUMN_RES_ID + " DESC LIMIT 1", null);

        View cardContainer = findViewById(R.id.card_reservation).getParent() instanceof View ?
                (View) findViewById(R.id.card_reservation).getParent() : findViewById(R.id.card_reservation);

        if (cursor != null && cursor.moveToFirst()) {
            currentResId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_RES_ID));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_RES_NAME));
            String rawDate = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_RES_DATE));
            String time = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_RES_TIME));

            String formattedDate = rawDate;
            try {
                SimpleDateFormat inputFormat = new SimpleDateFormat("d MMMM yyyy", Locale.ENGLISH);
                Date dateObj = inputFormat.parse(rawDate);
                SimpleDateFormat outputFormat = new SimpleDateFormat("EEE, MMM d", Locale.ENGLISH);
                formattedDate = outputFormat.format(dateObj);
            } catch (Exception e) {}

            if(tvName != null) tvName.setText(name);
            if(tvDate != null) tvDate.setText(formattedDate + " | " + time + " (Cancelled)");

            if(cardContainer != null) cardContainer.setVisibility(View.VISIBLE);
        } else {
            if(cardContainer != null) cardContainer.setVisibility(View.GONE);
            currentResId = -1;
        }

        if (cursor != null) cursor.close();
    }

    private void setupBottomNav() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, StaffMenuActivity.class)));
        if (navNotification != null) navNotification.setOnClickListener(v -> startActivity(new Intent(this, StaffNotificationActivity.class)));
        if (navSettings != null) navSettings.setOnClickListener(v -> startActivity(new Intent(this, StaffSettingsActivity.class)));
    }
}
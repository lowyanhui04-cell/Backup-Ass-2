package com.example.sunnysidecafe;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class EditMenuActivity extends AppCompatActivity {

    private EditText etName, etPrice;
    private ImageView imgPreview, btnBack;
    private Button btnSave, btnCancel, btnChangeImage;
    private DatabaseHelper dbHelper;
    private int itemId;
    private String currentImageUri = ""; // Stores the URI string

    // Image Picker Code
    private final ActivityResultLauncher<String> selectImage = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    currentImageUri = uri.toString();
                    imgPreview.setImageURI(uri);
                    // Take persistent permission so image loads after restart
                    try {
                        getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (SecurityException e) {
                        e.printStackTrace();
                    }
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_menu_screen);

        dbHelper = new DatabaseHelper(this);

        // Get the ID passed from Menu Screen
        itemId = getIntent().getIntExtra("ITEM_ID", -1);

        // Initialize Views
        etName = findViewById(R.id.etItemName);
        etPrice = findViewById(R.id.etPrice);
        imgPreview = findViewById(R.id.imgPreview);
        btnSave = findViewById(R.id.btnSaveChange);
        btnCancel = findViewById(R.id.btnCancel);
        btnChangeImage = findViewById(R.id.btnChangeImage);
        btnBack = findViewById(R.id.btnBack);

        // Load existing data
        loadItemDetails();

        // Button Actions
        btnChangeImage.setOnClickListener(v -> selectImage.launch("image/*"));

        btnSave.setOnClickListener(v -> {
            String newName = etName.getText().toString();
            String newPrice = etPrice.getText().toString();

            if (newName.isEmpty() || newPrice.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                // Update Database
                dbHelper.updateMenuItem(itemId, newName, "", newPrice, currentImageUri);
                Toast.makeText(this, "Changes Saved", Toast.LENGTH_SHORT).show();
                finish(); // Close screen and go back to menu
            }
        });

        btnCancel.setOnClickListener(v -> finish());
        btnBack.setOnClickListener(v -> finish());
    }

    private void loadItemDetails() {
        Cursor cursor = dbHelper.getMenuItem(itemId);
        if (cursor != null && cursor.moveToFirst()) {
            // DatabaseHelper columns: 0=id, 1=name, 2=desc, 3=price, 4=image
            etName.setText(cursor.getString(1));
            // Cursor index might vary slightly depending on your DB creation order,
            // but usually price is index 3 based on previous code.
            etPrice.setText(cursor.getString(3));

            String uriStr = cursor.getString(4);
            if (uriStr != null && !uriStr.isEmpty()) {
                currentImageUri = uriStr;
                try {
                    imgPreview.setImageURI(Uri.parse(uriStr));
                } catch (Exception e) {
                    // Handle case where image no longer exists
                    imgPreview.setImageResource(R.drawable.food_pineapple); // Fallback
                }
            }
        }
        if (cursor != null) cursor.close();
    }
}
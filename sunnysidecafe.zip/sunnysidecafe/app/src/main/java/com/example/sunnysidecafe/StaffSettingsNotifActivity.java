package com.example.sunnysidecafe;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

public class StaffSettingsNotifActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Ensure this matches the file name of the XML you pasted above
        setContentView(R.layout.staff_settings_notif_screen);

        // --- Back Button ---
        ImageView btnBack = findViewById(R.id.btnBack);
        if(btnBack != null) btnBack.setOnClickListener(v -> finish());

        // --- Notification Controls ---
        // These IDs exist in your pasted XML inside the 'btnNotifications' block
        SwitchCompat switchPush = findViewById(R.id.switchPush);
        CheckBox cbNewRes = findViewById(R.id.cbNewRes);
        CheckBox cbResChange = findViewById(R.id.cbResChange);

        // --- Save Changes Button ---
        Button btnSave = findViewById(R.id.btnSave);
        if(btnSave != null) {
            btnSave.setOnClickListener(v -> {
                boolean isPushOn = switchPush != null && switchPush.isChecked();
                boolean isNewRes = cbNewRes != null && cbNewRes.isChecked();
                boolean isResChange = cbResChange != null && cbResChange.isChecked();

                String message = "Settings Saved:\nPush: " + isPushOn + "\nNew Res: " + isNewRes;
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

                // Navigate back or refresh
                finish();
            });
        }

        // --- Navigation Buttons (Account, Appearance, Logout) ---
        // These IDs exist in your XML
        View btnAccount = findViewById(R.id.btnAccount);
        if(btnAccount != null) {
            btnAccount.setOnClickListener(v -> startActivity(new Intent(this, StaffAccountActivity.class)));
        }

        View btnAppearance = findViewById(R.id.btnAppearance);
        if(btnAppearance != null) {
            btnAppearance.setOnClickListener(v -> startActivity(new Intent(this, StaffSettingsAppearanceActivity.class)));
        }

        View btnLogOut = findViewById(R.id.btnLogOut);
        if(btnLogOut != null) {
            btnLogOut.setOnClickListener(v -> showLogoutDialog());
        }

        // --- Bottom Navigation ---
        setupBottomNav();
    }

    private void showLogoutDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_logout_screen);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }

        Button btnCancel = dialog.findViewById(R.id.btnCancel);
        Button btnLogout = dialog.findViewById(R.id.btnLogout);

        if(btnCancel != null) btnCancel.setOnClickListener(v -> dialog.dismiss());
        if(btnLogout != null) btnLogout.setOnClickListener(v -> {
            dialog.dismiss();
            Toast.makeText(this, "Logged Out Successfully", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
        dialog.show();
    }

    private void setupBottomNav() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if(navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, StaffMenuActivity.class)));
        if(navReservation != null) navReservation.setOnClickListener(v -> startActivity(new Intent(this, StaffReservationActivity.class)));
        if(navNotification != null) navNotification.setOnClickListener(v -> startActivity(new Intent(this, StaffNotificationActivity.class)));
        if(navSettings != null) navSettings.setOnClickListener(v -> startActivity(new Intent(this, StaffSettingsActivity.class)));
    }
}
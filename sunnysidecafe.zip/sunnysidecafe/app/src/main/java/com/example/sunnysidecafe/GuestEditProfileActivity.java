package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GuestEditProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_edit_profile_screen);

        ImageView btnBack = findViewById(R.id.btn_back_arrow); // Check ID
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        Button btnSave = findViewById(R.id.btnSaveChanges); // Check ID
        if (btnSave != null) {
            btnSave.setOnClickListener(v -> {
                Toast.makeText(this, "Profile Updated", Toast.LENGTH_SHORT).show();
                finish();
            });
        }
    }
}
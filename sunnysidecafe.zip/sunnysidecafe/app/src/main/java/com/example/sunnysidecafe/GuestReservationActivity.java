package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button; // For AppCompatButton
import androidx.appcompat.app.AppCompatActivity;

public class GuestReservationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Links to your FIRST XML (Reservation Hub)
        setContentView(R.layout.guest_reservation_hub_screen);

        // 1. Logic for "View My Reservation" -> Go to List Screen
        View btnViewReservation = findViewById(R.id.btn_view_reservation);
        if (btnViewReservation != null) {
            btnViewReservation.setOnClickListener(v -> {
                Intent intent = new Intent(GuestReservationActivity.this, GuestReservationListActivity.class);
                startActivity(intent);
            });
        }

        // 2. Logic for "Make New Reservation" -> Go to Details Screen
        View btnMakeReservation = findViewById(R.id.btn_make_reservation);
        if (btnMakeReservation != null) {
            btnMakeReservation.setOnClickListener(v -> {
                Intent intent = new Intent(GuestReservationActivity.this, GuestReservationDetailsActivity.class);
                startActivity(intent);
            });
        }

        // 3. Back Button
        View btnBack = findViewById(R.id.btn_back);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }
    }
}
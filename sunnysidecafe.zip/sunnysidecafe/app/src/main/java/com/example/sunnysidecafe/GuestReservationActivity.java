package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;

public class GuestReservationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_reservation_hub_screen);

        // --- Back Button ---
        ImageButton btnBack = findViewById(R.id.btn_back);
        btnBack.setOnClickListener(v -> finish()); // Closes this screen and goes back

        // --- View My Reservation ---
        Button btnViewReservation = findViewById(R.id.btn_view_reservation);
        btnViewReservation.setOnClickListener(v -> {
            // Navigate to Reservation List
            // Intent intent = new Intent(GuestReservationActivity.this, GuestReservationListActivity.class);
            // startActivity(intent);
        });

        // --- Make New Reservation ---
        Button btnMakeReservation = findViewById(R.id.btn_make_reservation);
        btnMakeReservation.setOnClickListener(v -> {
            // Navigate to New Reservation Form
            // Intent intent = new Intent(GuestReservationActivity.this, GuestNewReservationActivity.class);
            // startActivity(intent);
        });
    }
}
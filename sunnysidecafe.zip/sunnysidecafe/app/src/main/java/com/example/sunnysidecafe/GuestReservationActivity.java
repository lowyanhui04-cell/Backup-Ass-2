package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class GuestReservationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_reservation_hub_screen);

        View btnViewReservation = findViewById(R.id.btn_view_reservation);
        if (btnViewReservation != null) {
            btnViewReservation.setOnClickListener(v -> {
                Intent intent = new Intent(GuestReservationActivity.this, GuestReservationListActivity.class);
                startActivity(intent);
            });
        }

        View btnMakeReservation = findViewById(R.id.btn_make_reservation);
        if (btnMakeReservation != null) {
            btnMakeReservation.setOnClickListener(v -> {
                Intent intent = new Intent(GuestReservationActivity.this, GuestReservationDetailsActivity.class);
                startActivity(intent);
            });
        }

        View btnBack = findViewById(R.id.btn_back);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }
    }
}
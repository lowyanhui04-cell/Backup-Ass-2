package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast; // Added for Toast
import androidx.appcompat.app.AppCompatActivity;

public class GuestReservationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_reservation_hub_screen);

        // --- Back Button ---
        ImageButton btnBack = findViewById(R.id.btn_back);
        btnBack.setOnClickListener(v -> finish()); // Closes this screen and goes back

        // --- View My Reservation ---
        Button btnViewReservation = findViewById(R.id.btn_view_reservation);
        btnViewReservation.setOnClickListener(v -> {
            // Navigate to Reservation List
            // Intent intent = new Intent(GuestReservationActivity.this, GuestReservationListActivity.class);
            // startActivity(intent);
        });

        // --- Make New Reservation ---
        Button btnMakeReservation = findViewById(R.id.btn_make_reservation);
        btnMakeReservation.setOnClickListener(v -> {
            // --- COMBINED BOOKING LOGIC START ---

            // Note: In a full app, you'd get these from EditTexts.
            // Using placeholder values to match your logic:
            String name = "Guest User";
            String date = "2023-12-25";
            String time = "18:00";

            // 1. Insert into SQLite
            DatabaseHelper db = new DatabaseHelper(GuestReservationActivity.this);
            boolean success = db.insertReservation(name, date, time, 2, "Indoor");

            if (success) {
                Toast.makeText(GuestReservationActivity.this, "Reservation Sent!", Toast.LENGTH_SHORT).show();

                // 2. Send Notification
                NotificationUtils.createNotificationChannel(GuestReservationActivity.this);
                NotificationUtils.sendNotification(GuestReservationActivity.this,
                        "Reservation Received", "Your booking for " + date + " is Pending approval.");

                // Keep the original intent logic here if you want to navigate after booking
                // Intent intent = new Intent(GuestReservationActivity.this, GuestNewReservationActivity.class);
                // startActivity(intent);
            } else {
                Toast.makeText(GuestReservationActivity.this, "Booking Failed", Toast.LENGTH_SHORT).show();
            }

            // --- COMBINED BOOKING LOGIC END ---
        });
    }
}
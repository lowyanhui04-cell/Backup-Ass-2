package com.example.sunnysidecafe;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class StaffSettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.staff_settings_screen);

        // --- Back Button ---
        ImageView btnBack = findViewById(R.id.btnBack);
        if(btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // --- 1. Account Button Logic ---
        View btnAccount = findViewById(R.id.btnAccount);
        if(btnAccount != null) {
            btnAccount.setOnClickListener(v -> {
                Intent intent = new Intent(StaffSettingsActivity.this, StaffAccountActivity.class);
                startActivity(intent);
            });
        }

        // --- 2. Notification Button Logic ---
        View btnNotifications = findViewById(R.id.btnNotifications);
        if(btnNotifications != null) {
            btnNotifications.setOnClickListener(v -> {
                Intent intent = new Intent(StaffSettingsActivity.this, StaffSettingsNotifActivity.class);
                startActivity(intent);
            });
        }

        // --- 3. Appearance Button Logic ---
        View btnAppearance = findViewById(R.id.btnAppearance);
        if(btnAppearance != null) {
            btnAppearance.setOnClickListener(v -> {
                Intent intent = new Intent(StaffSettingsActivity.this, StaffSettingsAppearanceActivity.class);
                startActivity(intent);
            });
        }

        // --- 4. Log Out Logic ---
        View btnLogOut = findViewById(R.id.btnLogOut);
        if(btnLogOut != null) {
            btnLogOut.setOnClickListener(v -> showLogoutDialog());
        }

        // --- Bottom Navigation ---
        setupBottomNav();
    }

    private void showLogoutDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_logout_screen);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }

        // Note: XML uses AppCompatButton but Button is the parent class, so this cast works fine
        Button btnCancel = dialog.findViewById(R.id.btnCancel);
        Button btnLogout = dialog.findViewById(R.id.btnLogout);

        if(btnCancel != null) btnCancel.setOnClickListener(v -> dialog.dismiss());

        if(btnLogout != null) btnLogout.setOnClickListener(v -> {
            dialog.dismiss();
            Toast.makeText(this, "Logged Out", Toast.LENGTH_SHORT).show();
            // Clear stack and go to Login
            Intent intent = new Intent(StaffSettingsActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        dialog.show();
    }

    private void setupBottomNav() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, StaffMenuActivity.class)));
        if (navReservation != null) navReservation.setOnClickListener(v -> startActivity(new Intent(this, StaffReservationActivity.class)));
        if (navNotification != null) navNotification.setOnClickListener(v -> startActivity(new Intent(this, StaffNotificationActivity.class)));
        // Current Screen is Settings
        if (navSettings != null) navSettings.setOnClickListener(v -> Toast.makeText(this, "You are in Settings", Toast.LENGTH_SHORT).show());
    }
}
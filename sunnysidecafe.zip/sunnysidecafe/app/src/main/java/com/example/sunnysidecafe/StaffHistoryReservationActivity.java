package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
//import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class StaffHistoryReservationActivity extends AppCompatActivity {

    // Header & Navigation
    private ImageView btnBack;
    private LinearLayout navMenu, navReservation, navNotification;
    //navSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.staff_history_reservation_screen); // Ensure this matches your XML filename

        initializeViews();
        setupListeners();
    }

    private void initializeViews() {
        // FIX: Changed R.id.btn_back_history to R.id.btnBack
        btnBack = findViewById(R.id.btnBack);

        // Remove RecyclerView line if your XML is static (doesn't have <RecyclerView>)
        // recyclerView = findViewById(R.id.recycler_history);

        // Bottom Navigation
        LinearLayout bottomNav = findViewById(R.id.bottomNavContainer);
        if (bottomNav != null) {
            navMenu = (LinearLayout) bottomNav.getChildAt(0);
            navReservation = (LinearLayout) bottomNav.getChildAt(1);
            navNotification = (LinearLayout) bottomNav.getChildAt(2);
            //navSettings = (LinearLayout) bottomNav.getChildAt(3);
        }
    }

    private void setupListeners() {
        // Back Button
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // Bottom Navigation Logic
        if (navMenu != null) {
            navMenu.setOnClickListener(v -> {
                startActivity(new Intent(this, StaffMenuActivity.class));
                overridePendingTransition(0, 0);
                finish();
            });
        }

        if (navReservation != null) {
            navReservation.setOnClickListener(v -> {
                startActivity(new Intent(this, StaffReservationActivity.class));
                overridePendingTransition(0, 0);
                finish();
            });
        }

        if (navNotification != null) {
            navNotification.setOnClickListener(v -> {
                startActivity(new Intent(this, StaffNotificationActivity.class));
                overridePendingTransition(0, 0);
                finish();
            });
        }

        //if (navSettings != null) {
            //navSettings.setOnClickListener(v -> {
                //startActivity(new Intent(this, StaffSettingsScreen.class));
                //overridePendingTransition(0, 0);
                //finish();
           // });
        //}
    }
}
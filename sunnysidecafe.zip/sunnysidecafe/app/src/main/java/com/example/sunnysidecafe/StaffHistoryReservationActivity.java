package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class StaffHistoryReservationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Make sure this points to your history layout
        setContentView(R.layout.staff_history_reservation_screen);

        // --- Back Button ---
        ImageView btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // --- TAB NAVIGATION LOGIC ---
        LinearLayout tabContainer = findViewById(R.id.tabContainer);
        if (tabContainer != null) {
            // Get the first child (Upcoming Tab)
            View tabUpcoming = tabContainer.getChildAt(0);

            tabUpcoming.setOnClickListener(v -> {
                // Go back to Upcoming (Reservation List)
                Intent intent = new Intent(StaffHistoryReservationActivity.this, StaffReservationActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
            });
        }

        setupBottomNav();
    }

    private void setupBottomNav() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, StaffMenuActivity.class)));
        // navReservation is current context (Reservation/History)
        if (navNotification != null) navNotification.setOnClickListener(v -> startActivity(new Intent(this, StaffNotificationActivity.class)));
        if (navSettings != null) navSettings.setOnClickListener(v -> startActivity(new Intent(this, StaffSettingsActivity.class)));
    }
}
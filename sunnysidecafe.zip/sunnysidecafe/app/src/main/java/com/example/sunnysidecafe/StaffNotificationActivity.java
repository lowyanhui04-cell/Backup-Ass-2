package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class StaffNotificationActivity extends AppCompatActivity {

    // Bottom Navigation
    private LinearLayout navMenu, navReservation, navNotification, navSettings;

    // Header & Actions
    private ImageView btnBack;
    private TextView btnClearAll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.staff_notification_screen);

        initializeViews();
        setupNavigation();
        setupActions();
    }

    private void initializeViews() {
        // 1. Bottom Navigation - Linking to IDs defined in your XML
        navMenu = findViewById(R.id.nav_btn_menu);
        navReservation = findViewById(R.id.nav_btn_reservation);
        navNotification = findViewById(R.id.nav_btn_notification);
        navSettings = findViewById(R.id.nav_btn_settings); // FIXED: Variable is now active

        // 2. Header & Actions
        btnBack = findViewById(R.id.btnBack);

        // Optional: If you have a clear button in XML, uncomment this
        // btnClearAll = findViewById(R.id.tvClearAll);
    }

    private void setupNavigation() {
        // Back Button
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // Bottom Nav Actions
        if (navMenu != null) {
            navMenu.setOnClickListener(v -> {
                startActivity(new Intent(this, StaffMenuActivity.class));
                overridePendingTransition(0, 0);
            });
        }

        if (navReservation != null) {
            navReservation.setOnClickListener(v -> {
                startActivity(new Intent(this, StaffReservationActivity.class));
                overridePendingTransition(0, 0);
            });
        }

        if (navNotification != null) {
            navNotification.setOnClickListener(v -> {
                // Already on Notification screen
                Toast.makeText(this, "You are here", Toast.LENGTH_SHORT).show();
            });
        }

        // FIXED: This now works because navSettings is declared
        if (navSettings != null) {
            navSettings.setOnClickListener(v -> {
                startActivity(new Intent(this, StaffSettingsActivity.class));
                overridePendingTransition(0, 0);
            });
        }
    }

    private void setupActions() {
        if (btnClearAll != null) {
            btnClearAll.setOnClickListener(v -> {
                Toast.makeText(this, "All notifications cleared", Toast.LENGTH_SHORT).show();
            });
        }
    }
}
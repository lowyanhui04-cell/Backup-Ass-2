package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class StaffNotificationActivity extends AppCompatActivity {

    // Bottom Navigation
    private LinearLayout navMenu, navReservation, navNotification;
    //navSettings;

    // Header & Actions
    private ImageView btnBack;
    private TextView btnClearAll;

    // Optional: If you want to make specific notifications clickable
    // private LinearLayout notifItem1, notifItem2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.staff_notification_screen); // Ensure this matches your XML filename

        initializeViews();
        setupNavigation();
        setupActions();
    }

    private void initializeViews() {
        // 1. Bottom Navigation
        LinearLayout bottomNav = findViewById(R.id.bottomNavContainer);
        navMenu = (LinearLayout) bottomNav.getChildAt(0);
        navReservation = (LinearLayout) bottomNav.getChildAt(1);
        navNotification = (LinearLayout) bottomNav.getChildAt(2);
        //navSettings = (LinearLayout) bottomNav.getChildAt(3);

        // 2. Header & Actions
        btnBack = findViewById(R.id.btnBack);

        // Ensure you have an ID for "Clear All" in your XML, e.g., android:id="@+id/tvClearAll"
        // If not, you can remove this line.
        //btnClearAll = findViewById(R.id.tvClearAll);
    }

    private void setupNavigation() {
        // Back Button
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // Bottom Nav Actions
        navMenu.setOnClickListener(v -> {
            startActivity(new Intent(this, StaffMenuActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });

        navReservation.setOnClickListener(v -> {
            startActivity(new Intent(this, StaffReservationActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });

        navNotification.setOnClickListener(v -> {
            // Already here, do nothing
        });

        //navSettings.setOnClickListener(v -> {
            //startActivity(new Intent(this, StaffSettingsScreen.class));
            //overridePendingTransition(0, 0);
            //finish();
        //});
    }

    private void setupActions() {
        // Clear All Button Logic
        if (btnClearAll != null) {
            btnClearAll.setOnClickListener(v -> {
                Toast.makeText(this, "All notifications cleared", Toast.LENGTH_SHORT).show();
                // In a real app, this would hide the list items.
                // For now, it just shows a toast.
            });
        }
    }
}
package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView; // Updated type
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class GuestReservationDetailsActivity extends AppCompatActivity {

    private int peopleCount = 2; // Default count

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Correct XML: The one with Calendar and People Selector
        setContentView(R.layout.guest_reservation_details_screen);

        // 1. Back Button
        ImageView btnBack = findViewById(R.id.btn_back);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // 2. People Counter Logic
        View btnMinus = findViewById(R.id.btn_minus);
        View btnPlus = findViewById(R.id.btn_plus);
        TextView tvPeopleCount = findViewById(R.id.tv_people_count);

        if (btnMinus != null) {
            btnMinus.setOnClickListener(v -> {
                if (peopleCount > 1) {
                    peopleCount--;
                    tvPeopleCount.setText(String.valueOf(peopleCount));
                }
            });
        }

        if (btnPlus != null) {
            btnPlus.setOnClickListener(v -> {
                if (peopleCount < 20) {
                    peopleCount++;
                    tvPeopleCount.setText(String.valueOf(peopleCount));
                }
            });
        }

        // 3. Next Button -> GO TO TIME SCREEN
        // We removed the time check here because this screen is for Details, not Time.
        View btnNext = findViewById(R.id.btn_next);
        if (btnNext != null) {
            btnNext.setOnClickListener(v -> {
                Intent intent = new Intent(GuestReservationDetailsActivity.this, GuestReservationTimeActivity.class);
                // Optional: Pass the people count to the next screen
                intent.putExtra("PEOPLE_COUNT", peopleCount);
                startActivity(intent);
            });
        }

        setupBottomNavigation();
    }

    private void setupBottomNavigation() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, GuestMenuActivity.class)));
        if (navReservation != null) navReservation.setOnClickListener(v -> startActivity(new Intent(this, GuestReservationActivity.class)));
        if (navNotification != null) navNotification.setOnClickListener(v -> startActivity(new Intent(this, GuestNotificationActivity.class)));
        if (navSettings != null) navSettings.setOnClickListener(v -> startActivity(new Intent(this, GuestSettingsActivity.class)));
    }
}
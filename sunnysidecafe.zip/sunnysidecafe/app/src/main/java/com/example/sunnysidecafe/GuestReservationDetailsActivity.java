package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GuestReservationDetailsActivity extends AppCompatActivity {

    private int numberOfPeople = 2; // Default value from design
    private TextView tvPeopleCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_reservation_details_screen);

        // --- Header Navigation ---
        ImageView btnBack = findViewById(R.id.btn_back);
        btnBack.setOnClickListener(v -> finish());

        // --- Tabs Logic (Visual only for this screen) ---
        TextView tabTime = findViewById(R.id.tab_time);
        TextView tabTable = findViewById(R.id.tab_table);

        tabTime.setOnClickListener(v -> {
            // Intent to Time Selection Screen
            Toast.makeText(this, "Go to Time Selection", Toast.LENGTH_SHORT).show();
        });

        // --- Number of People Logic ---
        tvPeopleCount = findViewById(R.id.tv_people_count);
        View btnMinus = findViewById(R.id.btn_minus);
        View btnPlus = findViewById(R.id.btn_plus);

        btnMinus.setOnClickListener(v -> {
            if (numberOfPeople > 1) {
                numberOfPeople--;
                updatePeopleCount();
            }
        });

        btnPlus.setOnClickListener(v -> {
            if (numberOfPeople < 20) {
                numberOfPeople++;
                updatePeopleCount();
            }
        });

        // --- Next Button ---
        View btnNext = findViewById(R.id.btn_next);
        btnNext.setOnClickListener(v -> {
            // Proceed to next step (Time or Confirmation)
            Toast.makeText(this, "Next: " + numberOfPeople + " people selected", Toast.LENGTH_SHORT).show();
            // Intent intent = new Intent(this, GuestReservationTimeActivity.class);
            // startActivity(intent);
        });

        // --- Bottom Navigation ---
        setupBottomNav();
    }

    private void updatePeopleCount() {
        tvPeopleCount.setText(String.valueOf(numberOfPeople));
    }

    private void setupBottomNav() {
        LinearLayout navMenu = findViewById(R.id.nav_btn_menu);
        LinearLayout navReservation = findViewById(R.id.nav_btn_reservation);

        navMenu.setOnClickListener(v -> {
            Intent intent = new Intent(this, GuestMenuActivity.class);
            startActivity(intent);
        });

        // Current screen is Reservation, no action needed or toast
        navReservation.setOnClickListener(v -> Toast.makeText(this, "You are in Reservation", Toast.LENGTH_SHORT).show());
    }
}
package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class StaffAccountActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.staff_account_screen);

        // --- Back Button ---
        ImageView btnBack = findViewById(R.id.btnBack);
        if(btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // --- Other Menu Buttons (Navigation) ---
        // Since you used the same layout structure as Settings, re-bind listeners to navigate back to specific pages

        // Account is current screen (expanded view)

        View btnNotifications = findViewById(R.id.btnNotifications);
        if(btnNotifications != null) {
            btnNotifications.setOnClickListener(v -> startActivity(new Intent(this, StaffSettingsNotifActivity.class)));
        }

        View btnAppearance = findViewById(R.id.btnAppearance);
        if(btnAppearance != null) {
            btnAppearance.setOnClickListener(v -> startActivity(new Intent(this, StaffSettingsAppearanceActivity.class)));
        }

        View btnLogOut = findViewById(R.id.btnLogOut);
        if(btnLogOut != null) {
            // Re-use logic or just redirect to main settings for logout
            btnLogOut.setOnClickListener(v -> {
                Intent intent = new Intent(this, StaffSettingsActivity.class);
                // Assuming you might want to trigger logout immediately or just go back
                startActivity(intent);
            });
        }

        // --- Edit Profile Button ---
        Button btnEditProfile = findViewById(R.id.btnEditProfile);
        if(btnEditProfile != null) {
            btnEditProfile.setOnClickListener(v -> {
                Intent intent = new Intent(StaffAccountActivity.this, StaffEditProfileActivity.class);
                startActivity(intent);
            });
        }

        setupBottomNav();
    }

    // Standard Bottom Nav Setup
    private void setupBottomNav() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if(navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, StaffMenuActivity.class)));
        if(navReservation != null) navReservation.setOnClickListener(v -> startActivity(new Intent(this, StaffReservationActivity.class)));
        if(navNotification != null) navNotification.setOnClickListener(v -> startActivity(new Intent(this, StaffNotificationActivity.class)));
        if(navSettings != null) navSettings.setOnClickListener(v -> startActivity(new Intent(this, StaffSettingsActivity.class)));
    }
}
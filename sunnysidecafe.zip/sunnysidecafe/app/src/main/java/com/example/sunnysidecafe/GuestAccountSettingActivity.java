package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class GuestAccountSettingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_account_screen);

        ImageView btnBack = findViewById(R.id.btn_back_arrow);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        View btnEditProfile = findViewById(R.id.btnEditProfile);
        if (btnEditProfile != null) {
            btnEditProfile.setOnClickListener(v -> {
                Intent intent = new Intent(GuestAccountSettingActivity.this, GuestEditProfileActivity.class);
                startActivity(intent);
            });
        }

        setupBottomNavigation();
    }

    private void setupBottomNavigation() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) {
            navMenu.setOnClickListener(v -> startActivity(new Intent(this, GuestMenuActivity.class)));
        }
        if (navReservation != null) {
            navReservation.setOnClickListener(v -> startActivity(new Intent(this, GuestReservationActivity.class)));
        }
        if (navNotification != null) {
            navNotification.setOnClickListener(v -> startActivity(new Intent(this, GuestNotificationActivity.class)));
        }
        if (navSettings != null) {
            navSettings.setOnClickListener(v -> startActivity(new Intent(this, GuestSettingsActivity.class)));
        }
    }
}
package com.example.sunnysidecafe;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GuestAccountSettingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Ensure this layout name matches your XML file name
        setContentView(R.layout.guest_account_screen);

        // --- Back Button ---
        ImageView btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // --- Edit Profile Button ---
        // ID from XML: btnEditProfile
        Button btnEditProfile = findViewById(R.id.btnEditProfile);
        if (btnEditProfile != null) {
            btnEditProfile.setOnClickListener(v -> {
                Intent intent = new Intent(GuestAccountSettingActivity.this, GuestEditProfileActivity.class);
                startActivity(intent);
            });
        }

        // --- Notifications Option ---
        // ID from XML: btnNotifications
        View btnNotifications = findViewById(R.id.btnNotifications);
        if (btnNotifications != null) {
            btnNotifications.setOnClickListener(v -> {
                // Navigate to Notification Settings (GuestSettingsNotifActivity)
                Intent intent = new Intent(GuestAccountSettingActivity.this, GuestNotifSettingActivity.class);
                startActivity(intent);
            });
        }

        // --- Appearance Option ---
        // ID from XML: btnAppearance
        View btnAppearance = findViewById(R.id.btnAppearance);
        if (btnAppearance != null) {
            btnAppearance.setOnClickListener(v -> {
                // Navigate to Appearance Settings (assuming class exists, or show toast)
                // Intent intent = new Intent(GuestAccountSettingActivity.this, GuestSettingsAppearanceActivity.class);
                // startActivity(intent);
                Toast.makeText(this, "Appearance Settings", Toast.LENGTH_SHORT).show();
            });
        }

        // --- Log Out Option ---
        // ID from XML: btnLogOut
        View btnLogOut = findViewById(R.id.btnLogOut);
        if (btnLogOut != null) {
            btnLogOut.setOnClickListener(v -> showLogoutDialog());
        }

        setupBottomNav();
    }

    private void showLogoutDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        // Ensure this matches your dialog XML file name (e.g., layout_dialog_logout_screen.xml)
        dialog.setContentView(R.layout.dialog_logout_screen);

        // Make background transparent for rounded corners
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }

        // Find buttons in the dialog layout
        // Check your dialog XML for these IDs (usually btnCancel and btnLogout)
        Button btnCancel = dialog.findViewById(R.id.btnCancel);
        Button btnLogout = dialog.findViewById(R.id.btnLogout);

        if (btnCancel != null) {
            btnCancel.setOnClickListener(v -> dialog.dismiss());
        }

        if (btnLogout != null) {
            btnLogout.setOnClickListener(v -> {
                dialog.dismiss();
                Toast.makeText(this, "Logged Out Successfully", Toast.LENGTH_SHORT).show();

                // Navigate to Login Screen and clear stack
                Intent intent = new Intent(this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            });
        }

        dialog.show();
    }

    private void setupBottomNav() {
        // IMPORTANT: You must add these IDs (android:id="@+id/...") to the
        // 4 LinearLayouts inside 'bottomNavContainer' in your XML for this to work.
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) {
            navMenu.setOnClickListener(v -> {
                startActivity(new Intent(this, GuestMenuActivity.class));
                overridePendingTransition(0, 0);
            });
        }
        if (navReservation != null) {
            navReservation.setOnClickListener(v -> {
                startActivity(new Intent(this, GuestReservationListActivity.class));
                overridePendingTransition(0, 0);
            });
        }
        if (navNotification != null) {
            navNotification.setOnClickListener(v -> {
                startActivity(new Intent(this, GuestNotificationActivity.class));
                overridePendingTransition(0, 0);
            });
        }
        if (navSettings != null) {
            navSettings.setOnClickListener(v -> {
                // If we are already in an Account Setting page, clicking Settings
                // typically goes back to the main Settings list
                startActivity(new Intent(this, GuestSettingsActivity.class));
                overridePendingTransition(0, 0);
            });
        }
    }
}
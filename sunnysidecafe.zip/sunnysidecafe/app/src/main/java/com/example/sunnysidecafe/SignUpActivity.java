package com.example.sunnysidecafe;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SignUpActivity extends AppCompatActivity {

    private boolean isPasswordVisible = false;
    private boolean isConfirmVisible = false;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );

        setContentView(R.layout.signup_screen);

        // Initialize Views
        TextView tvLogIn = findViewById(R.id.tvLogIn);
        Button btnCreateAccount = findViewById(R.id.btnCreateAccount);
        EditText etName = findViewById(R.id.etName);
        EditText etEmail = findViewById(R.id.etEmail);
        EditText etPassword = findViewById(R.id.etPassword);
        EditText etConfirmPassword = findViewById(R.id.etConfirmPassword);

        // Underline "Log In"
        tvLogIn.setPaintFlags(tvLogIn.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

        // --- PASSWORD VISIBILITY TOGGLE (Main Password) ---
        setupPasswordToggle(etPassword, true);

        // --- PASSWORD VISIBILITY TOGGLE (Confirm Password) ---
        setupPasswordToggle(etConfirmPassword, false);

        // Create Account Button Click
        btnCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString();
                String email = etEmail.getText().toString();
                String pass = etPassword.getText().toString();
                String confirm = etConfirmPassword.getText().toString();

                if(name.isEmpty() || email.isEmpty() || pass.isEmpty()) {
                    Toast.makeText(SignUpActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                } else if (!pass.equals(confirm)) {
                    Toast.makeText(SignUpActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SignUpActivity.this, "Account Created!", Toast.LENGTH_SHORT).show();
                    // Navigate to Login or Home
                    finish();
                }
            }
        });

        // "Log In" text click -> Go back to Login Activity
        tvLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Since we are likely coming from Login, we can just finish() to go back
                // Or launch intent explicitly:
                Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }

    // Helper method to handle eye icon logic for any EditText
    @SuppressLint("ClickableViewAccessibility")
    private void setupPasswordToggle(EditText editText, boolean isMainPassword) {
        editText.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                final int DRAWABLE_RIGHT = 2;
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (event.getRawX() >= (editText.getRight() - editText.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width())) {

                        boolean currentVisibility = isMainPassword ? isPasswordVisible : isConfirmVisible;

                        if (currentVisibility) {
                            editText.setTransformationMethod(PasswordTransformationMethod.getInstance());
                            if(isMainPassword) isPasswordVisible = false; else isConfirmVisible = false;
                        } else {
                            editText.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                            if(isMainPassword) isPasswordVisible = true; else isConfirmVisible = true;
                        }
                        return true;
                    }
                }
                return false;
            }
        });
    }
}
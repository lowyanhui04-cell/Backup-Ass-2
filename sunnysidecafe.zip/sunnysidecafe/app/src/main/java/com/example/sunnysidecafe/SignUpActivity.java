package com.example.sunnysidecafe;

import android.annotation.SuppressLint;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat; // Import needed for ContextCompat

public class SignUpActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;

    // Track visibility for both fields
    private boolean isPassVisible = false;
    private boolean isConfirmVisible = false;

    // Define the icon size you want (in dp)
    private static final int ICON_SIZE_DP = 20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup_screen);

        dbHelper = new DatabaseHelper(this);

        // Initialize Views
        EditText etName = findViewById(R.id.etName);
        EditText etEmail = findViewById(R.id.etEmail);
        EditText etPassword = findViewById(R.id.etPassword);
        EditText etConfirm = findViewById(R.id.etConfirmPassword);
        Button btnCreate = findViewById(R.id.btnCreateAccount);
        TextView tvLogin = findViewById(R.id.tvLogIn);

        // 1. SETUP TOGGLES
        // Initialize them with the correct "Secure" icon and correct SIZE immediately
        updatePasswordIcon(etPassword, false);
        updatePasswordIcon(etConfirm, false);

        setupPasswordToggle(etPassword, true);
        setupPasswordToggle(etConfirm, false);

        tvLogin.setOnClickListener(v -> finish());

        btnCreate.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String email = etEmail.getText().toString();
            String pass = etPassword.getText().toString();
            String confirm = etConfirm.getText().toString();

            if (name.isEmpty() || email.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else if (!pass.equals(confirm)) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            } else {
                if (dbHelper.registerUser(name, email, pass, "staff")) {
                    Toast.makeText(this, "Account Created", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(this, "Registration Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupPasswordToggle(EditText editText, boolean isMainPassword) {
        editText.setOnTouchListener((v, event) -> {
            final int DRAWABLE_RIGHT = 2;

            // Check if drawable exists to prevent crash
            if(editText.getCompoundDrawables()[DRAWABLE_RIGHT] == null) return false;

            if (event.getAction() == MotionEvent.ACTION_UP) {
                // FIXED LOGIC: Detect click on the right drawable
                if (event.getX() >= (editText.getWidth() - editText.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width() - editText.getPaddingRight())) {

                    int selection = editText.getSelectionEnd(); // Save cursor position
                    boolean currentlyVisible = isMainPassword ? isPassVisible : isConfirmVisible;

                    if (currentlyVisible) {
                        // Hide Password
                        editText.setTransformationMethod(PasswordTransformationMethod.getInstance());
                        if (isMainPassword) isPassVisible = false; else isConfirmVisible = false;

                        // Set icon to "Secure" (Closed Eye) and RESIZE it
                        updatePasswordIcon(editText, false);
                    } else {
                        // Show Password
                        editText.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                        if (isMainPassword) isPassVisible = true; else isConfirmVisible = true;

                        // Set icon to "Visible" (Open Eye) and RESIZE it
                        updatePasswordIcon(editText, true);
                    }

                    editText.setSelection(selection); // Restore cursor position
                    v.performClick();
                    return true;
                }
            }
            return false;
        });
    }

    /**
     * Helper method to resize the icon and set it to the EditText
     * @param editText The field to update
     * @param isVisible The state (true = show eye, false = show crossed eye)
     */
    private void updatePasswordIcon(EditText editText, boolean isVisible) {
        int drawableId = isVisible ? R.drawable.input_field_password_icon : R.drawable.secure_password_icon;

        Drawable drawable = ContextCompat.getDrawable(this, drawableId);

        if (drawable != null) {
            // Calculate pixels from DP (so it looks the same on all screens)
            int sizePx = (int) TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP,
                    ICON_SIZE_DP,
                    getResources().getDisplayMetrics()
            );

            // Manually set the size (Bounds)
            drawable.setBounds(0, 0, sizePx, sizePx);

            // Set the drawable (Left, Top, Right, Bottom)
            editText.setCompoundDrawables(null, null, drawable, null);
        }
    }
}
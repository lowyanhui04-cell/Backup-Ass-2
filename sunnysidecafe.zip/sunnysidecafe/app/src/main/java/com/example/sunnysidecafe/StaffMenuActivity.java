package com.example.sunnysidecafe;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class StaffMenuActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    // Helper class to group your XML views together
    private class MenuCard {
        View cardView; // The parent CardView (found via parent of image)
        ImageView img, btnEdit, btnDelete;
        TextView title, price;
        int databaseId = -1; // To track which DB item is in this slot

        public MenuCard(ImageView img, TextView title, TextView price, ImageView btnEdit, ImageView btnDelete) {
            this.img = img;
            this.title = title;
            this.price = price;
            this.btnEdit = btnEdit;
            this.btnDelete = btnDelete;
            // Traverse up to hide the whole card: Image -> Constraint -> CardView
            this.cardView = (View) img.getParent().getParent();
        }
    }

    private MenuCard[] cards;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.staff_menu_screen); // Your exact XML filename

        dbHelper = new DatabaseHelper(this);

        // Initialize the 3 static slots from your XML
        cards = new MenuCard[3];

        cards[0] = new MenuCard(
                findViewById(R.id.imgFood1), findViewById(R.id.tvTitle1), findViewById(R.id.tvPrice1),
                findViewById(R.id.btnEdit1), findViewById(R.id.btnDelete1));

        cards[1] = new MenuCard(
                findViewById(R.id.imgFood2), findViewById(R.id.tvTitle2), findViewById(R.id.tvPrice2),
                findViewById(R.id.btnEdit2), findViewById(R.id.btnDelete2));

        cards[2] = new MenuCard(
                findViewById(R.id.imgFood3), findViewById(R.id.tvTitle3), findViewById(R.id.tvPrice3),
                findViewById(R.id.btnEdit3), findViewById(R.id.btnDelete3));

        // Setup Add Button
        ImageButton fabAdd = findViewById(R.id.fabAdd);
        fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(StaffMenuActivity.this, ManageItemActivity.class);
            startActivity(intent);
        });

        // Setup Back Button
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadMenuItems(); // Refresh data every time we come back to this screen
    }

    private void loadMenuItems() {
        Cursor cursor = dbHelper.getAllMenuItems();

        int i = 0;
        if (cursor.moveToFirst()) {
            do {
                // If we have more items than slots (3), stop loading
                if (i >= 3) break;

                // Get Data
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                String price = cursor.getString(cursor.getColumnIndexOrThrow("price"));
                int imgRes = cursor.getInt(cursor.getColumnIndexOrThrow("image_res"));

                // Update the visual card
                MenuCard card = cards[i];
                card.cardView.setVisibility(View.VISIBLE); // Show card
                card.title.setText(name);
                card.price.setText(price);
                card.img.setImageResource(imgRes);
                card.databaseId = id;

                // Setup Buttons for this specific item
                card.btnEdit.setOnClickListener(v -> {
                    Intent intent = new Intent(StaffMenuActivity.this, ManageItemActivity.class);
                    intent.putExtra("ID", id);
                    intent.putExtra("NAME", name);
                    intent.putExtra("PRICE", price);
                    startActivity(intent);
                });

                card.btnDelete.setOnClickListener(v -> {
                    new AlertDialog.Builder(this)
                            .setTitle("Delete Item")
                            .setMessage("Are you sure you want to delete " + name + "?")
                            .setPositiveButton("Yes", (dialog, which) -> {
                                dbHelper.deleteMenuItem(id);
                                loadMenuItems(); // Refresh UI
                                Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                            })
                            .setNegativeButton("No", null)
                            .show();
                });

                i++;
            } while (cursor.moveToNext());
        }

        // Hide unused cards (e.g., if DB has only 1 item, hide card 2 and 3)
        for (int j = i; j < 3; j++) {
            cards[j].cardView.setVisibility(View.GONE);
        }

        cursor.close();
    }
}
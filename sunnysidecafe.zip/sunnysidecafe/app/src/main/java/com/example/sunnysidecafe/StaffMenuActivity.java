package com.example.sunnysidecafe;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class StaffMenuActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private ImageButton fabAdd;

    // Item 1 Views
    private TextView tvTitle1, tvPrice1;
    private ImageView imgFood1, btnEdit1, btnDelete1;
    private int id1 = -1; // To store DB ID for item 1

    // Item 2 Views
    private TextView tvTitle2, tvPrice2;
    private ImageView imgFood2, btnEdit2, btnDelete2;
    private int id2 = -1;

    // Item 3 Views
    private TextView tvTitle3, tvPrice3;
    private ImageView imgFood3, btnEdit3, btnDelete3;
    private int id3 = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.staff_menu_screen);

        dbHelper = new DatabaseHelper(this);

        // --- Initialize Views from your XML ---
        fabAdd = findViewById(R.id.fabAdd);

        // Item 1
        tvTitle1 = findViewById(R.id.tvTitle1);
        tvPrice1 = findViewById(R.id.tvPrice1);
        imgFood1 = findViewById(R.id.imgFood1);
        btnEdit1 = findViewById(R.id.btnEdit1);
        btnDelete1 = findViewById(R.id.btnDelete1);

        // Item 2
        tvTitle2 = findViewById(R.id.tvTitle2);
        tvPrice2 = findViewById(R.id.tvPrice2);
        imgFood2 = findViewById(R.id.imgFood2);
        btnEdit2 = findViewById(R.id.btnEdit2);
        btnDelete2 = findViewById(R.id.btnDelete2);

        // Item 3
        tvTitle3 = findViewById(R.id.tvTitle3);
        tvPrice3 = findViewById(R.id.tvPrice3);
        imgFood3 = findViewById(R.id.imgFood3);
        btnEdit3 = findViewById(R.id.btnEdit3);
        btnDelete3 = findViewById(R.id.btnDelete3);

        // --- Setup Buttons ---

        fabAdd.setOnClickListener(v -> {
            startActivity(new Intent(this, AddNewItemActivity.class));
        });

        // Edit Button Logic - Passes the ID to EditMenuActivity
        btnEdit1.setOnClickListener(v -> openEditScreen(id1));
        btnEdit2.setOnClickListener(v -> openEditScreen(id2));
        btnEdit3.setOnClickListener(v -> openEditScreen(id3));

        // Delete Button Logic
        btnDelete1.setOnClickListener(v -> deleteItem(id1));
        btnDelete2.setOnClickListener(v -> deleteItem(id2));
        btnDelete3.setOnClickListener(v -> deleteItem(id3));

        // Setup Bottom Nav (Basic redirection)
        setupBottomNav();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh data every time we come back to this screen
        loadMenuData();
    }

    private void openEditScreen(int id) {
        if (id != -1) {
            Intent intent = new Intent(StaffMenuActivity.this, EditMenuActivity.class);
            intent.putExtra("ITEM_ID", id);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Slot is empty", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteItem(int id) {
        if (id != -1) {
            dbHelper.deleteMenuItem(id);
            loadMenuData(); // Refresh UI
            Toast.makeText(this, "Item Deleted", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadMenuData() {
        Cursor cursor = dbHelper.getAllMenuItems();

        // Clear previous IDs to prevent editing deleted items
        id1 = id2 = id3 = -1;

        if (cursor != null && cursor.moveToFirst()) {
            // --- LOAD ROW 1 ---
            id1 = cursor.getInt(0); // ID column
            tvTitle1.setText(cursor.getString(1)); // Name
            tvPrice1.setText(cursor.getString(3)); // Price
            updateImage(imgFood1, cursor.getString(4));

            if (cursor.moveToNext()) {
                // --- LOAD ROW 2 ---
                id2 = cursor.getInt(0);
                tvTitle2.setText(cursor.getString(1));
                tvPrice2.setText(cursor.getString(3));
                updateImage(imgFood2, cursor.getString(4));
            } else {
                clearSlot(2); // No data for slot 2
            }

            if (cursor.moveToNext()) {
                // --- LOAD ROW 3 ---
                id3 = cursor.getInt(0);
                tvTitle3.setText(cursor.getString(1));
                tvPrice3.setText(cursor.getString(3));
                updateImage(imgFood3, cursor.getString(4));
            } else {
                clearSlot(3); // No data for slot 3
            }
        } else {
            // Empty Database
            clearSlot(1);
            clearSlot(2);
            clearSlot(3);
        }

        if(cursor != null) cursor.close();
    }

    private void updateImage(ImageView imgView, String uriStr) {
        if (uriStr != null && !uriStr.isEmpty()) {
            try {
                imgView.setImageURI(Uri.parse(uriStr));
            } catch (Exception e) {
                imgView.setImageResource(R.drawable.food_pineapple); // Default fallback
            }
        } else {
            imgView.setImageResource(R.drawable.food_pineapple); // Default
        }
    }

    private void clearSlot(int slotNumber) {
        // Optional: Hide the card or set text to "Empty" if no data exists
        if (slotNumber == 1) {
            tvTitle1.setText("Empty Slot");
            tvPrice1.setText("-");
            imgFood1.setImageResource(R.drawable.food_pineapple);
        } else if (slotNumber == 2) {
            tvTitle2.setText("Empty Slot");
            tvPrice2.setText("-");
            imgFood2.setImageResource(R.drawable.food_signature);
        } else if (slotNumber == 3) {
            tvTitle3.setText("Empty Slot");
            tvPrice3.setText("-");
            imgFood3.setImageResource(R.drawable.food_carbonara);
        }
    }

    private void setupBottomNav() {
        // You can add click listeners for your bottom nav containers here
        // E.g., findViewById(R.id.bottomNavContainer).getChildAt(1)...
        // For now leaving as is since you didn't ask for Nav logic specifically in this step.
    }
}
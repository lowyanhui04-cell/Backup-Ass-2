package com.example.sunnysidecafe;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LogoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // IMPORTANT: Ensure this is your main settings layout file name, NOT the dialog layout
        setContentView(R.layout.dialog_logout_screen);

        // --- Back Button Logic ---
        ImageView btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

        // --- Other Settings Buttons Logic (Optional Placeholders) ---
        View btnAccount = findViewById(R.id.btnAccount);
        btnAccount.setOnClickListener(v -> {
            // Intent to Account Activity
        });

        // --- Log Out Button Logic ---
        // Finding the ConstraintLayout container for the Log Out button
        View btnLogOut = findViewById(R.id.btnLogOut);

        btnLogOut.setOnClickListener(v -> showLogoutDialog());
    }

    private void showLogoutDialog() {
        // Create the dialog
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        // IMPORTANT: Inflate the XML code you provided above
        // Make sure your XML file is named 'layout_dialog_logout_screen.xml' in res/layout
        dialog.setContentView(R.layout.dialog_logout_screen);

        // Configure the dialog window to be transparent and full screen
        // This allows your XML's background="#99000000" to act as the dimming overlay
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }

        // Find buttons inside the dialog layout using the IDs from your XML
        // Note: Using 'AppCompatButton' in XML usually casts to 'Button' in Java
        Button btnCancel = dialog.findViewById(R.id.btnCancel);
        Button btnLogout = dialog.findViewById(R.id.btnLogout);

        // Handle Cancel Click
        btnCancel.setOnClickListener(v -> dialog.dismiss());

        // Handle Log Out Click
        btnLogout.setOnClickListener(v -> {
            dialog.dismiss();
            performLogout();
        });

        dialog.show();
    }

    private void performLogout() {
        Toast.makeText(this, "Logged Out Successfully", Toast.LENGTH_SHORT).show();

        // Navigate back to Login/Welcome Screen
        Intent intent = new Intent(LogoutActivity.this, LoginActivity.class);
        // Clear the back stack so the user cannot press "Back" to return to Settings
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
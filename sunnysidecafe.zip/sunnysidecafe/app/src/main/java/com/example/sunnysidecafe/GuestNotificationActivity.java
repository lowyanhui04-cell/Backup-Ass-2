package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GuestNotificationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_notification_screen);

        // --- Back Button ---
        ImageView btnBack = findViewById(R.id.btn_back_arrow);
        btnBack.setOnClickListener(v -> finish());

        // --- Mark all as read ---
        TextView tvMarkRead = findViewById(R.id.tv_mark_read);
        tvMarkRead.setOnClickListener(v -> {
            Toast.makeText(this, "All notifications marked as read", Toast.LENGTH_SHORT).show();
        });

        // --- Notification Item Clicks (Example) ---
        View notif1 = findViewById(R.id.notif_card_1);
        notif1.setOnClickListener(v -> Toast.makeText(this, "View reservation details", Toast.LENGTH_SHORT).show());

        // --- Bottom Navigation ---
        setupBottomNav();
    }

    private void setupBottomNav() {
        LinearLayout navMenu = findViewById(R.id.nav_btn_menu);
        LinearLayout navReservation = findViewById(R.id.nav_btn_reservation);
        LinearLayout navSettings = findViewById(R.id.nav_btn_settings);

        navMenu.setOnClickListener(v -> {
            Intent intent = new Intent(this, GuestMenuActivity.class);
            startActivity(intent);
        });

        navReservation.setOnClickListener(v -> {
            Intent intent = new Intent(this, GuestReservationListActivity.class);
            startActivity(intent);
        });

        navSettings.setOnClickListener(v -> {
            // Intent intent = new Intent(this, SettingsActivity.class);
            // startActivity(intent);
        });
    }
}
package com.example.sunnysidecafe;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.constraintlayout.widget.ConstraintLayout;

public class StaffReservationActivity extends AppCompatActivity {

    // UI Components
    private LinearLayout tabUpcoming, tabHistory;
    private TextView tvTabUpcoming, tvTabHistory;
    private View lineUpcoming, lineHistory;

    // Content Views
    private ConstraintLayout cardContainer; // The "Jane" card
    private TextView tvNoHistory;           // The "No History" text

    // Buttons
    private ImageView btnBack;
    private AppCompatButton btnViewDetails;

    // Bottom Navigation
    private LinearLayout navMenu, navReservation, navNotification;
    //navSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reservation_list_screen); // Ensure matches your XML filename

        initializeViews();
        setupListeners();

        // Default: Show Upcoming Tab
        selectUpcomingTab();
    }

    private void initializeViews() {
        // 1. Initialize Tabs (Traversing the tabContainer)
        LinearLayout tabContainer = findViewById(R.id.tabContainer);

        // Upcoming Tab (First child)
        tabUpcoming = (LinearLayout) tabContainer.getChildAt(0);
        tvTabUpcoming = (TextView) tabUpcoming.getChildAt(0);
        lineUpcoming = tabUpcoming.getChildAt(1);

        // History Tab (Second child)
        tabHistory = (LinearLayout) tabContainer.getChildAt(1);
        tvTabHistory = (TextView) tabHistory.getChildAt(0);
        lineHistory = tabHistory.getChildAt(1);

        // 2. Initialize Content
        cardContainer = findViewById(R.id.cardContainer); // Needs ID in XML (see note below)
        tvNoHistory = findViewById(R.id.tvNoHistory);     // Needs ID in XML
        btnBack = findViewById(R.id.btnBack);

        // We need to find the button inside the cardContainer or directly if ID is unique
        btnViewDetails = findViewById(R.id.btnViewDetails);

        // 3. Initialize Bottom Navigation
        LinearLayout bottomNav = findViewById(R.id.bottomNavContainer);
        navMenu = (LinearLayout) bottomNav.getChildAt(0);
        navReservation = (LinearLayout) bottomNav.getChildAt(1);
        navNotification = (LinearLayout) bottomNav.getChildAt(2);
        //navSettings = (LinearLayout) bottomNav.getChildAt(3);
    }

    private void setupListeners() {
        // Tab Clicks
        tabUpcoming.setOnClickListener(v -> selectUpcomingTab());
        tabHistory.setOnClickListener(v -> selectHistoryTab());

        // Header Back Button
        btnBack.setOnClickListener(v -> finish());

        // "View Details" Button
        btnViewDetails.setOnClickListener(v -> {
            // Navigate to Details Screen
            Intent intent = new Intent(StaffReservationActivity.this, StaffReservationDetailsActivity.class);
            startActivity(intent);
        });

        // Bottom Navigation Logic
        navMenu.setOnClickListener(v -> {
            Intent intent = new Intent(this, StaffMenuActivity.class);
            startActivity(intent);
            overridePendingTransition(0,0);
            finish();
        });

        navReservation.setOnClickListener(v -> {
            // Already on Reservation screen
        });

        navNotification.setOnClickListener(v -> {
            Intent intent = new Intent(this, StaffNotificationActivity.class);
            startActivity(intent);
            overridePendingTransition(0,0);
            finish();
        });

        //navSettings.setOnClickListener(v -> {
            //Intent intent = new Intent(this, StaffSettingsScreen.class);
           // startActivity(intent);
          //  overridePendingTransition(0,0);
          //  finish();
        //});
    }

    // Logic to switch to "Upcoming" view
    private void selectUpcomingTab() {
        // Colors: Gold (#9C8749) for Active, Black for Inactive
        tvTabUpcoming.setTextColor(Color.parseColor("#9C8749"));
        tvTabHistory.setTextColor(Color.BLACK);

        // Text Styles
        tvTabUpcoming.setTypeface(null, Typeface.BOLD);
        tvTabHistory.setTypeface(null, Typeface.NORMAL);

        // Lines
        lineUpcoming.setBackgroundResource(R.drawable.tab_indicator_rounded_gold);
        lineHistory.setBackgroundResource(R.drawable.tab_indicator_rounded_black);

        // Adjust Line Height (Gold is thicker)
        updateLineHeight(lineUpcoming, 5);
        updateLineHeight(lineHistory, 3);

        // Visibility
        if(cardContainer != null) cardContainer.setVisibility(View.VISIBLE);
        if(tvNoHistory != null) tvNoHistory.setVisibility(View.GONE);
    }

    // Logic to switch to "History" view
    private void selectHistoryTab() {
        tvTabUpcoming.setTextColor(Color.BLACK);
        tvTabHistory.setTextColor(Color.parseColor("#9C8749"));

        tvTabUpcoming.setTypeface(null, Typeface.NORMAL);
        tvTabHistory.setTypeface(null, Typeface.BOLD);

        lineUpcoming.setBackgroundResource(R.drawable.tab_indicator_rounded_black);
        lineHistory.setBackgroundResource(R.drawable.tab_indicator_rounded_gold);

        updateLineHeight(lineUpcoming, 3);
        updateLineHeight(lineHistory, 5);

        // Visibility
        if(cardContainer != null) cardContainer.setVisibility(View.GONE);
        if(tvNoHistory != null) tvNoHistory.setVisibility(View.VISIBLE);
    }

    private void updateLineHeight(View view, int dp) {
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) view.getLayoutParams();
        float density = getResources().getDisplayMetrics().density;
        params.height = Math.round(dp * density);
        view.setLayoutParams(params);
    }
}
package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class StaffReservationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reservation_list_screen);

        // --- Back Button ---
        ImageView btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // --- View Details Button ---
        Button btnViewDetails = findViewById(R.id.btnViewDetails);
        if (btnViewDetails != null) {
            btnViewDetails.setOnClickListener(v -> {
                Intent intent = new Intent(StaffReservationActivity.this, StaffReservationDetailsActivity.class);
                startActivity(intent);
            });
        }

        // --- LOGIC TO "DELETE" ITEM IF CANCELLED ---
        // Check if we came here from the details screen after a cancellation
        if (getIntent().getBooleanExtra("REFRESH_CANCELLED", false)) {
            if (btnViewDetails != null) {
                // Navigate up from the button to the ConstraintLayout, then to the CardView
                View parentLayout = (View) btnViewDetails.getParent(); // ConstraintLayout
                if (parentLayout != null) {
                    View cardView = (View) parentLayout.getParent(); // CardView
                    if (cardView != null) {
                        cardView.setVisibility(View.GONE); // Hide the card
                        Toast.makeText(this, "Reservation removed from list", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }

        // --- TAB NAVIGATION LOGIC ---
        LinearLayout tabContainer = findViewById(R.id.tabContainer);
        if (tabContainer != null) {
            View tabHistory = tabContainer.getChildAt(1);
            if (tabHistory != null) {
                tabHistory.setOnClickListener(v -> {
                    Intent intent = new Intent(StaffReservationActivity.this, StaffHistoryReservationActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                    startActivity(intent);
                });
            }
        }

        // --- Bottom Nav ---
        setupBottomNav();
    }

    private void setupBottomNav() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, StaffMenuActivity.class)));
        // Current screen is Reservation
        if (navNotification != null) navNotification.setOnClickListener(v -> startActivity(new Intent(this, StaffNotificationActivity.class)));
        if (navSettings != null) navSettings.setOnClickListener(v -> startActivity(new Intent(this, StaffSettingsActivity.class)));
    }
}
package com.example.sunnysidecafe;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class StaffReservationActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    // IDs from your staff reservation screen.xml
    private TextView tvName, tvDate, tvHeader;
    private Button btnViewDetails;
    private ImageView btnBack;
    private LinearLayout tabHistory;

    // We will store the ID of the reservation displayed on the card
    private int currentReservationId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Make sure this matches your actual XML filename (e.g., reservation_list_screen)
        setContentView(R.layout.reservation_list_screen);

        dbHelper = new DatabaseHelper(this);

        // --- 1. Bind Views to your XML IDs ---
        tvHeader = findViewById(R.id.tvHeader);
        tvName = findViewById(R.id.tvName);
        tvDate = findViewById(R.id.tvDate);
        btnViewDetails = findViewById(R.id.btnViewDetails);
        btnBack = findViewById(R.id.btnBack);

        // Tab Container Mapping (Child 1 is History)
        LinearLayout tabContainer = findViewById(R.id.tabContainer);
        if (tabContainer != null) {
            tabHistory = (LinearLayout) tabContainer.getChildAt(1);
        }

        // --- 2. Setup Listeners ---

        // Back Button
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // View Details Button
        if (btnViewDetails != null) {
            btnViewDetails.setOnClickListener(v -> {
                if (currentReservationId != -1) {
                    Intent intent = new Intent(StaffReservationActivity.this, StaffReservationDetailsActivity.class);
                    intent.putExtra("RES_ID", currentReservationId);
                    startActivity(intent);
                } else {
                    Toast.makeText(this, "No active reservation to view", Toast.LENGTH_SHORT).show();
                }
            });
        }

        // History Tab
        if (tabHistory != null) {
            tabHistory.setOnClickListener(v -> {
                Intent intent = new Intent(StaffReservationActivity.this, StaffHistoryReservationActivity.class);
                startActivity(intent);
                overridePendingTransition(0,0);
            });
        }

        setupBottomNav();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadLatestReservation();
    }

    private void loadLatestReservation() {
        // Fetch only active reservations
        Cursor cursor = dbHelper.reservation_details_screen();

        if (cursor != null && cursor.moveToFirst()) {
            // Get data from the first active reservation found
            currentReservationId = cursor.getInt(0); // ID
            String date = cursor.getString(1);
            String time = cursor.getString(2);
            String pax = cursor.getString(3);

            // Update the UI
            tvName.setText(pax + " Booking"); // Using Pax as name since DB has no name column
            tvDate.setText(date + " at " + time);

            btnViewDetails.setVisibility(View.VISIBLE);
        } else {
            // No reservations found
            currentReservationId = -1;
            tvName.setText("No Upcoming Reservations");
            tvDate.setText("-");
            btnViewDetails.setVisibility(View.INVISIBLE); // Hide button if empty
        }

        if (cursor != null) cursor.close();
    }

    private void setupBottomNav() {
        LinearLayout nav = findViewById(R.id.bottomNavContainer);
        if (nav != null) {
            // Child 0: Menu
            nav.getChildAt(0).setOnClickListener(v -> {
                startActivity(new Intent(this, StaffMenuActivity.class));
                overridePendingTransition(0, 0);
            });

            // Child 1: Reservation (Current) - Do nothing

            // Child 2: Notification
            nav.getChildAt(2).setOnClickListener(v -> {
                startActivity(new Intent(this, StaffNotificationActivity.class));
                overridePendingTransition(0, 0);
            });

            // Child 3: Settings (Optional)
        }
    }
}
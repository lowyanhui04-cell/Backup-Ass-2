package com.example.sunnysidecafe;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class LoginActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private boolean isPasswordVisible = false;

    // Define the icon size you want (in dp)
    private static final int ICON_SIZE_DP = 20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);

        dbHelper = new DatabaseHelper(this);
        EditText etEmail = findViewById(R.id.etEmail);
        EditText etPassword = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);
        TextView tvSignUp = findViewById(R.id.tvSignUp);

        // 1. SETUP PASSWORD TOGGLE
        // Initialize with the correct "Secure" icon and correct SIZE immediately
        updatePasswordIcon(etPassword, false);
        setupPasswordToggle(etPassword);

        tvSignUp.setOnClickListener(v -> startActivity(new Intent(LoginActivity.this, SignUpActivity.class)));

        btnLogin.setOnClickListener(v -> {
            String email = etEmail.getText().toString();
            String password = etPassword.getText().toString();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                if (dbHelper.checkUser(email, password)) {
                    Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this, StaffMenuActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(this, "Invalid Email or Password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupPasswordToggle(EditText editText) {
        editText.setOnTouchListener((v, event) -> {
            final int DRAWABLE_RIGHT = 2;

            // Safety check
            if(editText.getCompoundDrawables()[DRAWABLE_RIGHT] == null) return false;

            if (event.getAction() == MotionEvent.ACTION_UP) {
                // FIXED LOGIC: Consistent with SignUpActivity
                // Checks click position relative to the view width and padding
                if (event.getX() >= (editText.getWidth() - editText.getCompoundDrawables()[DRAWABLE_RIGHT].getBounds().width() - editText.getPaddingRight())) {

                    int selection = editText.getSelectionEnd(); // Keep cursor position

                    if (isPasswordVisible) {
                        // Hide Password
                        editText.setTransformationMethod(PasswordTransformationMethod.getInstance());
                        isPasswordVisible = false;

                        // Set icon to "Secure" and RESIZE
                        updatePasswordIcon(editText, false);
                    } else {
                        // Show Password
                        editText.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                        isPasswordVisible = true;

                        // Set icon to "Normal" and RESIZE
                        updatePasswordIcon(editText, true);
                    }

                    editText.setSelection(selection); // Restore cursor
                    v.performClick();
                    return true;
                }
            }
            return false;
        });
    }

    /**
     * Helper method to resize the icon and set it to the EditText
     * @param editText The field to update
     * @param isVisible The state (true = show eye, false = show crossed eye)
     */
    private void updatePasswordIcon(EditText editText, boolean isVisible) {
        int drawableId = isVisible ? R.drawable.input_field_password_icon : R.drawable.secure_password_icon;

        Drawable drawable = ContextCompat.getDrawable(this, drawableId);

        if (drawable != null) {
            // Calculate pixels from DP (so it looks the same on all screens)
            int sizePx = (int) TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP,
                    ICON_SIZE_DP,
                    getResources().getDisplayMetrics()
            );

            // Manually set the size (Bounds)
            drawable.setBounds(0, 0, sizePx, sizePx);

            // Set the drawable (Left, Top, Right, Bottom)
            editText.setCompoundDrawables(null, null, drawable, null);
        }
    }
}
package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private String userType;
    private DatabaseHelper databaseHelper; // Assumption: You have a DatabaseHelper class

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Matching your layout file: login_screen.xml
        setContentView(R.layout.login_screen);

        databaseHelper = new DatabaseHelper(this); // Initialize DB Helper

        // Retrieve user type ("guest" or "staff") passed from MainActivity
        userType = getIntent().getStringExtra("userType");

        // IDs from your XML: emailInput, passwordInput, loginButton, signupText
        EditText etUsername = findViewById(R.id.etEmail);
        EditText etPassword = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);
        TextView tvSignUp = findViewById(R.id.tvSignUp);

        // Login Button Logic
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                } else {
                    // Perform Login Check
                    if (checkCredentials(username, password)) {
                        // Success: Navigate based on User Type
                        if ("staff".equals(userType)) {
                            // Go to Staff Menu Screen
                            Intent intent = new Intent(LoginActivity.this, StaffMenuActivity.class);
                            startActivity(intent);
                        } else {
                            // Go to Guest Menu Screen (Default for Guest)
                            Intent intent = new Intent(LoginActivity.this, GuestMenuActivity.class);
                            startActivity(intent);
                        }
                        finish(); // Close LoginActivity so they can't go back
                    } else {
                        Toast.makeText(LoginActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // Sign Up / Create Account Logic
        tvSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
                // Pass userType to Sign Up so we know what kind of account to create
                intent.putExtra("userType", userType);
                startActivity(intent);
            }
        });
    }

    private boolean checkCredentials(String username, String password) {
        // TODO: Integrate with your DatabaseHelper here.
        // Example: return databaseHelper.checkUser(username, password);

        // Temporary Bypass for testing:
        // Returns true if username and password are not empty (Logic handled above)
        // You should implement: return databaseHelper.checkUser(username, password);
        return true;
    }
}
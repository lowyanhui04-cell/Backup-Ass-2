package com.example.sunnysidecafe;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView; // Import CardView

public class GuestReservationListActivity extends AppCompatActivity {

    // Declare the card view variable so we can hide it later
    private CardView cardReservation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_reservation_list_screen);

        // --- Find the Card View by ID ---
        // Ensure this ID matches your XML (card_reservation)
        cardReservation = findViewById(R.id.card_reservation);

        // 1. Back Button Logic
        View btnBack = findViewById(R.id.btn_back_arrow);
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        View tabHistory = findViewById(R.id.tab_history);
        if (tabHistory != null) {
            tabHistory.setOnClickListener(v -> {
                Intent intent = new Intent(GuestReservationListActivity.this, GuestHistoryReservationActivity.class);
                startActivity(intent);
                // Removes the animation to make it look like a tab switch
                overridePendingTransition(0, 0);
            });
        }

        // 2. Edit Button Logic
        View btnEdit = findViewById(R.id.btn_edit);
        if (btnEdit != null) {
            btnEdit.setOnClickListener(v -> showEditDialog());
        }

        // 3. Cancel Button Logic
        View btnCancel = findViewById(R.id.btn_cancel);
        if (btnCancel != null) btnCancel.setOnClickListener(v -> showCancelDialog());

        setupBottomNavigation();
    }

    // ===========================
    // CANCEL RESERVATION DIALOG
    // ===========================
    private void showCancelDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_cancel_reservation);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            dialog.getWindow().setGravity(Gravity.CENTER);
        }

        View btnYes = dialog.findViewById(R.id.btn_yes);
        View btnNo = dialog.findViewById(R.id.btn_no);

        // Handle "No"
        if (btnNo != null) {
            btnNo.setOnClickListener(v -> dialog.dismiss());
        }

        // Handle "Yes" (Confirm Cancel)
        if (btnYes != null) {
            btnYes.setOnClickListener(v -> {
                dialog.dismiss();

                // 1. Show message
                Toast.makeText(this, "Reservation Cancelled", Toast.LENGTH_SHORT).show();

                // 2. Hide the Card View (The card, text, and picture will disappear)
                if (cardReservation != null) {
                    cardReservation.setVisibility(View.GONE);
                }

                // 3. DO NOT call finish() so the user stays on this screen to see it disappear
            });
        }
        dialog.show();
    }

    // ===========================
    // EDIT DIALOG
    // ===========================
    private void showEditDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_edit_reservation);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            dialog.getWindow().setGravity(Gravity.BOTTOM);
        }

        ImageView btnClose = dialog.findViewById(R.id.btn_close_dialog);
        Button btnUpdate = dialog.findViewById(R.id.btn_update_reservation);
        View btnMinus = dialog.findViewById(R.id.btn_minus_people);
        View btnPlus = dialog.findViewById(R.id.btn_plus_people);
        TextView tvPeopleCount = dialog.findViewById(R.id.tv_people_count);

        if (btnClose != null) btnClose.setOnClickListener(v -> dialog.dismiss());

        if (btnUpdate != null) {
            btnUpdate.setOnClickListener(v -> {
                Toast.makeText(this, "Reservation Updated Successfully!", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            });
        }

        final int[] count = {2};
        if (tvPeopleCount != null) {
            try { count[0] = Integer.parseInt(tvPeopleCount.getText().toString()); }
            catch (Exception e) { count[0] = 2; }
        }

        if (btnMinus != null) {
            btnMinus.setOnClickListener(v -> {
                if (count[0] > 1) { count[0]--; tvPeopleCount.setText(String.valueOf(count[0])); }
            });
        }
        if (btnPlus != null) {
            btnPlus.setOnClickListener(v -> {
                if (count[0] < 20) { count[0]++; tvPeopleCount.setText(String.valueOf(count[0])); }
            });
        }

        dialog.show();
    }

    private void setupBottomNavigation() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, GuestMenuActivity.class)));
        if (navReservation != null) navReservation.setOnClickListener(v -> startActivity(new Intent(this, GuestReservationActivity.class)));
        if (navNotification != null) navNotification.setOnClickListener(v -> startActivity(new Intent(this, GuestNotificationActivity.class)));
        if (navSettings != null) navSettings.setOnClickListener(v -> startActivity(new Intent(this, GuestSettingsActivity.class)));
    }
}
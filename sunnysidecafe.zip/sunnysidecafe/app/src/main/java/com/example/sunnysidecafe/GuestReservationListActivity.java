package com.example.sunnysidecafe;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

public class GuestReservationListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_reservation_list_screen);

        // --- Back Button ---
        ImageView btnBack = findViewById(R.id.btn_back_arrow);
        btnBack.setOnClickListener(v -> finish());

        // --- Tabs Logic (Visual only) ---
        TextView tabHistory = findViewById(R.id.tab_history);
        tabHistory.setOnClickListener(v -> {
            // Navigate to History Activity if needed
            // Intent intent = new Intent(this, GuestReservationHistoryActivity.class);
            // startActivity(intent);
            Toast.makeText(this, "Switching to History...", Toast.LENGTH_SHORT).show();
        });

        // --- Edit Button ---
        AppCompatButton btnEdit = findViewById(R.id.btn_edit);
        btnEdit.setOnClickListener(v -> {
            // Proceed to Edit Reservation logic (likely reusing the Make Reservation screens with pre-filled data)
            Intent intent = new Intent(this, GuestReservationDetailsActivity.class);
            intent.putExtra("isEditMode", true);
            startActivity(intent);
        });

        // --- Cancel Button ---
        AppCompatButton btnCancel = findViewById(R.id.btn_cancel);
        btnCancel.setOnClickListener(v -> showCancelConfirmationDialog());

        // --- Bottom Navigation ---
        setupBottomNav();
    }

    private void showCancelConfirmationDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Cancel Reservation")
                .setMessage("Are you sure you want to cancel this reservation?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    Toast.makeText(this, "Reservation Cancelled", Toast.LENGTH_SHORT).show();
                    // Perform cancellation logic here
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void setupBottomNav() {
        LinearLayout navMenu = findViewById(R.id.nav_btn_menu);
        navMenu.setOnClickListener(v -> {
            Intent intent = new Intent(this, GuestMenuActivity.class);
            startActivity(intent);
        });
    }
}
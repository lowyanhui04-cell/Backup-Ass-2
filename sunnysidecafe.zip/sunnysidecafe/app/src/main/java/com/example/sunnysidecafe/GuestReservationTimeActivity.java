package com.example.sunnysidecafe;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import java.util.ArrayList;
import java.util.List;

public class GuestReservationTimeActivity extends AppCompatActivity {

    private String selectedTime = "5:00 PM"; // Default selection
    private List<TextView> timeSlots = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_reservation_time_screen);

        // --- Navigation ---
        View btnBackArrow = findViewById(R.id.btn_back_arrow);
        btnBackArrow.setOnClickListener(v -> finish());

        // --- Time Slot Logic ---
        // Initialize 6 time slots only
        timeSlots.add(findViewById(R.id.time_500));
        timeSlots.add(findViewById(R.id.time_700));
        timeSlots.add(findViewById(R.id.time_900));

        // Set Click Listeners for each time slot
        for (TextView slot : timeSlots) {
            slot.setOnClickListener(v -> {
                selectedTime = slot.getText().toString();
                updateTimeSelectionUI(slot);
            });
        }

        // --- Bottom Buttons ---
        AppCompatButton btnNavBack = findViewById(R.id.btn_nav_back);
        AppCompatButton btnNavNext = findViewById(R.id.btn_nav_next);

        btnNavBack.setOnClickListener(v -> finish());

        btnNavNext.setOnClickListener(v -> {
            Toast.makeText(this, "Selected Time: " + selectedTime, Toast.LENGTH_SHORT).show();
            // Proceed to next screen
        });

        // --- Bottom Navigation Bar ---
        setupBottomNav();
    }

    private void updateTimeSelectionUI(TextView selectedSlot) {
        // Reset all to grey (unselected)
        for (TextView slot : timeSlots) {
            slot.setBackgroundResource(R.drawable.bg_unselected);
            slot.setTextColor(Color.parseColor("#000000")); // Black text
        }

        // Set selected to Gold Gradient
        selectedSlot.setBackgroundResource(R.drawable.bg_selected);
        selectedSlot.setTextColor(Color.parseColor("#1A234A")); // Dark blue text
    }

    private void setupBottomNav() {
        LinearLayout navMenu = findViewById(R.id.nav_btn_menu);
        LinearLayout navReservation = findViewById(R.id.nav_btn_reservation);

        navMenu.setOnClickListener(v -> {
            Intent intent = new Intent(this, GuestMenuActivity.class);
            startActivity(intent);
        });

        navReservation.setOnClickListener(v -> Toast.makeText(this, "You are in Reservation", Toast.LENGTH_SHORT).show());
    }
}
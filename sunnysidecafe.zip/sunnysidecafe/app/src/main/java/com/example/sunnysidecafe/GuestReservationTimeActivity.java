package com.example.sunnysidecafe;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GuestReservationTimeActivity extends AppCompatActivity {

    private String selectedTime = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Correct XML: The one with Time Grid and Back/Next buttons
        // Ensure you saved your second XML as 'guest_reservation_time_screen.xml'
        setContentView(R.layout.guest_reservation_time_screen);

        // 1. Back Buttons
        View btnBackArrow = findViewById(R.id.btn_back_arrow);
        View btnNavBack = findViewById(R.id.btn_nav_back);

        if (btnBackArrow != null) btnBackArrow.setOnClickListener(v -> finish());
        if (btnNavBack != null) btnNavBack.setOnClickListener(v -> finish());

        // 2. Next Button Logic
        // Uses 'btn_nav_next' from the time screen XML
        View btnNavNext = findViewById(R.id.btn_nav_next);
        if (btnNavNext != null) {
            btnNavNext.setOnClickListener(v -> {
                // NOW we check for time, because we are on the time screen
                if (selectedTime.isEmpty()) {
                    Toast.makeText(this, "Please select a time first", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(GuestReservationTimeActivity.this, GuestReservationTableActivity.class);
                    intent.putExtra("SELECTED_TIME", selectedTime);
                    startActivity(intent);
                }
            });
        }

        // 3. Time Slot Logic
        setupTimeSlots();

        setupBottomNavigation();
    }

    private void setupTimeSlots() {
        TextView time500 = findViewById(R.id.time_500);
        TextView time700 = findViewById(R.id.time_700);
        TextView time900 = findViewById(R.id.time_900);

        View.OnClickListener timeListener = v -> {
            // Reset styles
            resetTimeStyle(time500);
            resetTimeStyle(time700);
            resetTimeStyle(time900);

            // Highlight selected
            v.setBackgroundResource(R.drawable.bg_selected);
            ((TextView) v).setTextColor(Color.WHITE); // Assuming you want white text on selected

            selectedTime = ((TextView) v).getText().toString();
        };

        if (time500 != null) time500.setOnClickListener(timeListener);
        if (time700 != null) time700.setOnClickListener(timeListener);
        if (time900 != null) time900.setOnClickListener(timeListener);
    }

    private void resetTimeStyle(TextView tv) {
        if (tv != null) {
            tv.setBackgroundResource(R.drawable.bg_white_card);
            tv.setTextColor(Color.parseColor("#1A234A")); // Reset to your dark blue color
        }
    }

    private void setupBottomNavigation() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, GuestMenuActivity.class)));
        if (navReservation != null) navReservation.setOnClickListener(v -> startActivity(new Intent(this, GuestReservationActivity.class)));
        if (navNotification != null) navNotification.setOnClickListener(v -> startActivity(new Intent(this, GuestNotificationActivity.class)));
        if (navSettings != null) navSettings.setOnClickListener(v -> startActivity(new Intent(this, GuestSettingsActivity.class)));
    }
}
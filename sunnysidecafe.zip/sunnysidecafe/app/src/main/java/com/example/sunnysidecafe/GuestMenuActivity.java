package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GuestMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_menu_screen);

        setupBottomNavigation();
    }

    private void setupBottomNavigation() {
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navReservation != null) {
            navReservation.setOnClickListener(v -> {
                try {
                    Intent intent = new Intent(GuestMenuActivity.this, GuestReservationActivity.class);
                    startActivity(intent);
                    overridePendingTransition(0, 0); // No animation
                } catch (Exception e) {
                    Log.e("NavigationError", "Error going to Reservation: " + e.getMessage());
                    Toast.makeText(this, "Error opening Reservation screen", Toast.LENGTH_SHORT).show();
                }
            });
        }

        if (navNotification != null) {
            navNotification.setOnClickListener(v -> {
                Intent intent = new Intent(GuestMenuActivity.this, GuestNotificationActivity.class);
                startActivity(intent);
                overridePendingTransition(0, 0);
            });
        }

        if (navSettings != null) {
            navSettings.setOnClickListener(v -> {
                Intent intent = new Intent(GuestMenuActivity.this, GuestSettingsActivity.class);
                startActivity(intent);
                overridePendingTransition(0, 0);
            });
        }
    }
}
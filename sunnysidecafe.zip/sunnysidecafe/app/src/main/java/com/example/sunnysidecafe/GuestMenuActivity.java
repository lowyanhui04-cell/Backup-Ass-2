package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class GuestMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_menu_screen);

        // --- Bottom Navigation Logic ---
        LinearLayout navMenu = findViewById(R.id.nav_btn_menu);
        LinearLayout navReservation = findViewById(R.id.nav_btn_reservation);
        navReservation.setOnClickListener(v -> {
            Intent intent = new Intent(GuestMenuActivity.this, GuestReservationActivity.class);
            startActivity(intent);
        });
        LinearLayout navNotification = findViewById(R.id.nav_btn_notification);
        LinearLayout navSettings = findViewById(R.id.nav_btn_settings);

        // Menu is current screen
        navMenu.setOnClickListener(v -> Toast.makeText(this, "You are on the Menu", Toast.LENGTH_SHORT).show());

        navReservation.setOnClickListener(v -> {
            // Intent to Reservation Activity
            // startActivity(new Intent(this, GuestReservationActivity.class));
        });

        navNotification.setOnClickListener(v -> {
            // Intent to Notification Activity
        });

        navSettings.setOnClickListener(v -> {
            // Intent to Settings Activity
        });

        // --- Search Bar Logic ---
        View searchBar = findViewById(R.id.search_bar_container);
        searchBar.setOnClickListener(v -> {
            Toast.makeText(this, "Search clicked", Toast.LENGTH_SHORT).show();
        });

        // --- Food Item Click Listeners (Example) ---
        CardView item1 = findViewById(R.id.card_item_1);
        item1.setOnClickListener(v -> {
            Toast.makeText(this, "Selected: Grilled Chicken Chop", Toast.LENGTH_SHORT).show();
        });
    }
}
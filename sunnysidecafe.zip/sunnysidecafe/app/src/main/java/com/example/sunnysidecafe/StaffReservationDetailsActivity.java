package com.example.sunnysidecafe;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class StaffReservationDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reservation_details_screen);

        // --- Back Button ---
        ImageView btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // --- Cancel Reservation Button ---
        Button btnCancel = findViewById(R.id.btnCancelReservation);
        if (btnCancel != null) {
            btnCancel.setOnClickListener(v -> showCancellationDialog());
        }

        // --- TAB LOGIC ---
        LinearLayout tabContainer = findViewById(R.id.tabContainer);
        if (tabContainer != null) {
            View tabUpcoming = tabContainer.getChildAt(0);
            if (tabUpcoming != null) {
                tabUpcoming.setOnClickListener(v -> {
                    Intent intent = new Intent(StaffReservationDetailsActivity.this, StaffReservationActivity.class);
                    startActivity(intent);
                    overridePendingTransition(0, 0);
                });
            }

            View tabHistory = tabContainer.getChildAt(1);
            if (tabHistory != null) {
                tabHistory.setOnClickListener(v -> {
                    Intent intent = new Intent(StaffReservationDetailsActivity.this, StaffHistoryReservationActivity.class);
                    startActivity(intent);
                    overridePendingTransition(0, 0);
                });
            }
        }

        // --- Bottom Navigation ---
        setupBottomNav();
    }

    private void showCancellationDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.cancellation_dialog_screen);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }

        Button btnConfirmCancel = dialog.findViewById(R.id.btnConfirmCancel);
        Button btnGoBack = dialog.findViewById(R.id.btnGoBack);

        btnConfirmCancel.setOnClickListener(v -> {
            Toast.makeText(this, "Reservation Cancelled", Toast.LENGTH_SHORT).show();
            dialog.dismiss();

            // Navigate back to the list and pass a flag to delete the item
            Intent intent = new Intent(StaffReservationDetailsActivity.this, StaffReservationActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("REFRESH_CANCELLED", true); // <--- THIS FLAG TELLS THE LIST TO DELETE
            startActivity(intent);
            finish();
        });

        btnGoBack.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    private void setupBottomNav() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, StaffMenuActivity.class)));
        // Current Screen is Reservation
        if (navNotification != null) navNotification.setOnClickListener(v -> startActivity(new Intent(this, StaffNotificationActivity.class)));
        if (navSettings != null) navSettings.setOnClickListener(v -> startActivity(new Intent(this, StaffSettingsActivity.class)));
    }
}
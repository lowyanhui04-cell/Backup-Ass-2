package com.example.sunnysidecafe;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class StaffReservationDetailsActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int resId;

    // IDs from your staffreservationdetailsscreen.xml
    private TextView tvName;
    private Button btnCancelRes;
    private ImageView btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Make sure this matches your actual XML filename (e.g., reservation_details_screen)
        setContentView(R.layout.reservation_details_screen);

        dbHelper = new DatabaseHelper(this);

        // Get the ID passed from the previous screen
        resId = getIntent().getIntExtra("RES_ID", -1);

        // --- 1. Bind Views ---
        tvName = findViewById(R.id.tvName);
        btnCancelRes = findViewById(R.id.btnCancelReservation);
        btnBack = findViewById(R.id.btnBack);

        // --- 2. Load Data ---
        loadReservationDetails();

        // --- 3. Setup Listeners ---

        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        if (btnCancelRes != null) {
            btnCancelRes.setOnClickListener(v -> showCancelDialog());
        }

        setupBottomNav();
    }

    private void loadReservationDetails() {
        Cursor cursor = dbHelper.getReservation(resId);
        if (cursor != null && cursor.moveToFirst()) {
            // DB Columns: 0=id, 1=date, 2=time, 3=pax, 4=status
            String date = cursor.getString(1);
            String time = cursor.getString(2);
            String pax = cursor.getString(3);
            String status = cursor.getString(4);

            // Update Name TextView
            tvName.setText("Booking for " + pax);

            // NOTE: Your XML does not have IDs for Date, Time, or Pax values.
            // They are hardcoded as @string/label_time etc.
            // If you want to show dynamic data there, you must add IDs to those TextViews in XML.

            // Check if already cancelled
            if ("Cancelled".equalsIgnoreCase(status)) {
                btnCancelRes.setEnabled(false);
                btnCancelRes.setText("Reservation Cancelled");
            }
        }
        if (cursor != null) cursor.close();
    }

    private void showCancelDialog() {
        // Simple Popup Dialog
        new AlertDialog.Builder(this)
                .setTitle("Cancel Reservation")
                .setMessage("Are you sure you want to cancel this reservation?")
                .setPositiveButton("Yes, Cancel", (dialog, which) -> {
                    // Perform cancellation in Database
                    dbHelper.cancelReservation(resId);
                    Toast.makeText(this, "Reservation has been cancelled", Toast.LENGTH_SHORT).show();

                    // Refresh UI to disable button
                    loadReservationDetails();
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void setupBottomNav() {
        LinearLayout nav = findViewById(R.id.bottomNavContainer);
        if (nav != null) {
            // Child 0: Menu
            nav.getChildAt(0).setOnClickListener(v -> {
                startActivity(new Intent(this, StaffMenuActivity.class));
                overridePendingTransition(0, 0);
            });
            // Child 1: Reservation (Active) -> go back to list
            nav.getChildAt(1).setOnClickListener(v -> {
                startActivity(new Intent(this, StaffReservationActivity.class));
                overridePendingTransition(0, 0);
            });
            // Child 2: Notification
            nav.getChildAt(2).setOnClickListener(v -> {
                startActivity(new Intent(this, StaffNotificationActivity.class));
                overridePendingTransition(0, 0);
            });
        }
    }
}
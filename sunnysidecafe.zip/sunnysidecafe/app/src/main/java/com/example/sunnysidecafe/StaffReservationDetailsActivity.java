package com.example.sunnysidecafe;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

public class StaffReservationDetailsActivity extends AppCompatActivity {

    // Header & Nav
    private ImageView btnBack;

    // Details
    private TextView tvName;
    private AppCompatButton btnCancelReservation;

    // Bottom Navigation
    private LinearLayout navMenu, navReservation, navNotification, navSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reservation_details_screen); // Ensure matches your XML filename

        initializeViews();
        setupListeners();
    }

    private void initializeViews() {
        btnBack = findViewById(R.id.btnBack);
        tvName = findViewById(R.id.tvName);
        btnCancelReservation = findViewById(R.id.btnCancelReservation);

        // Bottom Nav
        LinearLayout bottomNav = findViewById(R.id.bottomNavContainer);
        navMenu = (LinearLayout) bottomNav.getChildAt(0);
        navReservation = (LinearLayout) bottomNav.getChildAt(1);
        navNotification = (LinearLayout) bottomNav.getChildAt(2);
        navSettings = (LinearLayout) bottomNav.getChildAt(3);
    }

    private void setupListeners() {
        // Back Button
        btnBack.setOnClickListener(v -> finish());

        // Cancel Reservation Logic
        btnCancelReservation.setOnClickListener(v -> showCancellationDialog());

        // Bottom Navigation
        navMenu.setOnClickListener(v -> {
            Intent intent = new Intent(this, StaffMenuActivity.class);
            startActivity(intent);
            overridePendingTransition(0, 0);
        });

        navReservation.setOnClickListener(v -> {
            // Check if we need to go back to list or stay here
            Intent intent = new Intent(this, StaffReservationActivity.class);
            startActivity(intent);
            overridePendingTransition(0, 0);
        });

        navNotification.setOnClickListener(v -> {
            Intent intent = new Intent(this, StaffNotificationActivity.class);
            startActivity(intent);
            overridePendingTransition(0, 0);
        });

        //navSettings.setOnClickListener(v -> {
            //Intent intent = new Intent(this, StaffSettingsScreen.class);
            //startActivity(intent);
            //overridePendingTransition(0, 0);
        //});
    }

    private void showCancellationDialog() {
        // Assuming you have 'cancellation_dialog_screen.xml' layout created previously
        // If not, use standard AlertDialog
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.cancellation_dialog_screen); // Use your custom layout

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        // Initialize Dialog Buttons
        // (Adjust IDs based on your dialog XML)
        AppCompatButton btnKeep = dialog.findViewById(R.id.btnCancelReservation);
        AppCompatButton btnCancel = dialog.findViewById(R.id.btnCancel);

        if (btnKeep != null) {
            btnKeep.setOnClickListener(v -> dialog.dismiss());
        }

        if (btnCancel != null) {
            btnCancel.setOnClickListener(v -> {
                Toast.makeText(this, "Reservation Cancelled", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
                finish(); // Go back to list
            });
        }

        dialog.show();
    }
}
package com.example.sunnysidecafe;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class AddNewItemActivity extends AppCompatActivity {

    private EditText etName, etPrice; // Add etDesc if you have a description field
    private ImageView imgPreview, btnBack;
    private Button btnSave, btnCancel;
    private DatabaseHelper dbHelper;
    private String selectedImageUri = "";

    // Image Picker Logic
    private final ActivityResultLauncher<String> selectImage = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    selectedImageUri = uri.toString();
                    imgPreview.setImageURI(uri);
                    // Grant permission to access this image later
                    try {
                        getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (SecurityException e) {
                        e.printStackTrace();
                    }
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_new_item_screen); // Ensure this XML name is correct

        dbHelper = new DatabaseHelper(this);

        // --- CHECK YOUR XML IDs HERE ---
        etName = findViewById(R.id.etItemName);       // Example ID
        etPrice = findViewById(R.id.etPrice);         // Example ID
        imgPreview = findViewById(R.id.imgPreview);   // Example ID
        btnSave = findViewById(R.id.btnSaveItem);     // Example ID
        btnCancel = findViewById(R.id.btnCancel);     // Example ID
        btnBack = findViewById(R.id.btnBack);         // Example ID (if exists)

        // Select Image Listener
        if (imgPreview != null) {
            imgPreview.setOnClickListener(v -> selectImage.launch("image/*"));
        }

        // Save Button Listener
        if (btnSave != null) {
            btnSave.setOnClickListener(v -> {
                String name = etName.getText().toString();
                String price = etPrice.getText().toString();

                if (name.isEmpty() || price.isEmpty()) {
                    Toast.makeText(this, "Please fill required fields", Toast.LENGTH_SHORT).show();
                } else {
                    // Save to Database
                    dbHelper.addMenuItem(name, "", price, selectedImageUri);
                    Toast.makeText(this, "Item Added Successfully", Toast.LENGTH_SHORT).show();
                    finish(); // Return to Menu Screen
                }
            });
        }

        // Cancel / Back Listeners
        if (btnCancel != null) btnCancel.setOnClickListener(v -> finish());
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());
    }
}
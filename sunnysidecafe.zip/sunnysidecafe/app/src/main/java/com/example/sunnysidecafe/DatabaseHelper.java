package com.example.sunnysidecafe;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "SunnysideCafe.db";
    private static final int DATABASE_VERSION = 1;

    // Table Names
    private static final String TABLE_USERS = "users";
    private static final String TABLE_MENU = "menu_items";
    private static final String TABLE_RESERVATIONS = "reservations";
    private static final String TABLE_NOTIFICATIONS = "notifications";

    private static final String KEY_ID = "id";

    // Menu Table
    private static final String KEY_NAME = "name";
    private static final String KEY_DESC = "description";
    private static final String KEY_PRICE = "price";
    private static final String KEY_IMAGE = "image_uri";

    // User Table Columns (added for clarity)
    private static final String KEY_USER_NAME = "username";
    private static final String KEY_USER_PASS = "password";
    private static final String KEY_USER_ROLE = "role";

    // Reservation Table
    private static final String KEY_RES_DATE = "date";
    private static final String KEY_RES_TIME = "time";
    private static final String KEY_PAX = "pax";
    private static final String KEY_STATUS = "status";

    // Notification Table
    private static final String KEY_NOTIF_MSG = "message";
    private static final String KEY_IS_READ = "is_read";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_USER_NAME + " TEXT,"
                + KEY_USER_PASS + " TEXT,"
                + KEY_USER_ROLE + " TEXT" + ")";

        String CREATE_MENU_TABLE = "CREATE TABLE " + TABLE_MENU + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_NAME + " TEXT,"
                + KEY_DESC + " TEXT,"
                + KEY_PRICE + " TEXT,"
                + KEY_IMAGE + " TEXT" + ")";

        String CREATE_RESERVATIONS_TABLE = "CREATE TABLE " + TABLE_RESERVATIONS + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_RES_DATE + " TEXT,"
                + KEY_RES_TIME + " TEXT,"
                + KEY_PAX + " TEXT,"
                + KEY_STATUS + " TEXT" + ")";

        String CREATE_NOTIFICATIONS_TABLE = "CREATE TABLE " + TABLE_NOTIFICATIONS + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_NOTIF_MSG + " TEXT,"
                + KEY_IS_READ + " INTEGER" + ")";

        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_MENU_TABLE);
        db.execSQL(CREATE_RESERVATIONS_TABLE);
        db.execSQL(CREATE_NOTIFICATIONS_TABLE);

        insertDummyData(db);
    }

    private void insertDummyData(SQLiteDatabase db) {
        db.execSQL("INSERT INTO " + TABLE_USERS + " (username, password, role) VALUES ('John', 'John1234', 'Staff')");
        db.execSQL("INSERT INTO " + TABLE_MENU + " (name, description, price, image_uri) VALUES ('Signature Pasta', 'Delicious creamy pasta', '25.00', '')");
        db.execSQL("INSERT INTO " + TABLE_MENU + " (name, description, price, image_uri) VALUES ('Iced Latte', 'Refreshing coffee', '12.00', '')");
        db.execSQL("INSERT INTO " + TABLE_RESERVATIONS + " (date, time, pax, status) VALUES ('2025-12-25', '19:00', '4 pax', 'Active')");
        db.execSQL("INSERT INTO " + TABLE_RESERVATIONS + " (date, time, pax, status) VALUES ('2024-01-01', '12:00', '2 pax', 'Cancelled')");
        db.execSQL("INSERT INTO " + TABLE_NOTIFICATIONS + " (message, is_read) VALUES ('New reservation made for 4 pax on 2025-12-25', 0)");
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MENU);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RESERVATIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTIFICATIONS);
        onCreate(db);
    }

    // --- USER OPERATIONS ---

    public boolean registerUser(String name, String email, String password, String role) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_USER_NAME, email); // Storing email in username column
        values.put(KEY_USER_PASS, password);
        values.put(KEY_USER_ROLE, role);

        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1;
    }

    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + KEY_USER_NAME + "=? AND " + KEY_USER_PASS + "=?", new String[]{email, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // --- MENU OPERATIONS ---

    public void addMenuItem(String name, String desc, String price, String imageUri) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_NAME, name);
        values.put(KEY_DESC, desc);
        values.put(KEY_PRICE, price);
        values.put(KEY_IMAGE, imageUri);
        db.insert(TABLE_MENU, null, values);
        db.close();
    }

    public Cursor getAllMenuItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_MENU, null);
    }

    public Cursor getMenuItem(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        // FIXED: Changed "menu_table" to TABLE_MENU constant
        return db.rawQuery("SELECT * FROM " + TABLE_MENU + " WHERE " + KEY_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public void updateMenuItem(int id, String name, String desc, String price, String imageUri) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_NAME, name);
        values.put(KEY_DESC, desc);
        values.put(KEY_PRICE, price);
        values.put(KEY_IMAGE, imageUri);
        db.update(TABLE_MENU, values, KEY_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }

    public void deleteMenuItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_MENU, KEY_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }

    // --- RESERVATION OPERATIONS ---

    public Cursor getAllReservations() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_RESERVATIONS, null);
    }

    public Cursor getActiveReservations() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_RESERVATIONS + " WHERE " + KEY_STATUS + "='Active'", null);
    }

    public Cursor getHistoryReservations() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_RESERVATIONS + " WHERE " + KEY_STATUS + "<>'Active'", null);
    }

    public Cursor getReservation(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_RESERVATIONS + " WHERE " + KEY_ID + "=?", new String[]{String.valueOf(id)});
    }

    public void cancelReservation(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_STATUS, "Cancelled");
        db.update(TABLE_RESERVATIONS, values, KEY_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }

    // --- NOTIFICATION OPERATIONS ---

    public Cursor getAllNotifications() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NOTIFICATIONS + " ORDER BY id DESC", null);
    }

    public void simulateNewReservation() {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_RES_DATE, "2025-12-31");
        values.put(KEY_RES_TIME, "20:00");
        values.put(KEY_PAX, "2 pax");
        values.put(KEY_STATUS, "Active");
        db.insert(TABLE_RESERVATIONS, null, values);

        ContentValues notifValues = new ContentValues();
        notifValues.put(KEY_NOTIF_MSG, "New reservation made for 2 pax on 2025-12-31");
        notifValues.put(KEY_IS_READ, 0);
        db.insert(TABLE_NOTIFICATIONS, null, notifValues);

        db.close();
    }
}
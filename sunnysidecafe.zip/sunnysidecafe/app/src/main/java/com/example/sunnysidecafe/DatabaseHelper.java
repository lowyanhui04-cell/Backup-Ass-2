package com.example.sunnysidecafe;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "SunnysideCafe.db";
    private static final int DATABASE_VERSION = 1;

    // Users Table
    public static final String TABLE_USERS = "users";
    public static final String COL_EMAIL = "email";
    public static final String COL_PASSWORD = "password";
    public static final String COL_NAME = "name";
    public static final String COL_ROLE = "role";

    // Menu Items Table
    public static final String TABLE_ITEMS = "menu_items";
    public static final String COL_ITEM_ID = "id";
    public static final String COL_ITEM_NAME = "name";
    public static final String COL_ITEM_PRICE = "price";
    public static final String COL_ITEM_IMG_RES = "image_res";

    // Reservations Table
    public static final String TABLE_RESERVATIONS = "reservations";
    public static final String COL_RES_ID = "id";
    public static final String COL_RES_DATE = "date";
    public static final String COL_RES_TIME = "time";
    public static final String COL_RES_PAX = "pax";
    public static final String COL_RES_STATUS = "status";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create User Table
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                COL_EMAIL + " TEXT PRIMARY KEY, " +
                COL_NAME + " TEXT, " +
                COL_PASSWORD + " TEXT, " +
                COL_ROLE + " TEXT)");

        // Create Menu Table
        db.execSQL("CREATE TABLE " + TABLE_ITEMS + " (" +
                COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ITEM_NAME + " TEXT, " +
                COL_ITEM_PRICE + " TEXT, " +
                COL_ITEM_IMG_RES + " INTEGER)");

        // Create Reservation Table
        db.execSQL("CREATE TABLE " + TABLE_RESERVATIONS + " (" +
                COL_RES_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_RES_DATE + " TEXT, " +
                COL_RES_TIME + " TEXT, " +
                COL_RES_PAX + " TEXT, " +
                COL_RES_STATUS + " TEXT)");

        addInitialData(db);
    }

    private void addInitialData(SQLiteDatabase db) {
        // Dummy Menu Data
        db.execSQL("INSERT INTO " + TABLE_ITEMS + " (name, price, image_res) VALUES ('Hawaiian Pizza', 'RM 25.00', " + R.drawable.food_pineapple + ")");
        db.execSQL("INSERT INTO " + TABLE_ITEMS + " (name, price, image_res) VALUES ('Signature Burger', 'RM 18.00', " + R.drawable.food_signature + ")");
        db.execSQL("INSERT INTO " + TABLE_ITEMS + " (name, price, image_res) VALUES ('Carbonara', 'RM 22.00', " + R.drawable.food_carbonara + ")");

        // Dummy Reservation Data
        db.execSQL("INSERT INTO " + TABLE_RESERVATIONS + " (date, time, pax, status) VALUES ('12 Oct 2023', '7:00 PM', '2 Pax', 'active')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RESERVATIONS);
        onCreate(db);
    }

    // --- MENU METHODS ---
    public boolean addMenuItem(String name, String price) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_PRICE, price);
        values.put(COL_ITEM_IMG_RES, R.drawable.food_signature);
        return db.insert(TABLE_ITEMS, null, values) != -1;
    }

    public boolean updateMenuItem(int id, String name, String price) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_PRICE, price);
        return db.update(TABLE_ITEMS, values, COL_ITEM_ID + "=?", new String[]{String.valueOf(id)}) > 0;
    }

    public boolean deleteMenuItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_ITEMS, COL_ITEM_ID + "=?", new String[]{String.valueOf(id)}) > 0;
    }

    public Cursor getAllMenuItems() {
        return this.getReadableDatabase().rawQuery("SELECT * FROM " + TABLE_ITEMS, null);
    }

    // --- USER METHODS ---
    public boolean registerUser(String name, String email, String password, String role) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NAME, name);
        values.put(COL_EMAIL, email);
        values.put(COL_PASSWORD, password);
        values.put(COL_ROLE, role);
        return db.insert(TABLE_USERS, null, values) != -1;
    }

    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE email=? AND password=?", new String[]{email, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // --- RESERVATION METHODS (ADDED) ---

    // For StaffReservationActivity (List)
    public Cursor reservation_details_screen() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT " + COL_RES_ID + ", " + COL_RES_DATE + ", " + COL_RES_TIME + ", " + COL_RES_PAX + " FROM " + TABLE_RESERVATIONS + " WHERE " + COL_RES_STATUS + " = 'active'", null);
    }

    // For StaffReservationDetailsActivity (Single Details)
    public Cursor getReservation(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_RESERVATIONS + " WHERE " + COL_RES_ID + " = ?", new String[]{String.valueOf(id)});
    }

    // Cancel Reservation
    public boolean cancelReservation(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_RES_STATUS, "Cancelled");
        long result = db.update(TABLE_RESERVATIONS, values, COL_RES_ID + " = ?", new String[]{String.valueOf(id)});
        return result > 0;
    }
}
package com.example.sunnysidecafe;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ManageItemActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int itemId = -1; // -1 means Adding, otherwise Editing

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. CHECK INTENT FIRST to decide which layout to load
        if (getIntent().hasExtra("ID")) {
            itemId = getIntent().getIntExtra("ID", -1);
            setContentView(R.layout.edit_menu_screen); // Load Edit XML
        } else {
            setContentView(R.layout.add_new_item_screen); // Load Add XML
        }

        dbHelper = new DatabaseHelper(this);

        // 2. BIND VIEWS
        // IMPORTANT: Ensure your XML files (add_new_item_screen.xml AND edit_menu_screen.xml)
        // use these EXACT IDs for these fields:
        EditText etName = findViewById(R.id.etName);
        EditText etPrice = findViewById(R.id.etPrice);
        Button btnSave = findViewById(R.id.btnSave);
        ImageView btnBack = findViewById(R.id.btnBack); // Assuming you have a back button

        // 3. PRE-FILL DATA (Only if Editing)
        if (itemId != -1) {
            // We are editing, fill the boxes
            if (etName != null) etName.setText(getIntent().getStringExtra("NAME"));
            if (etPrice != null) etPrice.setText(getIntent().getStringExtra("PRICE"));
            if (btnSave != null) btnSave.setText("Update Item");
        }

        // 4. SAVE BUTTON LISTENER
        if (btnSave != null) {
            btnSave.setOnClickListener(v -> {
                String name = (etName != null) ? etName.getText().toString() : "";
                String price = (etPrice != null) ? etPrice.getText().toString() : "";

                if (name.isEmpty() || price.isEmpty()) {
                    Toast.makeText(this, "Please fill fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (itemId == -1) {
                    // --- CASE: ADD NEW ---
                    if (dbHelper.addMenuItem(name, price)) {
                        Toast.makeText(this, "Item Added", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(this, "Error Adding", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // --- CASE: UPDATE EXISTING ---
                    if (dbHelper.updateMenuItem(itemId, name, price)) {
                        Toast.makeText(this, "Item Updated", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(this, "Error Updating", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        // 5. BACK BUTTON LISTENER
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }
    }
}
package com.example.sunnysidecafe;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ManageItemActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int itemId = -1; // -1 means Adding, otherwise Editing

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_menu_screen);

        dbHelper = new DatabaseHelper(this);

        // Find views (You need to create these IDs in your XML)
        EditText etName = findViewById(R.id.etName);
        EditText etPrice = findViewById(R.id.etPrice);
        Button btnSave = findViewById(R.id.btnSave);

        // Check if we are editing (Data passed from StaffMenuActivity)
        if (getIntent().hasExtra("ID")) {
            itemId = getIntent().getIntExtra("ID", -1);
            etName.setText(getIntent().getStringExtra("NAME"));
            etPrice.setText(getIntent().getStringExtra("PRICE"));
            btnSave.setText("Update Item");
        }

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String price = etPrice.getText().toString();

            if (name.isEmpty() || price.isEmpty()) {
                Toast.makeText(this, "Please fill fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (itemId == -1) {
                // Add New
                if (dbHelper.addMenuItem(name, price)) {
                    Toast.makeText(this, "Item Added", Toast.LENGTH_SHORT).show();
                    finish(); // Go back to Menu
                } else {
                    Toast.makeText(this, "Error Adding", Toast.LENGTH_SHORT).show();
                }
            } else {
                // Update Existing
                if (dbHelper.updateMenuItem(itemId, name, price)) {
                    Toast.makeText(this, "Item Updated", Toast.LENGTH_SHORT).show();
                    finish(); // Go back to Menu
                } else {
                    Toast.makeText(this, "Error Updating", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
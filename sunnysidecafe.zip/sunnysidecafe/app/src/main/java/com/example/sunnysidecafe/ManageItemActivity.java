package com.example.sunnysidecafe;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class ManageItemActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int itemId = -1;
    private String imageUriStr = "null";
    private ImageView imgPreview;
    private LinearLayout containerUpload;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getIntent().hasExtra("ID")) {
            itemId = getIntent().getIntExtra("ID", -1);
            setContentView(R.layout.edit_menu_screen);
            imageUriStr = getIntent().getStringExtra("URI");
        } else {
            setContentView(R.layout.add_new_item_screen);
        }

        dbHelper = new DatabaseHelper(this);
        EditText etName = findViewById(R.id.etItemName);
        EditText etPrice = findViewById(R.id.etPrice);
        imgPreview = findViewById(R.id.imgPreview);
        containerUpload = findViewById(R.id.containerUpload);

        Button btnSave = (itemId == -1) ? findViewById(R.id.btnSave) : findViewById(R.id.btnSaveChange);

        ActivityResultLauncher<Intent> imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Uri uri = result.getData().getData();
                        imageUriStr = uri.toString();

                        // Take persistable permission
                        try {
                            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        } catch (Exception e) { e.printStackTrace(); }

                        // Display in UI
                        if (imgPreview != null) {
                            imgPreview.setImageURI(uri);
                        } else if (containerUpload != null) {
                            containerUpload.removeAllViews();
                            ImageView newImg = new ImageView(this);
                            newImg.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
                            newImg.setScaleType(ImageView.ScaleType.CENTER_CROP);
                            newImg.setImageURI(uri);
                            containerUpload.addView(newImg);
                        }
                    }
                }
        );

        if (containerUpload != null) containerUpload.setOnClickListener(v -> openGallery(imagePickerLauncher));
        View changeImg = findViewById(R.id.btnChangeImage);
        if (changeImg != null) changeImg.setOnClickListener(v -> openGallery(imagePickerLauncher));

        if (itemId != -1) {
            etName.setText(getIntent().getStringExtra("NAME"));
            etPrice.setText(getIntent().getStringExtra("PRICE"));
            if (imgPreview != null && imageUriStr != null && !imageUriStr.equals("null")) {
                imgPreview.setImageURI(Uri.parse(imageUriStr));
            }
        }

        if (btnSave != null) {
            btnSave.setOnClickListener(v -> {
                String name = etName.getText().toString().trim();
                String pStr = etPrice.getText().toString().trim();
                if (name.isEmpty() || pStr.isEmpty()) return;

                try {
                    double price = Double.parseDouble(pStr);
                    boolean success = (itemId == -1) ?
                            dbHelper.insertMenuItem(name, price, imageUriStr) :
                            dbHelper.updateMenuItem(String.valueOf(itemId), name, price, imageUriStr);

                    if (success) finish();
                } catch (Exception e) { Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show(); }
            });
        }

        if (findViewById(R.id.btnBack) != null) findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        if (findViewById(R.id.btnCancel) != null) findViewById(R.id.btnCancel).setOnClickListener(v -> finish());
    }

    private void openGallery(ActivityResultLauncher<Intent> launcher) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        launcher.launch(intent);
    }
}
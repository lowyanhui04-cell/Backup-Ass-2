package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class GuestStaffActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_staff_selection_screen);

        // 1. Find the buttons using the IDs from your XML
        Button btnGuest = findViewById(R.id.btnGuest);
        Button btnStaff = findViewById(R.id.btnStaff);

        // 2. Set Click Listener for Staff Button
        btnStaff.setOnClickListener(v -> {
            Intent intent = new Intent(GuestStaffActivity.this, LoginActivity.class);
            // Pass "staff" so LoginActivity knows who is logging in
            intent.putExtra("USER_ROLE", "staff");
            startActivity(intent);
        });

        // 3. Set Click Listener for Guest Button
        btnGuest.setOnClickListener(v -> {
            Intent intent = new Intent(GuestStaffActivity.this, LoginActivity.class);
            // Pass "guest" so LoginActivity knows who is logging in
            intent.putExtra("USER_ROLE", "guest");
            startActivity(intent);
        });
    }
}
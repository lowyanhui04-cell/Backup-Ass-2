package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
// Import LinearLayout if your buttons are layouts, or Button if they are standard buttons
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class GuestStaffActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_staff_selection_screen); // Check this name matches your XML file

        // 1. Find the buttons/layouts from your XML
        // Make sure these IDs match what is in layout_guest_staff_selection_screen.xml
        View btnGuest = findViewById(R.id.btnGuest);
        View btnStaff = findViewById(R.id.btnStaff);

        // 2. Guest Logic
        if (btnGuest != null) {
            btnGuest.setOnClickListener(v -> {
                Intent intent = new Intent(GuestStaffActivity.this, LoginActivity.class);
                intent.putExtra("userType", "guest"); // <--- This passes "guest" to Login
                startActivity(intent);
            });
        }

        // 3. Staff Logic
        if (btnStaff != null) {
            btnStaff.setOnClickListener(v -> {
                Intent intent = new Intent(GuestStaffActivity.this, LoginActivity.class);
                intent.putExtra("userType", "staff"); // <--- This passes "staff" to Login
                startActivity(intent);
            });
        }
    }
}
package com.example.sunnysidecafe;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GuestStaffActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Remove status bar limits to match full screen design
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );

        setContentView(R.layout.guest_staff_selection_screen);

        Button btnGuest = findViewById(R.id.btnGuest);
        Button btnStaff = findViewById(R.id.btnStaff);

        btnGuest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(GuestStaffActivity.this, "Guest Selected", Toast.LENGTH_SHORT).show();
                // Add logic to go to Guest Menu here
            }
        });

        btnStaff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(GuestStaffActivity.this, "Staff Selected", Toast.LENGTH_SHORT).show();
                // Add logic to go to Staff Login here
            }
        });
    }
}
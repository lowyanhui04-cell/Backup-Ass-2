package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.cardview.widget.CardView;

public class GuestReservationTableActivity extends AppCompatActivity {

    private CardView cardIndoor, cardOutdoor, cardWindow;
    private String selectedSeating = "Outdoor"; // Default based on CSS

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest_reservation_table);

        // --- Header & Navigation ---
        View btnBack = findViewById(R.id.btn_back_arrow);
        btnBack.setOnClickListener(v -> finish());

        TextView btnEdit = findViewById(R.id.btn_edit_summary);
        btnEdit.setOnClickListener(v -> {
            // Logic to go back to Date/Time selection
            finish();
        });

        // --- Seating Logic ---
        cardIndoor = findViewById(R.id.card_indoor);
        cardOutdoor = findViewById(R.id.card_outdoor);
        cardWindow = findViewById(R.id.card_window);

        // Set listeners
        cardIndoor.setOnClickListener(v -> updateSeatingSelection(cardIndoor, "Indoor"));
        cardOutdoor.setOnClickListener(v -> updateSeatingSelection(cardOutdoor, "Outdoor"));
        cardWindow.setOnClickListener(v -> updateSeatingSelection(cardWindow, "Window"));

        // --- Special Request ---
        EditText etSpecialRequest = findViewById(R.id.et_special_request);

        // --- Confirm Button ---
        AppCompatButton btnConfirm = findViewById(R.id.btn_confirm);
        btnConfirm.setOnClickListener(v -> {
            String request = etSpecialRequest.getText().toString();
            Toast.makeText(this, "Confirmed: " + selectedSeating + "\nNote: " + request, Toast.LENGTH_LONG).show();

            // Navigate to Success Screen or Home
            // Intent intent = new Intent(this, ReservationSuccessActivity.class);
            // startActivity(intent);
        });

        // --- Bottom Nav ---
        setupBottomNav();
    }

    private void updateSeatingSelection(CardView selectedCard, String seatingName) {
        selectedSeating = seatingName;

        // Reset all to white background
        cardIndoor.setCardBackgroundColor(0xFFFFFFFF); // White
        cardOutdoor.setCardBackgroundColor(0xFFFFFFFF);
        cardWindow.setCardBackgroundColor(0xFFFFFFFF);

        // Reset text colors if you want strict control (Optional, handled by layout mostly)

        // Highlight selected (Gold Gradient simulation using solid color or resource)
        // Since CardView doesn't support gradient backgrounds easily without a child layout,
        // we swap the child layout background or set a solid color closer to the gradient start.
        // For exact design match, we use the method below:

        // Note: To apply the gradient XML to a CardView, we actually apply it to the LinearLayout INSIDE the card.
        findViewById(R.id.layout_indoor).setBackgroundResource(R.drawable.bg_white_card_no_radius);
        findViewById(R.id.layout_outdoor).setBackgroundResource(R.drawable.bg_white_card_no_radius);
        findViewById(R.id.layout_window).setBackgroundResource(R.drawable.bg_white_card_no_radius);

        if (seatingName.equals("Indoor")) {
            findViewById(R.id.layout_indoor).setBackgroundResource(R.drawable.bg_card_gradient_gold);
        } else if (seatingName.equals("Outdoor")) {
            findViewById(R.id.layout_outdoor).setBackgroundResource(R.drawable.bg_card_gradient_gold);
        } else {
            findViewById(R.id.layout_window).setBackgroundResource(R.drawable.bg_card_gradient_gold);
        }
    }

    private void setupBottomNav() {
        LinearLayout navMenu = findViewById(R.id.nav_btn_menu);
        LinearLayout navReservation = findViewById(R.id.nav_btn_reservation);

        navMenu.setOnClickListener(v -> {
            Intent intent = new Intent(this, GuestMenuActivity.class);
            startActivity(intent);
        });

        navReservation.setOnClickListener(v -> Toast.makeText(this, "You are in Reservation", Toast.LENGTH_SHORT).show());
    }
}
package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.cardview.widget.CardView;

public class GuestReservationTableActivity extends AppCompatActivity {

    private CardView cardIndoor, cardOutdoor, cardWindow;
    private LinearLayout layoutIndoor, layoutOutdoor, layoutWindow;
    private String selectedSeating = "Outdoor"; // Default based on layout

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_reservation_table_screen);

        // --- 1. Initialize Views ---
        ImageView btnBack = findViewById(R.id.btn_back_arrow);
        TextView btnEdit = findViewById(R.id.btn_edit_summary);

        cardIndoor = findViewById(R.id.card_indoor);
        cardOutdoor = findViewById(R.id.card_outdoor);
        cardWindow = findViewById(R.id.card_window);

        layoutIndoor = findViewById(R.id.layout_indoor);
        layoutOutdoor = findViewById(R.id.layout_outdoor);
        layoutWindow = findViewById(R.id.layout_window);

        EditText etSpecialRequest = findViewById(R.id.et_special_request);
        AppCompatButton btnConfirm = findViewById(R.id.btn_confirm);

        // --- 2. Navigation Listeners ---
        btnBack.setOnClickListener(v -> finish());

        btnEdit.setOnClickListener(v -> {
            // Logic to go back to Date/Time selection
            finish();
        });

        // --- 3. Seating Selection Logic ---
        cardIndoor.setOnClickListener(v -> updateSeatingSelection("Indoor"));
        cardOutdoor.setOnClickListener(v -> updateSeatingSelection("Outdoor"));
        cardWindow.setOnClickListener(v -> updateSeatingSelection("Window"));

        // --- 4. Confirm Button ---
        btnConfirm.setOnClickListener(v -> {
            String requestText = etSpecialRequest.getText().toString().trim();

            // Database Logic or passing data to a Summary/Success screen
            Toast.makeText(this, "Seating: " + selectedSeating + "\nRequests: " +
                    (requestText.isEmpty() ? "None" : requestText), Toast.LENGTH_LONG).show();

            // Example Navigation to Success:
            // Intent intent = new Intent(this, ReservationSuccessActivity.class);
            // startActivity(intent);
        });

        // --- 5. Bottom Navigation Setup ---
        setupBottomNav();
    }

    private void updateSeatingSelection(String seatingName) {
        selectedSeating = seatingName;

        // Reset all layouts to the standard white background drawable
        layoutIndoor.setBackgroundResource(R.drawable.bg_white_card);
        layoutOutdoor.setBackgroundResource(R.drawable.bg_white_card);
        layoutWindow.setBackgroundResource(R.drawable.bg_white_card);

        // Apply selected background (Gold Gradient or "Selected" style)
        switch (seatingName) {
            case "Indoor":
                layoutIndoor.setBackgroundResource(R.drawable.bg_selected);
                break;
            case "Outdoor":
                layoutOutdoor.setBackgroundResource(R.drawable.bg_selected);
                break;
            case "Window":
                layoutWindow.setBackgroundResource(R.drawable.bg_selected);
                break;
        }
    }

    private void setupBottomNav() {
        LinearLayout navMenu = findViewById(R.id.nav_btn_menu);
        LinearLayout navReservation = findViewById(R.id.nav_btn_reservation);
        LinearLayout navNotification = findViewById(R.id.nav_btn_notification);
        LinearLayout navSettings = findViewById(R.id.nav_btn_settings);

        navMenu.setOnClickListener(v -> {
            startActivity(new Intent(this, GuestMenuActivity.class));
            finish();
        });

        navReservation.setOnClickListener(v ->
                Toast.makeText(this, "Already in Reservation", Toast.LENGTH_SHORT).show());

        navNotification.setOnClickListener(v -> {
            // startActivity(new Intent(this, GuestNotificationActivity.class));
        });

        navSettings.setOnClickListener(v -> {
            // startActivity(new Intent(this, GuestSettingsActivity.class));
        });
    }
}
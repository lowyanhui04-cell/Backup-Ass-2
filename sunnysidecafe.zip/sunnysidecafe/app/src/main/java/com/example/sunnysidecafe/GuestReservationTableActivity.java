package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GuestReservationTableActivity extends AppCompatActivity {

    private String selectedTime;
    private String selectedSeating = "Outdoor"; // Default selection based on your XML

    // UI References
    private LinearLayout layoutIndoor, layoutOutdoor, layoutWindow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Ensure this matches your XML file name
        setContentView(R.layout.guest_reservation_table_screen);

        // 1. Retrieve Data from Previous Screen
        selectedTime = getIntent().getStringExtra("SELECTED_TIME");

        // 2. Initialize Views
        ImageView btnBackArrow = findViewById(R.id.btn_back_arrow);
        Button btnConfirm = findViewById(R.id.btn_confirm);
        TextView btnEditSummary = findViewById(R.id.btn_edit_summary);

        // Seating Layouts (We change the background of these layouts)
        layoutIndoor = findViewById(R.id.layout_indoor);
        layoutOutdoor = findViewById(R.id.layout_outdoor);
        layoutWindow = findViewById(R.id.layout_window);

        // 3. Back Button Logic
        if (btnBackArrow != null) {
            btnBackArrow.setOnClickListener(v -> finish());
        }

        // 4. Edit Summary Logic (Goes back to start)
        if (btnEditSummary != null) {
            btnEditSummary.setOnClickListener(v -> {
                // Return to details/start
                Intent intent = new Intent(GuestReservationTableActivity.this, GuestReservationDetailsActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            });
        }

        // 5. Confirm Button Logic
        if (btnConfirm != null) {
            btnConfirm.setOnClickListener(v -> confirmReservation());
        }

        // 6. Setup Seating Selection Logic
        setupSeatingSelection();

        // 7. Setup Bottom Navigation
        setupBottomNavigation();
    }

    private void setupSeatingSelection() {
        // Set click listeners for the cards/layouts
        View.OnClickListener seatingListener = v -> {
            // Reset all to white/default
            resetSeatingStyles();

            // Highlight the clicked one
            v.setBackgroundResource(R.drawable.bg_selected); // Gold/Yellow background

            // Update selected variable based on ID
            int id = v.getId();
            if (id == R.id.layout_indoor) {
                selectedSeating = "Indoor";
            } else if (id == R.id.layout_outdoor) {
                selectedSeating = "Outdoor";
            } else if (id == R.id.layout_window) {
                selectedSeating = "Window";
            }

            Toast.makeText(this, "Selected: " + selectedSeating, Toast.LENGTH_SHORT).show();
        };

        if (layoutIndoor != null) layoutIndoor.setOnClickListener(seatingListener);
        if (layoutOutdoor != null) layoutOutdoor.setOnClickListener(seatingListener);
        if (layoutWindow != null) layoutWindow.setOnClickListener(seatingListener);
    }

    private void resetSeatingStyles() {
        // Reset backgrounds to white
        if (layoutIndoor != null) layoutIndoor.setBackgroundResource(R.drawable.bg_white_card);
        if (layoutOutdoor != null) layoutOutdoor.setBackgroundResource(R.drawable.bg_white_card);
        if (layoutWindow != null) layoutWindow.setBackgroundResource(R.drawable.bg_white_card);
    }

    private void confirmReservation() {
        // Here you would save to SQLite database

        String message = "Confirmed!\nTime: " + selectedTime + "\nSeat: " + selectedSeating;
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();

        // Navigate to the Reservation List (History) to show the booking
        Intent intent = new Intent(GuestReservationTableActivity.this, GuestReservationListActivity.class);
        // Clear back stack so user can't go back to selection screens
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    private void setupBottomNavigation() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) navMenu.setOnClickListener(v -> startActivity(new Intent(this, GuestMenuActivity.class)));
        if (navReservation != null) navReservation.setOnClickListener(v -> startActivity(new Intent(this, GuestReservationActivity.class)));
        if (navNotification != null) navNotification.setOnClickListener(v -> startActivity(new Intent(this, GuestNotificationActivity.class)));
        if (navSettings != null) navSettings.setOnClickListener(v -> startActivity(new Intent(this, GuestSettingsActivity.class)));
    }
}
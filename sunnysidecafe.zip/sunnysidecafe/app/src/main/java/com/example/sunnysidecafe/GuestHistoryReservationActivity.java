package com.example.sunnysidecafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class GuestHistoryReservationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_history_reservation_screen);

        // 1. Logic to go BACK to Upcoming (List) when clicking "Upcoming" tab
        View tabUpcoming = findViewById(R.id.tab_upcoming);
        if (tabUpcoming != null) {
            tabUpcoming.setOnClickListener(v -> {
                Intent intent = new Intent(GuestHistoryReservationActivity.this, GuestReservationListActivity.class);
                startActivity(intent);
                overridePendingTransition(0, 0); // No animation for tab switching effect
            });
        }

        // 2. Back Button Logic
        View btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // 3. Setup Bottom Navigation
        setupBottomNavigation();
    }

    private void setupBottomNavigation() {
        View navMenu = findViewById(R.id.nav_btn_menu);
        View navReservation = findViewById(R.id.nav_btn_reservation);
        View navNotification = findViewById(R.id.nav_btn_notification);
        View navSettings = findViewById(R.id.nav_btn_settings);

        if (navMenu != null) {
            navMenu.setOnClickListener(v -> startActivity(new Intent(this, GuestMenuActivity.class)));
        }
        if (navReservation != null) {
            // Already in Reservation section, maybe go to Hub or stay
            navReservation.setOnClickListener(v -> startActivity(new Intent(this, GuestReservationActivity.class)));
        }
        if (navNotification != null) {
            navNotification.setOnClickListener(v -> startActivity(new Intent(this, GuestNotificationActivity.class)));
        }
        if (navSettings != null) {
            navSettings.setOnClickListener(v -> startActivity(new Intent(this, GuestSettingsActivity.class)));
        }
    }
}
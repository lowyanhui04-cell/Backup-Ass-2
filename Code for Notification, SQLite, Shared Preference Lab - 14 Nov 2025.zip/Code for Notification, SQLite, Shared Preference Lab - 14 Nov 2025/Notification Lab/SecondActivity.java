package com.example.notification_exercise;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tv = new TextView(this);
        tv.setTextSize(20f);

        String data = getIntent().getStringExtra("data");
        if (data == null) data = "No data received";

        tv.setText("SecondActivity opened!\n\n" + data);
        setContentView(tv);
    }
}

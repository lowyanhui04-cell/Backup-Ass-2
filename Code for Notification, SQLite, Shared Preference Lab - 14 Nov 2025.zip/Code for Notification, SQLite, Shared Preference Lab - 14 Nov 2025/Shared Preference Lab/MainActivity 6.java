package com.example.shared_preference;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static final String PREF_NAME = "MyPrefs";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_REMEMBER = "remember";

    EditText etUsername;
    Switch switchRemember;
    Button btnSave;
    TextView tvStatus;

    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsername = findViewById(R.id.etUsername);
        switchRemember = findViewById(R.id.switchRemember);
        btnSave = findViewById(R.id.btnSave);
        tvStatus = findViewById(R.id.tvStatus);

        sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        loadPreferences();

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                savePreferences();
            }
        });
    }

    private void loadPreferences() {
        String username = sharedPreferences.getString(KEY_USERNAME, "");
        boolean remember = sharedPreferences.getBoolean(KEY_REMEMBER, false);

        etUsername.setText(username);
        switchRemember.setChecked(remember);

        tvStatus.setText("Loaded: username=" + username + ", remember=" + remember);
    }

    private void savePreferences() {
        String username = etUsername.getText().toString().trim();
        boolean remember = switchRemember.isChecked();

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_USERNAME, username);
        editor.putBoolean(KEY_REMEMBER, remember);
        editor.apply();

        tvStatus.setText("Saved: username=" + username + ", remember=" + remember);
    }
}

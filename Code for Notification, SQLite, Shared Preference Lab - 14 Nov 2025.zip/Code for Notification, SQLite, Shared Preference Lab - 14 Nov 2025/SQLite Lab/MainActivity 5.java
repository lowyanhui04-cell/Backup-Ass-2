package com.example.sqlite_demo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText etName, etAge, etEmail;
    Button btnAdd, btnView;
    TextView tvUsers;

    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etAge = findViewById(R.id.etAge);
        etEmail = findViewById(R.id.etEmail);
        btnAdd = findViewById(R.id.btnAdd);
        btnView = findViewById(R.id.btnView);
        tvUsers = findViewById(R.id.tvUsers);

        dbHelper = new DatabaseHelper(this);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString().trim();
                String ageStr = etAge.getText().toString().trim();
                String email = etEmail.getText().toString().trim();

                if (name.isEmpty() || ageStr.isEmpty() || email.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                int age = Integer.parseInt(ageStr);
                DataModel data = new DataModel(name, age, email);

                boolean success = dbHelper.addUser(data);
                if (success) {
                    Toast.makeText(MainActivity.this, "User added", Toast.LENGTH_SHORT).show();
                    etName.setText("");
                    etAge.setText("");
                    etEmail.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Failed to add", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<DataModel> users = dbHelper.getAllUsers();
                StringBuilder sb = new StringBuilder();
                for (DataModel d : users) {
                    sb.append(d.toString()).append("\n");
                }
                if (users.isEmpty()) {
                    sb.append("No users yet.");
                }
                tvUsers.setText(sb.toString());
            }
        });
    }
}
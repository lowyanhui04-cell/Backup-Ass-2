package com.example.sqlite_demo;

public class DataModel {
    String name, email;
    int age;

    public DataModel(String name, int age, String email) {
        this.name = name;
        this.email = email;
        this.age = age;
    }

    public String getName() { return name; }
    public String getEmail() { return email; }
    public int getAge() { return age; }

    @Override
    public String toString() {
        return name + " (" + age + ") - " + email;
    }
}